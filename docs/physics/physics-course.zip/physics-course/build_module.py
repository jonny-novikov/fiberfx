#!/usr/bin/env python3
"""Генератор модуля курса /physics (дизайн-система style.py).
Модуль = материалы (разделы) + интерактив (калькулятор/чек-лист) + квиз модуля + навигация.
Каждый модуль ОБЯЗАН заканчиваться квизом (директива курса). В CFG — образец 1.4 «Закон Ома»
с интерактивным калькулятором закона Ома; остальные модули заполняются по аналогии."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style

BASE = os.path.dirname(os.path.abspath(__file__))

def sect(i, inner):
    return f'<section class="sect" id="s{i}">\n  <div class="container">\n{inner}\n  </div>\n</section>'
def secnav(items):
    return ''.join(f'\n    <a href="#s{i+1}"><span class="sn-n">{i+1}</span> {l}</a>' for i,l in enumerate(items))
def takeaway(items):
    return ''.join(f'\n        <div class="takeaway-item"><span class="ti-num">{i+1}</span><span class="ti-text">{t}</span></div>' for i,t in enumerate(items))
def refs(items):
    return ''.join(f'\n    <li>{r}</li>' for r in items)

# Интерактив-калькулятор закона Ома (HTML + JS) — образец интерактива
OHM_HTML = """    <div class="task-block">
      <div class="task-head"><span class="task-tag">Интерактив · калькулятор</span><h4>Калькулятор закона Ома</h4></div>
      <p class="task-intro">Введите любые две величины — калькулятор найдёт третью и заодно мощность.</p>
      <div class="calc-grid">
        <div class="calc-field"><label>Напряжение U, В</label><input id="om-u" type="number" inputmode="decimal" placeholder="например, 12"></div>
        <div class="calc-field"><label>Ток I, А</label><input id="om-i" type="number" inputmode="decimal" placeholder="например, 3"></div>
        <div class="calc-field"><label>Сопротивление R, Ом</label><input id="om-r" type="number" inputmode="decimal" placeholder="например, 4"></div>
      </div>
      <button class="calc-btn" id="om-btn">Рассчитать</button>
      <div class="calc-result" id="om-res"></div>
      <div class="disclaimer">Учебный калькулятор: значения нигде не сохраняются и не передаются.</div>
    </div>"""

OHM_JS = """function omFmt(x){ return (Math.round(x*1000)/1000).toString().replace('.',','); }
function omCalc(){
  var res=document.getElementById('om-res');
  var U=parseFloat(document.getElementById('om-u').value),
      I=parseFloat(document.getElementById('om-i').value),
      R=parseFloat(document.getElementById('om-r').value);
  var nU=!isNaN(U), nI=!isNaN(I), nR=!isNaN(R), cnt=(nU?1:0)+(nI?1:0)+(nR?1:0);
  function show(html){ res.innerHTML=html; res.classList.add('show'); }
  if(cnt<2){ show('<p class="cr-t">Введите хотя бы <b>две</b> величины — третью посчитаю.</p>'); return; }
  var big='', formula='';
  if(!nU){ U=I*R; big='U = '+omFmt(U)+' В'; formula='U = I &middot; R'; }
  else if(!nI){ if(R===0){ show('<p class="cr-t">Сопротивление не может быть нулём при делении.</p>'); return; } I=U/R; big='I = '+omFmt(I)+' А'; formula='I = U / R'; }
  else if(!nR){ if(I===0){ show('<p class="cr-t">Ток не может быть нулём при делении.</p>'); return; } R=U/I; big='R = '+omFmt(R)+' Ом'; formula='R = U / I'; }
  else { big='Все три заданы'; formula='проверка U = I &middot; R'; }
  var P=U*I;
  show('<div class="cr-big">'+big+'</div><p class="cr-t">Формула: <b>'+formula+'</b>. Мощность: <b>P = U &middot; I = '+omFmt(P)+' Вт</b>.</p>');
}
document.getElementById('om-btn').addEventListener('click', omCalc);"""

QUIZ_JS = """const QUIZ_KEY='@@QUIZ_KEY@@';
const QUIZ=@@QUIZ_JSON@@;
let qs={};
function qSave(){ try{localStorage.setItem(QUIZ_KEY,JSON.stringify(qs));}catch(e){} }
function qLoad(){ try{var r=localStorage.getItem(QUIZ_KEY); if(r) qs=JSON.parse(r);}catch(e){qs={};} }
function qBuild(){
  var root=document.getElementById('quiz-root'),h='';
  QUIZ.forEach(function(it,qi){
    h+='<div class="quiz-q" data-q="'+qi+'"><div class="q-text"><span class="q-num">'+(qi+1)+'</span><span>'+it.q+'</span></div><div class="q-options">';
    it.options.forEach(function(o,oi){ h+='<button class="q-opt" data-q="'+qi+'" data-o="'+oi+'">'+o+'</button>'; });
    h+='</div><div class="q-explain" id="qe-'+qi+'">'+it.explain+'</div></div>';
  });
  root.innerHTML=h;
  root.querySelectorAll('.q-opt').forEach(function(b){ b.addEventListener('click',qOpt); });
  Object.keys(qs).forEach(function(qi){ qApply(Number(qi)); });
}
function qApply(qi){
  var it=QUIZ[qi],st=qs[qi]; if(!st) return;
  var el=document.querySelector('.quiz-q[data-q="'+qi+'"]'); if(!el) return;
  el.querySelectorAll('.q-opt').forEach(function(b,oi){ b.classList.add('disabled'); if(oi===it.correct) b.classList.add('correct'); else if(oi===st.choice) b.classList.add('incorrect'); });
  document.getElementById('qe-'+qi).classList.add('show');
}
function qOpt(e){ var qi=Number(e.currentTarget.dataset.q),oi=Number(e.currentTarget.dataset.o); if(qs[qi]) return; qs[qi]={correct:oi===QUIZ[qi].correct,choice:oi}; qApply(qi); qSave(); qScore(); }
function qScore(){
  var N=QUIZ.length,ans=Object.keys(qs).length,ok=Object.values(qs).filter(function(s){return s.correct;}).length;
  var el=document.getElementById('quiz-score');
  if(ans===0){ el.textContent='0 / '+N; return; }
  var t=ok+' / '+N+' верно';
  if(ans===N) t+= ok===N?' — отлично!':(ok>=Math.ceil(N*0.6)?' — хорошо!':' — стоит перечитать');
  el.textContent=t;
}
qLoad(); qBuild(); qScore();
document.getElementById('quiz-reset').addEventListener('click',function(){ qs={}; try{localStorage.removeItem(QUIZ_KEY);}catch(e){} qBuild(); qScore(); });"""


# ===== интерактивы модулей 1.1-1.3 =====
FLOW_HTML = """    <div class="task-block">
      <div class="task-head"><span class="task-tag">Интерактив · схема</span><h4>Куда течёт ток?</h4></div>
      <p class="task-intro">Переключите вид — и сравните условное направление тока с реальным движением электронов.</p>
      <style>
      .flow-wire{position:relative;height:56px;border-radius:28px;border:1px solid var(--line);background:rgba(var(--rgb),.06);overflow:hidden;margin:8px 0}
      .flow-wire .term{position:absolute;top:0;bottom:0;width:48px;display:grid;place-items:center;font-family:var(--mono);font-weight:700;font-size:1.25rem;color:var(--accent-bright);z-index:2;background:rgba(0,0,0,.18)}
      .flow-wire .term.l{left:0;border-right:1px solid var(--line)}
      .flow-wire .term.r{right:0;border-left:1px solid var(--line)}
      .flow-dots{position:absolute;left:48px;right:48px;top:0;bottom:0}
      .flow-dots i{position:absolute;top:50%;width:12px;height:12px;border-radius:50%;background:var(--accent-bright);box-shadow:0 0 9px rgba(var(--rgb),.75);transform:translateY(-50%);animation:flowR 2.6s linear infinite}
      .flow-wire.rev .flow-dots i{animation-name:flowL}
      @keyframes flowR{from{left:-5%}to{left:105%}}
      @keyframes flowL{from{left:105%}to{left:-5%}}
      @media(prefers-reduced-motion:reduce){.flow-dots i{animation:none;left:50%}}
      </style>
      <div class="flow-wire" id="flow"><span class="term l">+</span><div class="flow-dots" id="dots"></div><span class="term r">&minus;</span></div>
      <div class="seg" id="flow-seg">
        <button class="on" data-mode="current">Ток (условно)</button>
        <button data-mode="electrons">Электроны</button>
      </div>
      <div class="calc-result show" id="flow-res"></div>
      <div class="disclaimer">Схема наглядная: ток условно течёт от «плюса» к «минусу», электроны — навстречу.</div>
    </div>"""
FLOW_JS = """(function(){
  var dots=document.getElementById('dots');
  for(var k=0;k<7;k++){ var i=document.createElement('i'); i.style.animationDelay=(k*0.37)+'s'; dots.appendChild(i); }
  var wire=document.getElementById('flow'), res=document.getElementById('flow-res');
  function set(mode){
    document.querySelectorAll('#flow-seg button').forEach(function(b){ b.classList.toggle('on', b.dataset.mode===mode); });
    if(mode==='electrons'){ wire.classList.add('rev'); res.innerHTML='<p class="cr-t"><b>Электроны</b> движутся от «минуса» к «плюсу» (влево) — навстречу условному току.</p>'; }
    else { wire.classList.remove('rev'); res.innerHTML='<p class="cr-t"><b>Ток</b> условно течёт от «плюса» к «минусу» (вправо). Так договорились исторически.</p>'; }
  }
  document.querySelectorAll('#flow-seg button').forEach(function(b){ b.addEventListener('click', function(){ set(b.dataset.mode); }); });
  set('current');
})();"""

VOLT_HTML = """    <div class="task-block">
      <div class="task-head"><span class="task-tag">Интерактив · слайдер</span><h4>Напряжение и «напор»</h4></div>
      <p class="task-intro">Двигайте напряжение при фиксированном сопротивлении (R = 12 Ом) — смотрите, как растёт ток.</p>
      <style>
      .v-row{display:flex;justify-content:space-between;font-family:var(--mono);font-size:.9rem;color:var(--cream-soft);margin:4px 0}
      input[type=range].v-sl{width:100%;accent-color:var(--accent);height:26px}
      .napor-bar{height:24px;border:1px solid var(--line);border-radius:12px;background:rgba(0,0,0,.22);overflow:hidden;margin:10px 0}
      .napor-bar>div{height:100%;width:50%;background:linear-gradient(90deg,var(--accent-deep),var(--accent-bright));transition:width .12s}
      </style>
      <div class="v-row"><span>U = <b id="v-val">12</b> В</span><span>R = 12 Ом</span></div>
      <input class="v-sl" type="range" id="v-slider" min="0" max="24" step="1" value="12">
      <div class="napor-bar"><div id="napor-fill"></div></div>
      <div class="calc-result show" id="v-res"></div>
      <div class="disclaimer">Модель по закону Ома: I = U / R. Значения учебные.</div>
    </div>"""
VOLT_JS = """(function(){
  var sl=document.getElementById('v-slider'), val=document.getElementById('v-val'), fill=document.getElementById('napor-fill'), res=document.getElementById('v-res');
  var R=12, Imax=24/12;
  function upd(){
    var U=parseFloat(sl.value), I=U/R;
    val.textContent=U;
    fill.style.width=(Imax>0?(I/Imax*100):0)+'%';
    res.innerHTML='<p class="cr-t">Ток <b>I = U / R = '+(Math.round(I*100)/100).toString().replace('.',',')+' А</b>. Больше напряжение — больше ток.</p>';
  }
  sl.addEventListener('input', upd); upd();
})();"""

RES_HTML = """    <div class="task-block">
      <div class="task-head"><span class="task-tag">Интерактив · конструктор</span><h4>От чего зависит сопротивление</h4></div>
      <p class="task-intro">Соберите проводник — материал, длину и толщину — и смотрите, как меняются сопротивление и ток (при одном напряжении).</p>
      <style>
      .res-ctl{display:grid;gap:12px;margin:6px 0}
      .res-ctl .rc-row{display:flex;flex-wrap:wrap;align-items:center;gap:10px}
      .res-ctl .rc-lab{font-family:var(--sans);font-size:.82rem;font-weight:600;color:var(--cream-soft);min-width:96px}
      .cur-bar{height:22px;border:1px solid var(--line);border-radius:11px;background:rgba(0,0,0,.22);overflow:hidden;margin:10px 0}
      .cur-bar>div{height:100%;width:50%;background:linear-gradient(90deg,var(--accent-deep),var(--accent-bright));transition:width .15s}
      </style>
      <div class="res-ctl">
        <div class="rc-row"><span class="rc-lab">Материал</span><div class="seg" data-grp="mat"><button class="on" data-v="1">Медь</button><button data-v="30">Нихром</button></div></div>
        <div class="rc-row"><span class="rc-lab">Длина</span><div class="seg" data-grp="len"><button class="on" data-v="1">Короткий</button><button data-v="3">Длинный</button></div></div>
        <div class="rc-row"><span class="rc-lab">Сечение</span><div class="seg" data-grp="area"><button class="on" data-v="1">Тонкий</button><button data-v="3">Толстый</button></div></div>
      </div>
      <div class="cur-bar"><div id="res-fill"></div></div>
      <div class="calc-result show" id="res-out"></div>
      <div class="disclaimer">Модель в условных единицах: R растёт с длиной и материалом, падает с сечением. Ток — при одном напряжении.</div>
    </div>"""
RES_JS = """(function(){
  var sel={mat:1,len:1,area:1};
  function upd(){
    var R=sel.mat*sel.len/sel.area, I=12/R, w=Math.min(100, 30/R);
    document.getElementById('res-fill').style.width=w+'%';
    var verdict = R<=1 ? 'малое сопротивление — большой ток' : (R<=6 ? 'среднее сопротивление' : 'большое сопротивление — маленький ток');
    document.getElementById('res-out').innerHTML='<p class="cr-t">Сопротивление <b>R &asymp; '+(Math.round(R*100)/100).toString().replace('.',',')+'</b> усл. ед. — '+verdict+'.</p>';
  }
  document.querySelectorAll('.res-ctl .seg').forEach(function(seg){
    seg.querySelectorAll('button').forEach(function(b){
      b.addEventListener('click', function(){
        seg.querySelectorAll('button').forEach(function(x){ x.classList.remove('on'); });
        b.classList.add('on'); sel[seg.dataset.grp]=parseFloat(b.dataset.v); upd();
      });
    });
  });
  upd();
})();"""

# ---------- модули Главы 1 ----------
M14 = dict(
    slug='zakon-oma', chapter='tok', pal='tok', num='1.4', name='Закон Ома',
    title='Модуль 1.4 · Закон Ома · Электричество дома',
    desc='Модуль 1.4: закон Ома U=IR — связь напряжения, тока и сопротивления, три формы формулы, интерактивный калькулятор и примеры из жизни. С квизом.',
    kicker='Глава 1 · Модуль 1.4',
    h1='Закон <span class="em">Ома</span>',
    formula='U = IR', hero_formula='U = IR',
    lead='Одна формула связывает напряжение, ток и сопротивление — и из неё следует почти всё в этой главе. Разберём её в трёх формах и сразу посчитаем на калькуляторе.',
    secnav=['Что это','Три формы','Калькулятор','В жизни'],
    sections=[
        """    <div class="sect-head"><span class="kicker">Раздел 1 · Что это</span><h2>Что говорит <span class="em">закон Ома</span></h2><p class="lead">Чем больше «давление» (напряжение) и чем меньше «узость трубы» (сопротивление), тем сильнее поток (ток).</p></div>
    <div class="sect-block"><ul>
      <li><b>Напряжение $U$</b> (вольты) «толкает» ток.</li>
      <li><b>Сопротивление $R$</b> (омы) мешает току.</li>
      <li><b>Ток $I$</b> (амперы) — то, что в итоге течёт.</li>
    </ul>
    <div class="callout">Аналогия воды: напряжение — давление, сопротивление — узость трубы, ток — поток воды. Шире труба (меньше $R$) — больше поток (больше $I$).</div></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 2 · Три формы</span><h2>Три формы <span class="em">одной формулы</span></h2><p class="lead">Зная любые две величины, всегда найдёте третью.</p></div>
    <div class="formula-box"><div>
      <div class="fb-cap">Закон Ома</div>
      $$U = IR \\qquad I = \\frac{U}{R} \\qquad R = \\frac{U}{I}$$
    </div></div>
    <div class="sect-block"><ul>
      <li><b>$U = IR$</b> — найти напряжение по току и сопротивлению.</li>
      <li><b>$I = U/R$</b> — найти ток по напряжению и сопротивлению.</li>
      <li><b>$R = U/I$</b> — найти сопротивление по напряжению и току.</li>
    </ul></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 3 · Калькулятор</span><h2>Посчитайте <span class="em">сами</span></h2><p class="lead">Введите любые две величины — третья и мощность посчитаются автоматически.</p></div>
""" + OHM_HTML,
        """    <div class="sect-head"><span class="kicker">Раздел 4 · В жизни</span><h2>Где это <span class="em">в розетке</span></h2><p class="lead">Закон Ома объясняет повседневные вещи.</p></div>
    <div class="sect-block"><ul>
      <li><b>Нагреватель vs лампа:</b> меньше сопротивление — больше ток и больше тепла при том же напряжении.</li>
      <li><b>Толстый провод</b> имеет меньшее сопротивление, поэтому меньше греется при том же токе.</li>
      <li><b>Влажные руки</b> снижают сопротивление тела — ток через тело растёт (об этом подробно в главе о безопасности).</li>
    </ul>
    <div class="callout warn">Не проверяйте сопротивление тела на розетке: при $230$ В даже небольшое снижение сопротивления даёт опасный ток.</div></div>""",
    ],
    takeaway=[
        'Закон Ома: $U = IR$ — связь напряжения, тока и сопротивления.',
        'Три формы: $U=IR$, $I=U/R$, $R=U/I$ — зная любые две величины, найдёте третью.',
        'Больше сопротивление при том же напряжении — меньше ток.',
        'Калькулятор: введите две величины — получите третью и мощность $P=UI$.',
    ],
    quiz=[
        {"q":"Закон Ома связывает:","options":["напряжение, ток и сопротивление","массу и скорость","температуру и время","объём и давление газа"],"correct":0,
         "explain":"<b>U, I и R.</b> $U=IR$ — фундамент расчётов в цепях."},
        {"q":"Если $U=12$ В и $R=4$ Ом, то ток $I$ равен:","options":["3 А","48 А","0,33 А","16 А"],"correct":0,
         "explain":"<b>3 А.</b> $I=U/R=12/4=3$."},
        {"q":"Чтобы найти сопротивление, нужно:","options":["R = U / I","R = U · I","R = I / U","R = U + I"],"correct":0,
         "explain":"<b>$R=U/I$.</b> Третья форма закона Ома."},
        {"q":"Верно ли: «При том же напряжении большее сопротивление даёт меньший ток»?","options":["Верно","Неверно"],"correct":0,
         "explain":"<b>Верно.</b> $I=U/R$: при росте $R$ ток падает."},
        {"q":"Толстый провод по сравнению с тонким (тот же материал и длина):","options":["имеет меньшее сопротивление","имеет большее сопротивление","имеет такое же сопротивление","не проводит ток"],"correct":0,
         "explain":"<b>Меньшее сопротивление.</b> Поэтому толстый провод меньше греется при том же токе."},
    ],
    interactive_js=OHM_JS,
    quiz_key='phys-tok-zakon-oma-quiz',
    prev=('/physics/tok/soprotivlenie', 'Модуль 1.3', '<span class="em">Сопротивление</span>'),
    nxt=('/physics/tok/cepi', 'Модуль 1.5', '<span class="em">Цепи</span>: посл. и парал.'),
)


M11 = dict(
    slug='tok-chto', chapter='tok', pal='tok', num='1.1', name='Что течёт в проводах',
    title='Модуль 1.1 · Что течёт в проводах · Электричество дома',
    desc='Модуль 1.1: что течёт в проводах — заряд и ток, ампер, условное направление тока и движение электронов. Интерактивная схема и квиз.',
    kicker='Глава 1 · Модуль 1.1',
    h1='Что течёт <span class="em">в проводах</span>',
    formula='I = q/t', hero_formula='I = \\frac{q}{t}',
    lead='В розетке и проводах нет «электрической жидкости» — там движется заряд. Разберём, что именно течёт, как это измеряют и куда оно направлено.',
    secnav=['Заряд и ток','Направление','Схема','В жизни'],
    sections=[
        """    <div class="sect-head"><span class="kicker">Раздел 1 · Заряд и ток</span><h2>Что <span class="em">движется</span> в проводе</h2><p class="lead">Ток — это направленный поток заряда. В металлах его несут свободные электроны.</p></div>
    <div class="sect-block"><ul>
      <li><b>Свободные электроны</b> в металле обычно движутся хаотично; под напряжением — направленно.</li>
      <li><b>Сила тока $I$</b> — сколько заряда проходит за секунду; измеряется в амперах (А).</li>
      <li><b>Ампер:</b> $1$ А — это $1$ кулон заряда за $1$ секунду.</li>
    </ul>
    <div class="formula-box"><div><div class="fb-cap">Сила тока</div>$$I = \\frac{q}{t}$$</div></div></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 2 · Направление</span><h2>Куда он <span class="em">направлен</span></h2><p class="lead">Здесь есть историческая тонкость.</p></div>
    <div class="sect-block"><ul>
      <li><b>Условное направление тока</b> — от «плюса» к «минусу». Так договорились ещё до открытия электрона.</li>
      <li><b>Электроны</b> заряжены отрицательно и движутся навстречу — от «минуса» к «плюсу».</li>
      <li>На расчёты это не влияет: важна величина тока, а не «чьё» движение мы рисуем.</li>
    </ul></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 3 · Схема</span><h2>Посмотрите <span class="em">сами</span></h2><p class="lead">Переключите вид и сравните направления.</p></div>
""" + FLOW_HTML,
        """    <div class="sect-head"><span class="kicker">Раздел 4 · В жизни</span><h2>Постоянный и <span class="em">переменный</span></h2><p class="lead">Не всегда заряд течёт в одну сторону.</p></div>
    <div class="sect-block"><ul>
      <li><b>В батарейке</b> — постоянный ток: заряд течёт в одну сторону.</li>
      <li><b>В розетке</b> — переменный ток: электроны колеблются туда-обратно $50$ раз в секунду.</li>
      <li>Подробнее о различии — в главе об устройствах (модуль 5.1).</li>
    </ul></div>""",
    ],
    takeaway=[
        'Ток — направленный поток заряда; в металлах его несут свободные электроны.',
        'Сила тока измеряется в амперах: $1$ А — это $1$ кулон заряда за секунду.',
        'Условное направление тока — от «плюса» к «минусу»; электроны движутся навстречу.',
        'В батарейке ток постоянный, в розетке — переменный.',
    ],
    quiz=[
        {"q":"Электрический ток — это:","options":["направленный поток заряда","поток воды","поток тепла","поток света"],"correct":0,"explain":"<b>Поток заряда.</b> В металлах его создают движущиеся свободные электроны."},
        {"q":"В металлах заряд переносят:","options":["свободные электроны","протоны","нейтроны","молекулы воздуха"],"correct":0,"explain":"<b>Электроны.</b> Часть электронов в металле не привязана к атомам и может двигаться."},
        {"q":"Сила тока измеряется в:","options":["амперах","вольтах","омах","ваттах"],"correct":0,"explain":"<b>Амперы.</b> $1$ А — это $1$ кулон заряда за секунду."},
        {"q":"Верно ли: «Условное направление тока противоположно движению электронов»?","options":["Верно","Неверно"],"correct":0,"explain":"<b>Верно.</b> Ток условно течёт от «плюса» к «минусу», электроны — навстречу."},
        {"q":"В батарейке ток:","options":["постоянный (течёт в одну сторону)","переменный","отсутствует","есть только при нагреве"],"correct":0,"explain":"<b>Постоянный.</b> В розетке же ток переменный."},
    ],
    interactive_js=FLOW_JS, quiz_key='phys-tok-tok-chto-quiz',
    prev=('/physics/tok', 'Глава 1', 'К обзору <span class="em">главы</span>'),
    nxt=('/physics/tok/napryazhenie', 'Модуль 1.2', '<span class="em">Напряжение</span>'),
)

M12 = dict(
    slug='napryazhenie', chapter='tok', pal='tok', num='1.2', name='Напряжение',
    title='Модуль 1.2 · Напряжение · Электричество дома',
    desc='Модуль 1.2: напряжение — что «толкает» ток, вольты, аналогия давления воды, интерактивный слайдер напряжения и квиз.',
    kicker='Глава 1 · Модуль 1.2',
    h1='<span class="em">Напряжение</span>',
    formula='I = U/R', hero_formula='I = \\frac{U}{R}',
    lead='Если ток — это поток заряда, то напряжение — то, что заставляет его течь. Разберёмся, что это и почему оно похоже на «давление».',
    secnav=['Что это','Аналогия','Слайдер','В жизни'],
    sections=[
        """    <div class="sect-head"><span class="kicker">Раздел 1 · Что это</span><h2>Что такое <span class="em">напряжение</span></h2><p class="lead">Напряжение — это то, что «толкает» ток по цепи.</p></div>
    <div class="sect-block"><ul>
      <li><b>Напряжение $U$</b> — разность потенциалов между двумя точками; измеряется в вольтах (В).</li>
      <li>Нет напряжения — нет тока: зарядам нечем «толкаться».</li>
      <li>Чем больше напряжение, тем сильнее «давление» на заряды.</li>
    </ul></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 2 · Аналогия</span><h2>Как <span class="em">давление воды</span></h2><p class="lead">Электрическую цепь удобно представлять как воду в трубах.</p></div>
    <div class="sect-block"><ul>
      <li><b>Напряжение</b> — как давление воды: чем выше, тем сильнее поток.</li>
      <li><b>Ток</b> — как поток воды по трубе.</li>
      <li><b>Сопротивление</b> — как узость трубы (об этом — модуль 1.3).</li>
    </ul>
    <div class="callout">При том же сопротивлении удвоить напряжение — значит удвоить ток: $I = U/R$.</div></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 3 · Слайдер</span><h2>Покрутите <span class="em">напряжение</span></h2><p class="lead">Сопротивление зафиксировано — меняется только напряжение.</p></div>
""" + VOLT_HTML,
        """    <div class="sect-head"><span class="kicker">Раздел 4 · В жизни</span><h2>Сколько вольт <span class="em">вокруг</span></h2><p class="lead">Бытовые источники сильно отличаются по напряжению.</p></div>
    <div class="sect-block"><ul>
      <li><b>Розетка</b> в России — около $230$ В.</li>
      <li><b>USB</b> — $5$ В; <b>пальчиковая батарейка</b> — $1{,}5$ В; <b>автомобиль</b> — $12$ В.</li>
      <li>Высокое напряжение опасно: оно создаёт большой ток через тело (глава о безопасности).</li>
    </ul></div>""",
    ],
    takeaway=[
        'Напряжение — разность потенциалов, которая «толкает» ток; измеряется в вольтах (В).',
        'Аналогия: напряжение — давление, ток — поток, сопротивление — узость трубы.',
        'По закону Ома $I = U/R$: ток прямо пропорционален напряжению.',
        'Бытовые значения: розетка ~$230$ В, USB $5$ В, батарейка $1{,}5$ В.',
    ],
    quiz=[
        {"q":"Напряжение измеряется в:","options":["вольтах","амперах","омах","ваттах"],"correct":0,"explain":"<b>Вольты.</b> Напряжение — разность потенциалов между точками цепи."},
        {"q":"Напряжение в цепи — это:","options":["то, что «толкает» ток","сам поток заряда","сопротивление проводника","мощность прибора"],"correct":0,"explain":"<b>«Толкает» ток.</b> Без напряжения зарядам нечем двигаться."},
        {"q":"При том же сопротивлении большее напряжение даёт:","options":["больший ток","меньший ток","тот же ток","нулевой ток"],"correct":0,"explain":"<b>Больший ток.</b> $I = U/R$: ток растёт вместе с напряжением."},
        {"q":"Напряжение бытовой розетки в России около:","options":["230 В","12 В","1000 В","5 В"],"correct":0,"explain":"<b>Около 230 В.</b> Поэтому розетка опасна, а USB ($5$ В) — нет."},
        {"q":"Верно ли: «По закону Ома ток прямо пропорционален напряжению»?","options":["Верно","Неверно"],"correct":0,"explain":"<b>Верно.</b> При постоянном $R$: $I = U/R$."},
    ],
    interactive_js=VOLT_JS, quiz_key='phys-tok-napryazhenie-quiz',
    prev=('/physics/tok/tok-chto', 'Модуль 1.1', 'Что течёт <span class="em">в проводах</span>'),
    nxt=('/physics/tok/soprotivlenie', 'Модуль 1.3', '<span class="em">Сопротивление</span>'),
)

M13 = dict(
    slug='soprotivlenie', chapter='tok', pal='tok', num='1.3', name='Сопротивление',
    title='Модуль 1.3 · Сопротивление · Электричество дома',
    desc='Модуль 1.3: сопротивление — что мешает току, омы, зависимость от материала, длины и сечения. Интерактивный конструктор проводника и квиз.',
    kicker='Глава 1 · Модуль 1.3',
    h1='<span class="em">Сопротивление</span>',
    formula='R = U/I', hero_formula='R = \\frac{U}{I}',
    lead='Если напряжение толкает ток, то сопротивление его сдерживает. Разберём, что это, от чего зависит и зачем иногда нужно.',
    secnav=['Что это','От чего зависит','Конструктор','В жизни'],
    sections=[
        """    <div class="sect-head"><span class="kicker">Раздел 1 · Что это</span><h2>Что такое <span class="em">сопротивление</span></h2><p class="lead">Сопротивление — это то, что мешает току течь.</p></div>
    <div class="sect-block"><ul>
      <li><b>Сопротивление $R$</b> измеряется в омах (Ом).</li>
      <li>Разные материалы сопротивляются по-разному: медь — слабо, нихром — сильно.</li>
      <li>Энергия тока на сопротивлении превращается в тепло.</li>
    </ul></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 2 · От чего зависит</span><h2>От чего <span class="em">зависит</span></h2><p class="lead">Три главных фактора (плюс температура).</p></div>
    <div class="sect-block"><ul>
      <li><b>Материал:</b> у меди сопротивление маленькое, у нихрома — большое.</li>
      <li><b>Длина:</b> длиннее провод — больше сопротивление.</li>
      <li><b>Сечение:</b> толще провод — меньше сопротивление.</li>
      <li><b>Температура:</b> у металлов с нагревом сопротивление растёт.</li>
    </ul></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 3 · Конструктор</span><h2>Соберите <span class="em">проводник</span></h2><p class="lead">Меняйте материал, длину и толщину — смотрите на сопротивление и ток.</p></div>
""" + RES_HTML,
        """    <div class="sect-head"><span class="kicker">Раздел 4 · В жизни</span><h2>Где это <span class="em">важно</span></h2><p class="lead">Сопротивление — это и польза, и проблема.</p></div>
    <div class="sect-block"><ul>
      <li><b>Нагреватели и лампы накаливания:</b> нихром и вольфрам с большим сопротивлением сильно греются.</li>
      <li><b>Провода:</b> толстую медь берут специально — у неё малое сопротивление и меньше потерь.</li>
      <li>Тонкий или длинный провод под нагрузкой греется — это причина перегрева (глава о безопасности).</li>
    </ul></div>""",
    ],
    takeaway=[
        'Сопротивление мешает току; измеряется в омах (Ом).',
        'Оно зависит от материала, длины (длиннее → больше $R$) и сечения (толще → меньше $R$).',
        'По закону Ома $I = U/R$: больше сопротивление — меньше ток.',
        'Нихром (большое $R$) греется в нагревателях; толстая медь (малое $R$) проводит почти без потерь.',
    ],
    quiz=[
        {"q":"Сопротивление измеряется в:","options":["омах","вольтах","амперах","ваттах"],"correct":0,"explain":"<b>Омы.</b> Сопротивление показывает, насколько проводник мешает току."},
        {"q":"Если провод сделать длиннее (тот же материал и сечение), сопротивление:","options":["увеличится","уменьшится","не изменится","станет нулём"],"correct":0,"explain":"<b>Увеличится.</b> Длиннее путь — больше сопротивление."},
        {"q":"Более толстый провод (большее сечение):","options":["имеет меньшее сопротивление","имеет большее сопротивление","имеет такое же сопротивление","не проводит ток"],"correct":0,"explain":"<b>Меньшее.</b> Заряду есть где «пройти» — сопротивление падает."},
        {"q":"Большое сопротивление при том же напряжении даёт:","options":["меньший ток","больший ток","тот же ток","нулевое напряжение"],"correct":0,"explain":"<b>Меньший ток.</b> $I = U/R$: чем больше $R$, тем меньше $I$."},
        {"q":"В нагревателях используют нихром, потому что:","options":["у него большое сопротивление и он сильно греется","он совсем не проводит ток","у него нулевое сопротивление","он всегда холодный"],"correct":0,"explain":"<b>Большое сопротивление.</b> Ток, преодолевая его, выделяет тепло."},
    ],
    interactive_js=RES_JS, quiz_key='phys-tok-soprotivlenie-quiz',
    prev=('/physics/tok/napryazhenie', 'Модуль 1.2', '<span class="em">Напряжение</span>'),
    nxt=('/physics/tok/zakon-oma', 'Модуль 1.4', '<span class="em">Закон Ома</span>'),
)

MODULES = [M11, M12, M13, M14]

def build(c):
    sections = '\n\n'.join(sect(i+1, inner) for i, inner in enumerate(c['sections']))
    js = (c.get('interactive_js','') + "\n" +
          QUIZ_JS.replace('@@QUIZ_KEY@@', c['quiz_key']).replace('@@QUIZ_JSON@@', json.dumps(c['quiz'], ensure_ascii=False, indent=2))
          + "\n" + style.NAV_JS)
    html = style.head(c['title'], c['desc'], slug=c['pal'])
    ph, pl, pt = c['prev']; nh, nl, nt = c['nxt']
    body = f"""<body id="top">
<div class="progress-bar"></div>

<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="/physics/{c['chapter']}">
      <div class="brand-mark">&#9889;</div>
      <div class="brand-text"><span class="brand-name">Электричество и устройства</span><span class="brand-sub">Модуль · Глава 1</span></div>
    </a>
    <nav class="breadcrumb"><a href="/physics">Физика</a><span class="sep">/</span><a href="/physics/{c['chapter']}">Гл. 1</a><span class="sep">/</span><span class="current">{c['num']}</span></nav>
    <a class="back-link" href="/physics/{c['chapter']}">К главе</a>
  </div>
</header>

<nav class="section-nav" aria-label="Навигация по разделам">
  <div class="section-nav-inner">{secnav(c['secnav'])}
  </div>
</nav>

<section class="hero">
  <div class="container">
    <div class="hero-mark">&#9889;</div>
    <span class="kicker">{c['kicker']}</span>
    <h1>{c['h1']}</h1>
    <div class="formula-row"><span class="formula-chip"><span class="fc-l">формула</span> ${c['hero_formula']}$</span></div>
    <p class="hero-lead">{c['lead']}</p>
  </div>
</section>

<div class="safety-banner"><div><p><b>Важно:</b> образовательный материал по школьной физике. Электричество опасно — не проверяйте формулы на бытовой сети под напряжением.</p></div></div>

{sections}

<section class="takeaway-section">
  <div class="takeaway">
    <h2>Главное <span class="em">коротко</span></h2>
    <div class="takeaway-grid">{takeaway(c['takeaway'])}
    </div>
  </div>
</section>

<section class="quiz" id="quiz">
  <div class="quiz-head"><span class="quiz-tag">Квиз модуля</span><span class="quiz-score" id="quiz-score">0 / {len(c['quiz'])}</span></div>
  <p class="quiz-intro">Несколько вопросов по модулю. Выберите ответ — сразу увидите верный вариант и пояснение. Прогресс сохраняется.</p>
  <div id="quiz-root"></div>
  <div class="quiz-foot"><button class="quiz-reset" id="quiz-reset">Сбросить квиз</button></div>
</section>

<nav class="nav-prev-next">
  <a class="nav-card prev" href="{ph}"><span class="nv-label">{pl}</span><span class="nv-title">{pt}</span></a>
  <a class="nav-card next" href="{nh}"><span class="nv-label">{nl}</span><span class="nv-title">{nt}</span></a>
</nav>
<div class="to-top"><a href="#top">↑ Наверх</a></div>

<footer class="footer"><div class="container">
  <div class="foot-mark">&#9889;</div>
  <p>Модуль {c['num']} · {c['name']}</p>
  <p>Курс <a href="/physics">«Электричество и устройства»</a></p>
  <p class="foot-links"><a href="/physics/{c['chapter']}">← К главе 1</a><a href="/physics/{c['chapter']}/kviz">Квиз главы</a></p>
</div></footer>

<script>
{js}
</script>
</body>
</html>
"""
    out_dir = os.path.join(BASE, 'site', 'physics', c['chapter'])
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, c['slug'] + '.html')
    open(out, 'w', encoding='utf-8').write(html + body)
    print('written:', out, '|', len(html + body), 'bytes')

if __name__ == '__main__':
    for _m in MODULES:
        build(_m)
