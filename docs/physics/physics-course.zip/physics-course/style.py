#!/usr/bin/env python3
"""jonnify · Электрическая дизайн-система (luxury editorial, dark).
Общий модуль toolkit курса «Электричество и устройства: школьная физика дома» (/physics).

Экспорт:
  FONTS              — блок <link>/<script> (шрифты + KaTeX)
  CSS                — полная таблица стилей (без тегов <style>)
  PALETTE            — слаг главы -> (accent, bright, deep, "r,g,b")
  accent_css(slug)   — :root-переопределение акцента для страницы главы
  head(title, desc, slug=None) — целиком <head>...</head>

Палитра гармонизирует с темами: электрический синий (ток), медь-янтарь (энергия),
зелёный (деньги/экономия), красный (безопасность), фиолетовый (устройства), бирюза (финал).
"""

FONTS = """<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=PT+Serif:ital,wght@0,400;0,700;1,400;1,700&family=Manrope:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
  onload="renderMathInElement(document.body,{delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}],throwOnError:false,strict:false});"></script>"""

# слаг -> (accent, accent-bright, accent-deep, "r,g,b")
PALETTE = {
    'global':     ('#4f9ad8', '#7cc1f0', '#2f6ba0', '79,154,216'),    # электрический синий
    'tok':        ('#4f9ad8', '#7cc1f0', '#2f6ba0', '79,154,216'),    # Гл.1 ток — электрик-блю
    'moshchnost': ('#d9a23f', '#f1c569', '#a8782a', '217,162,63'),    # Гл.2 мощность — медь/янтарь
    'schet':      ('#5aa67a', '#80c89c', '#3d7355', '90,166,122'),    # Гл.3 счёт — зелёный
    'bezopasnost':('#d4584a', '#f07c6e', '#9e3a30', '212,88,74'),     # Гл.4 безопасность — красный
    'ustroystva': ('#8a78d6', '#ab9bf0', '#5f4ea0', '138,120,214'),   # Гл.5 устройства — фиолетовый
    'final':      ('#3d9aa0', '#5fbcc2', '#2a6e72', '61,154,160'),    # Финал — бирюза
}

CSS = r"""
:root{
  --ink:#070a14;--ink-2:#0b1020;--surface:#111726;--surface-2:#19223a;
  --line:#283250;--line-soft:#1d2640;
  --cream:#ece6d6;--cream-soft:#d3ccb9;--muted:#9a9379;--muted-2:#6e6857;
  --accent:#4f9ad8;--accent-bright:#7cc1f0;--accent-deep:#2f6ba0;--rgb:79,154,216;
  --amber:#d9a23f;--amber-bright:#f1c569;--warn:#e0584a;--warn-bright:#ff7c6d;--ok:#5fb98a;
  --serif:'Cormorant Garamond','PT Serif',Georgia,serif;
  --body:'PT Serif','Georgia',serif;
  --sans:'Manrope',system-ui,sans-serif;
  --mono:'JetBrains Mono',ui-monospace,monospace;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--body);background:var(--ink);color:var(--cream);font-size:17px;line-height:1.65;-webkit-font-smoothing:antialiased;
  background-image:radial-gradient(ellipse at 12% -5%,rgba(var(--rgb),.10) 0%,transparent 52%),radial-gradient(ellipse at 92% 8%,rgba(217,162,63,.05) 0%,transparent 48%),linear-gradient(180deg,#070a14 0%,#0b1020 100%);
  background-attachment:fixed;min-height:100vh;position:relative}
body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:1;
  background-image:linear-gradient(rgba(var(--rgb),.03) 1px,transparent 1px),linear-gradient(90deg,rgba(var(--rgb),.03) 1px,transparent 1px);
  background-size:34px 34px;mask-image:radial-gradient(ellipse 80% 62% at 50% 0%,black 36%,transparent 100%)}
h1,h2,h3,h4{font-family:var(--serif);font-weight:500;line-height:1.16;color:var(--cream)}
h1{font-size:clamp(2.1rem,5vw,3.3rem);letter-spacing:-.015em}
h2{font-size:clamp(1.45rem,3vw,2rem);letter-spacing:-.01em}
h3{font-size:clamp(1.12rem,2vw,1.35rem)}
h4{font-size:1.05rem}
em,i{color:var(--cream-soft);font-style:italic}
strong,b{color:var(--cream);font-weight:600}
p{margin:.6em 0}
a{color:var(--accent-bright);text-decoration:none;transition:.2s}
.katex{font-size:1.04em}
.container{max-width:920px;margin:0 auto;padding:0 26px}

/* reading progress */
.progress-bar{position:fixed;top:0;left:0;height:3px;width:0;z-index:70;
  background:linear-gradient(90deg,var(--accent-deep),var(--accent-bright));box-shadow:0 0 12px rgba(var(--rgb),.65)}

/* topbar */
.topbar{position:sticky;top:0;z-index:50;background:rgba(7,10,20,.82);backdrop-filter:blur(13px);border-bottom:1px solid var(--line-soft)}
.topbar-inner{max-width:1180px;margin:0 auto;padding:13px 26px;display:flex;align-items:center;gap:20px}
.brand{display:flex;align-items:center;gap:13px;text-decoration:none}
.brand-mark{width:38px;height:38px;border-radius:9px;display:grid;place-items:center;font-size:1.2rem;color:var(--ink);
  background:linear-gradient(140deg,var(--accent-bright),var(--accent-deep));box-shadow:0 0 18px rgba(var(--rgb),.4)}
.brand-text{display:flex;flex-direction:column;line-height:1.15}
.brand-name{font-family:var(--serif);font-size:1.16rem;color:var(--cream);font-weight:600}
.brand-sub{font-family:var(--sans);font-size:.66rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
.breadcrumb{margin-left:auto;font-family:var(--sans);font-size:.8rem;color:var(--muted);display:flex;align-items:center;gap:9px}
.breadcrumb a{color:var(--muted)}.breadcrumb a:hover{color:var(--accent-bright)}
.breadcrumb .sep{opacity:.4}.breadcrumb .current{color:var(--cream-soft)}
.back-link{font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--accent-bright);white-space:nowrap}
@media(max-width:720px){.breadcrumb{display:none}}

/* section nav (scroll-spy) */
.section-nav{position:sticky;top:65px;z-index:40;background:rgba(11,16,32,.75);backdrop-filter:blur(10px);border-bottom:1px solid var(--line-soft)}
.section-nav-inner{max-width:1180px;margin:0 auto;padding:0 26px;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none}
.section-nav-inner::-webkit-scrollbar{display:none}
.section-nav a{flex:none;display:inline-flex;align-items:center;gap:8px;padding:13px 14px;font-family:var(--sans);font-size:.8rem;font-weight:500;color:var(--muted);border-bottom:2px solid transparent;white-space:nowrap;transition:.2s}
.section-nav a:hover{color:var(--cream-soft)}
.section-nav a.active{color:var(--accent-bright);border-bottom-color:var(--accent-bright)}
.section-nav a .sn-n{font-family:var(--mono);font-size:.68rem;color:var(--accent-deep)}
.section-nav a.active .sn-n{color:var(--accent-bright)}

/* hero */
.hero{padding:64px 0 30px;text-align:center;position:relative;z-index:2}
.hero-mark{width:64px;height:64px;margin:0 auto 22px;border-radius:14px;display:grid;place-items:center;font-size:2rem;color:var(--ink);
  background:linear-gradient(140deg,var(--accent-bright),var(--accent-deep));box-shadow:0 0 34px rgba(var(--rgb),.5)}
.kicker{font-family:var(--sans);font-size:.72rem;font-weight:600;letter-spacing:.22em;text-transform:uppercase;color:var(--accent-bright);display:inline-flex;align-items:center;gap:10px}
.kicker::before,.kicker::after{content:'';width:24px;height:1px;background:var(--accent-bright);opacity:.55}
.hero h1{margin:18px auto 14px;max-width:14ch}
.hero h1 .em{font-style:italic;color:var(--accent-bright)}
.hero-lead{max-width:62ch;margin:0 auto;font-size:1.12rem;color:var(--cream-soft);line-height:1.6}
.formula-row{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:26px 0 6px}
.formula-chip{display:inline-flex;align-items:center;gap:10px;padding:10px 18px;border:1px solid var(--line);border-radius:999px;background:rgba(var(--rgb),.06)}
.formula-chip .fc-l{font-family:var(--sans);font-size:.6rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
.hero-quote{max-width:60ch;margin:30px auto 0;font-family:var(--serif);font-style:italic;font-size:1.3rem;color:var(--cream-soft);line-height:1.5;position:relative;padding-top:22px}
.hero-quote::before{content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);width:42px;height:2px;background:var(--accent)}
.hero-quote .hq-source{display:block;margin-top:14px;font-family:var(--sans);font-style:normal;font-size:.72rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}

/* safety banner */
.safety-banner{position:relative;z-index:2;max-width:980px;margin:8px auto 0;padding:0 26px}
.safety-banner > div{border:1px solid var(--line);border-left:3px solid var(--amber);border-radius:0 4px 4px 0;background:linear-gradient(150deg,rgba(217,162,63,.08),var(--ink-2));padding:15px 20px}
.safety-banner p{margin:0;font-family:var(--sans);font-size:.86rem;color:var(--cream-soft);line-height:1.55}
.safety-banner b{color:var(--cream)}

/* sections */
.sect{position:relative;z-index:2;padding:48px 0;border-bottom:1px solid var(--line-soft)}
.sect-head{max-width:920px;margin:0 auto 22px;padding:0 26px}
.sect-head .kicker{margin-bottom:11px;font-size:.66rem}
.sect-head .lead,.lead{color:var(--cream-soft);font-size:1.04rem;line-height:1.6;max-width:64ch;margin:.4em 0 0}
.sect-block{max-width:920px;margin:16px auto 0;padding:0 26px}
.sect-block h3{margin:1.3em 0 .5em;color:var(--cream)}
.sect-block ul{margin:.5em 0;padding-left:0;list-style:none}
.sect-block li{position:relative;padding:6px 0 6px 26px;color:var(--cream-soft);line-height:1.55}
.sect-block li::before{content:'';position:absolute;left:4px;top:14px;width:7px;height:7px;border-radius:50%;background:var(--accent);box-shadow:0 0 7px rgba(var(--rgb),.6)}
.sect-block li b{color:var(--cream)}

/* formula / callout boxes */
.formula-box{max-width:920px;margin:18px auto;padding:0 26px}
.formula-box > div{border:1px solid var(--line);border-radius:5px;background:linear-gradient(150deg,var(--surface),var(--ink-2));padding:20px 24px;text-align:center}
.formula-box .fb-cap{font-family:var(--sans);font-size:.62rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent-bright);margin-bottom:8px}
.callout{border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:0 4px 4px 0;background:rgba(var(--rgb),.05);padding:14px 18px;margin:14px 0;font-family:var(--sans);font-size:.9rem;color:var(--cream-soft)}
.callout b{color:var(--cream)}
.callout.warn{border-left-color:var(--warn);background:rgba(224,88,74,.06)}
.disclaimer{border:1px dashed var(--line);border-radius:4px;background:rgba(0,0,0,.18);padding:11px 15px;margin:12px 0;font-family:var(--sans);font-size:.82rem;color:var(--muted)}

/* chapter grid (home / landing) */
.ch-grid{max-width:1080px;margin:0 auto;padding:0 26px;display:grid;grid-template-columns:repeat(2,1fr);gap:16px}
@media(max-width:760px){.ch-grid{grid-template-columns:1fr}}
.ch-tile{position:relative;display:flex;flex-direction:column;gap:9px;padding:24px 26px;text-decoration:none;color:inherit;border:1px solid var(--line);border-radius:4px;overflow:hidden;
  background:linear-gradient(160deg,var(--surface) 0%,var(--ink-2) 100%);transition:transform .24s,border-color .24s;
  opacity:0;animation:rise .6s cubic-bezier(.2,.7,.3,1) forwards}
.ch-tile::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--t,var(--accent))}
.ch-tile::after{content:'';position:absolute;right:-40px;top:-40px;width:130px;height:130px;border-radius:50%;background:radial-gradient(circle,rgba(var(--trgb,var(--rgb)),.16),transparent 70%);opacity:.8;transition:.24s}
.ch-tile:hover{transform:translateY(-4px);border-color:var(--tb,var(--accent-bright))}
.ch-tile:hover::after{opacity:1;transform:scale(1.15)}
.ch-tile .ct-top{display:flex;align-items:center;gap:13px}
.ch-tile .ct-n{font-family:var(--serif);font-style:italic;font-size:2rem;color:var(--tb,var(--accent-bright));line-height:1;min-width:42px}
.ch-tile .ct-tag{font-family:var(--sans);font-size:.58rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:var(--muted)}
.ch-tile h3{margin:0;font-size:1.26rem;color:var(--cream)}
.ch-tile .ct-topic{font-size:.94rem;color:var(--cream-soft);line-height:1.5;flex:1}
.ch-tile .ct-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:4px}
.ch-tile .ct-form{font-family:var(--mono);font-size:.8rem;color:var(--tb,var(--accent-bright));background:rgba(var(--trgb,var(--rgb)),.08);border:1px solid var(--line);border-radius:6px;padding:3px 9px}
.ch-tile .ct-go{font-family:var(--sans);font-size:.74rem;font-weight:600;color:var(--tb,var(--accent-bright))}
.ch-tile .ct-go::after{content:' →'}
.ch-tile.final{grid-column:1/-1;background:linear-gradient(150deg,rgba(61,154,160,.12),var(--ink-2))}
.ch-tile.final .ct-n{font-style:normal;font-size:1.5rem}
@keyframes rise{to{opacity:1;transform:translateY(0)}}
.ch-tile{transform:translateY(14px)}

/* pillars (approach) */
.pillars{max-width:1080px;margin:0 auto;padding:0 26px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
@media(max-width:860px){.pillars{grid-template-columns:repeat(2,1fr)}}
@media(max-width:480px){.pillars{grid-template-columns:1fr}}
.pillar{padding:20px;border:1px solid var(--line);border-radius:4px;background:rgba(0,0,0,.16)}
.pillar .pi-ic{font-size:1.5rem;margin-bottom:8px}
.pillar h4{margin:0 0 5px;color:var(--cream)}
.pillar p{margin:0;font-family:var(--sans);font-size:.84rem;color:var(--cream-soft);line-height:1.5}

/* project CTA */
.project-cta{max-width:920px;margin:0 auto;padding:0 26px}
.project-cta > div{border:1px solid var(--line);border-radius:6px;background:linear-gradient(150deg,rgba(61,154,160,.12),var(--ink-2));padding:30px 32px}
.project-cta h3{margin:0 0 8px;font-size:1.5rem}
.project-cta h3 .em{font-style:italic;color:#5fbcc2}
.project-cta p{font-family:var(--sans);font-size:.94rem;color:var(--cream-soft);line-height:1.6;margin:.4em 0}
.project-cta .pc-list{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0 18px}
.project-cta .pc-list span{font-family:var(--sans);font-size:.76rem;color:var(--cream-soft);border:1px solid var(--line);border-radius:999px;padding:6px 13px}
.project-cta a{display:inline-block;font-family:var(--sans);font-size:.84rem;font-weight:600;color:#5fbcc2;border:1px solid #2a6e72;border-radius:4px;padding:11px 22px}
.project-cta a:hover{background:rgba(61,154,160,.16)}
.project-cta a::after{content:' →'}

/* takeaway */
.takeaway-section{position:relative;z-index:2;padding:46px 0;border-bottom:1px solid var(--line-soft)}
.takeaway{max-width:920px;margin:0 auto;padding:0 26px}
.takeaway > h2{text-align:center;margin-bottom:24px}.takeaway > h2 .em{font-style:italic;color:var(--accent-bright)}
.takeaway-grid{display:grid;gap:12px}
.takeaway-item{display:flex;gap:16px;align-items:baseline;padding:15px 20px;border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:0 4px 4px 0;background:linear-gradient(150deg,var(--surface),var(--ink-2))}
.takeaway-item .ti-num{font-family:var(--mono);font-size:.92rem;font-weight:700;color:var(--accent-bright);min-width:30px}
.takeaway-item .ti-text{color:var(--cream-soft);line-height:1.55}.takeaway-item .ti-text b{color:var(--cream)}

/* interactive task / checklist */
.task-block{max-width:920px;margin:18px auto 0;padding:22px 24px;border:1px solid var(--line);border-radius:6px;background:linear-gradient(150deg,var(--surface),var(--ink-2))}
.task-head{display:flex;align-items:center;gap:12px;margin-bottom:8px}
.task-tag{font-family:var(--sans);font-size:.58rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:var(--accent-bright);border:1px solid var(--accent-deep);border-radius:3px;padding:3px 10px}
.task-block h4{margin:0}
.task-intro{font-family:var(--sans);font-size:.9rem;color:var(--cream-soft)}
.calc-grid{display:grid;gap:13px;margin-top:6px}
.calc-field{display:flex;flex-direction:column;gap:5px}
.calc-field label{font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--cream-soft)}
.calc-field input,.calc-field select{font-family:var(--mono);font-size:1rem;color:var(--cream);background:rgba(0,0,0,.28);border:1px solid var(--line);border-radius:5px;padding:11px 13px}
.calc-field input:focus,.calc-field select:focus{outline:none;border-color:var(--accent-bright);box-shadow:0 0 0 2px rgba(var(--rgb),.18)}
.seg{display:flex;flex-wrap:wrap;gap:8px}
.seg button{font-family:var(--sans);font-size:.84rem;font-weight:600;color:var(--cream-soft);background:rgba(0,0,0,.22);border:1px solid var(--line);border-radius:6px;padding:9px 15px;cursor:pointer;transition:.18s}
.seg button:hover{border-color:var(--accent-bright)}
.seg button.on{background:var(--accent);border-color:var(--accent);color:var(--ink)}
.calc-btn,.audit-btn{font-family:var(--sans);font-size:.86rem;font-weight:600;color:var(--ink);background:var(--accent);border:none;border-radius:6px;padding:12px 22px;margin-top:14px;cursor:pointer;transition:.18s}
.calc-btn:hover,.audit-btn:hover{background:var(--accent-bright)}
.calc-result,.audit-result{margin-top:16px;opacity:0;max-height:0;overflow:hidden;transition:.3s}
.calc-result.show,.audit-result.show{opacity:1;max-height:600px}
.calc-result .cr-big{font-family:var(--mono);font-size:1.7rem;font-weight:700;color:var(--accent-bright)}
.calc-result .cr-t,.audit-result .ar-text{font-family:var(--sans);font-size:.9rem;color:var(--cream-soft);line-height:1.55;margin-top:6px}
.audit-result .ar-count{font-family:var(--mono);font-size:1.5rem;font-weight:700;color:var(--accent-bright)}
.audit-list{display:grid;gap:8px;margin-top:6px}
.audit-item{display:flex;gap:12px;align-items:flex-start;padding:11px 14px;border:1px solid var(--line);border-radius:5px;background:rgba(0,0,0,.16);cursor:pointer;font-family:var(--sans);font-size:.9rem;color:var(--cream-soft);transition:.16s}
.audit-item:hover{border-color:var(--accent-deep)}
.audit-item input{margin-top:3px;accent-color:var(--accent)}

/* quiz */
.quiz{max-width:920px;margin:0 auto;padding:30px 26px}
.quiz-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:6px}
.quiz-tag{font-family:var(--sans);font-size:.66rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent-bright)}
.quiz-score{font-family:var(--mono);font-size:.84rem;color:var(--cream-soft)}
.quiz-intro{font-family:var(--sans);font-size:.9rem;color:var(--cream-soft);margin:0 0 16px}
.quiz-q{border:1px solid var(--line);border-radius:6px;background:linear-gradient(150deg,var(--surface),var(--ink-2));padding:18px 20px;margin-bottom:13px}
.q-text{display:flex;gap:12px;align-items:baseline;font-size:1.04rem;color:var(--cream);margin-bottom:12px}
.q-num{font-family:var(--mono);font-size:.84rem;font-weight:700;color:var(--accent-bright)}
.q-options{display:grid;gap:8px}
.q-opt{text-align:left;font-family:var(--sans);font-size:.92rem;color:var(--cream-soft);background:rgba(0,0,0,.2);border:1px solid var(--line);border-radius:5px;padding:11px 15px;cursor:pointer;transition:.16s}
.q-opt:hover:not(.disabled){border-color:var(--accent-bright)}
.q-opt.disabled{cursor:default}
.q-opt.correct{border-color:var(--ok);background:rgba(95,185,138,.13);color:var(--cream)}
.q-opt.incorrect{border-color:var(--warn);background:rgba(224,88,74,.12)}
.q-explain{margin-top:11px;font-family:var(--sans);font-size:.86rem;color:var(--cream-soft);line-height:1.55;border-left:2px solid var(--accent);padding-left:13px;display:none}
.q-explain.show{display:block}
.q-explain b{color:var(--cream)}
.quiz-foot{margin-top:14px}
.quiz-reset{font-family:var(--sans);font-size:.78rem;font-weight:600;color:var(--muted);background:none;border:1px solid var(--line);border-radius:5px;padding:8px 16px;cursor:pointer}
.quiz-reset:hover{color:var(--cream-soft);border-color:var(--accent-deep)}

/* references */
.references{max-width:920px;margin:0 auto;padding:26px;border-top:1px solid var(--line-soft)}
.ref-title{font-family:var(--sans);font-size:.66rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);margin-bottom:12px}
.ref-list{margin:0;padding-left:22px;font-family:var(--sans);font-size:.86rem;color:var(--cream-soft);line-height:1.6}
.ref-list li{margin:7px 0}.ref-list em{color:var(--cream)}
.ref-note{font-family:var(--sans);font-size:.78rem;color:var(--muted);margin-top:14px;font-style:italic}

/* prev/next + to top */
.nav-prev-next{max-width:920px;margin:18px auto 0;padding:0 26px;display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:600px){.nav-prev-next{grid-template-columns:1fr}}
.nav-card{display:flex;flex-direction:column;gap:5px;padding:17px 20px;border:1px solid var(--line);border-radius:5px;background:linear-gradient(150deg,var(--surface),var(--ink-2));text-decoration:none;color:inherit;transition:.2s}
.nav-card:hover{border-color:var(--accent-bright);transform:translateY(-2px)}
.nav-card.next{text-align:right}
.nav-card .nv-label{font-family:var(--sans);font-size:.62rem;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:var(--muted)}
.nav-card .nv-title{font-family:var(--serif);font-size:1.16rem;color:var(--cream)}.nav-card .nv-title .em{font-style:italic;color:var(--accent-bright)}
.to-top{text-align:center;padding:24px}
.to-top a{font-family:var(--sans);font-size:.8rem;font-weight:600;color:var(--muted)}.to-top a:hover{color:var(--accent-bright)}

/* footer */
.footer{position:relative;z-index:2;text-align:center;padding:48px 26px;border-top:1px solid var(--line)}
.foot-mark{font-family:var(--serif);font-size:1.7rem;color:var(--accent-bright);margin-bottom:10px}
.footer p{margin:5px 0;font-family:var(--sans);font-size:.84rem;color:var(--muted)}
.footer a{color:var(--accent-bright)}
.foot-links{display:flex;flex-wrap:wrap;gap:18px;justify-content:center;margin-top:12px}
.foot-links a{font-weight:600}

@media(min-width:1024px){html{font-size:18px}body{font-size:18.5px}}
@media(min-width:1440px){html{font-size:19px}}
@media(prefers-reduced-motion:reduce){.ch-tile{animation:none;opacity:1;transform:none}html{scroll-behavior:auto}}
"""

def accent_css(slug):
    if not slug or slug not in PALETTE:
        return ''
    a, b, d, rgb = PALETTE[slug]
    return f"\n:root{{--accent:{a};--accent-bright:{b};--accent-deep:{d};--rgb:{rgb};}}\n"

def head(title, desc, slug=None):
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
{FONTS}
<style>
{CSS}{accent_css(slug)}</style>
</head>
"""

# небольшой JS прогресс-бара + scroll-spy (используется на всех страницах)
NAV_JS = """(function(){
  var bar=document.querySelector('.progress-bar');
  function prog(){ if(!bar) return; var h=document.documentElement; var m=h.scrollHeight-h.clientHeight; bar.style.width=(m>0?(h.scrollTop/m*100):0)+'%'; }
  document.addEventListener('scroll',prog,{passive:true}); prog();
  var links=[].slice.call(document.querySelectorAll('.section-nav a'));
  if(links.length){
    var map={}; links.forEach(function(a){ map[a.getAttribute('href').slice(1)]=a; });
    var obs=new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ links.forEach(function(a){a.classList.remove('active');}); if(map[e.target.id]) map[e.target.id].classList.add('active'); } }); },{rootMargin:'-120px 0px -60% 0px',threshold:0});
    document.querySelectorAll('.sect[id],section[id]').forEach(function(s){ obs.observe(s); });
  }
})();"""

if __name__ == '__main__':
    print('PALETTE:', list(PALETTE))
    print('CSS bytes:', len(CSS))
