/* suite.landings.js — лендинги Главы 1 (tok) и Главы 2 (moshchnost).
   BASE_URL="file:///home/claude/work/physics/site" node suite.landings.js */
const { Validator } = require('./validator');
const CH = [
  { slug:'tok', title:'Глава 1', tiles:5, mod:'/physics/tok/zakon-oma',
    prev:'/physics', next:'/physics/moshchnost' },
  { slug:'moshchnost', title:'Глава 2', tiles:4, mod:'/physics/moshchnost/pribory',
    prev:'/physics/tok', next:'/physics/schet' },
];
(async () => {
  const v = new Validator({ baseUrl: process.env.BASE_URL });
  await v.start();
  for (const c of CH) {
    await v.open(`/physics/${c.slug}/index.html`);
    await v.title(c.title);
    await v.noKatexErrors();
    await v.noHorizontalOverflow();
    await v.expectCount('.progress-bar', '==', 1);
    await v.expectVisible('.section-nav');
    await v.expectCount('.section-nav a', '==', 3);
    await v.expectCount('.sect[id]', '==', 3);
    await v.expectVisible('#intro');
    await v.expectVisible('#modules');
    await v.expectVisible('#quiz-cta');
    await v.expectCount('.ch-tile', '==', c.tiles);
    await v.expectCount(`.ch-tile[href="${c.mod}"]`, '==', 1);
    await v.expectCount(`a[href="/physics/${c.slug}/kviz"]`, '>=', 1);
    await v.expectCount('.nav-card', '==', 2);
    await v.expectCount(`.nav-card.prev[href="${c.prev}"]`, '==', 1);
    await v.expectCount(`.nav-card.next[href="${c.next}"]`, '==', 1);
    await v.expectVisible('.footer');
    await v.expectVisible('.to-top');
  }
  v.report();
  await v.stop();
  process.exit(v.fail ? 1 : 0);
})();
