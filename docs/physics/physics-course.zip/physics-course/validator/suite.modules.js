/* suite.modules.js — модули Главы 1: 1.1 tok-chto, 1.2 napryazhenie, 1.3 soprotivlenie.
   BASE_URL="file:///home/claude/work/physics/site" node suite.modules.js */
const { Validator } = require('./validator');

const M = [
  { slug:'tok-chto', title:'Модуль 1.1', qopts:18, qexp:'заряда',
    prev:'/physics/tok', next:'/physics/tok/napryazhenie',
    inter: async (v) => { await v.click('#flow-seg button[data-mode="electrons"]'); await v.settle(90); await v.expectText('#flow-res','Электроны'); } },
  { slug:'napryazhenie', title:'Модуль 1.2', qopts:18, qexp:'Вольт',
    prev:'/physics/tok/tok-chto', next:'/physics/tok/soprotivlenie',
    inter: async (v) => { await v.expectText('#v-res','I = U / R'); await v.expectText('#v-res','А'); } },
  { slug:'soprotivlenie', title:'Модуль 1.3', qopts:20, qexp:'Ом',
    prev:'/physics/tok/napryazhenie', next:'/physics/tok/zakon-oma',
    inter: async (v) => { await v.click('.res-ctl .seg[data-grp="mat"] button[data-v="30"]'); await v.settle(90); await v.expectText('#res-out','30'); } },
];

(async () => {
  const v = new Validator({ baseUrl: process.env.BASE_URL });
  await v.start();
  for (const m of M) {
    await v.open(`/physics/tok/${m.slug}.html`);
    await v.title(m.title);
    await v.noKatexErrors();
    await v.noHorizontalOverflow();
    await v.expectCount('.progress-bar', '==', 1);
    await v.expectCount('.section-nav a', '==', 4);
    await v.expectCount('.sect[id]', '==', 4);
    await v.expectCount('.takeaway-item', '==', 4);
    await v.expectVisible('.safety-banner');
    await v.expectCount('.nav-card', '==', 2);
    await v.expectCount(`.nav-card.prev[href="${m.prev}"]`, '==', 1);
    await v.expectCount(`.nav-card.next[href="${m.next}"]`, '==', 1);
    await v.expectVisible('.to-top');
    // интерактив модуля
    await v.expectCount('.task-block', '==', 1);
    await m.inter(v);
    // квиз модуля (рендерится JS)
    await v.expectCount('.quiz-q', '==', 5);
    await v.expectCount('.q-opt', '==', m.qopts);
    await v.click('.quiz-q[data-q="0"] .q-opt[data-o="0"]');
    await v.settle(120);
    await v.expectText('#quiz-score', '1 / 5');
    await v.expectText('#qe-0', m.qexp);
  }
  v.report();
  await v.stop();
  process.exit(v.fail ? 1 : 0);
})();
