# Abstracts — Agile Agent Workflow in Elixir

A practitioner's course on shipping reliable software with a human and a Claude agent: decompose a vision into small valuable user stories, plan a roadmap, write the spec and the agent brief, and prove each increment correct — built end to end on **Portal**, a learning platform that grows from a branded store to an event-sourced engine behind one facade, a Phoenix web app, a Telegram bot, and a student dashboard, from zero to production.

The course is organised as a foundations chapter (**A0**) that lays out the framework, six workflow chapters (**A1–A6**) that teach it, and an exemplar chapter (**A7**) that builds the whole thing. Chapters A1–A6 follow the canonical seven-part table of contents (Parts I–VI); A7 is Part VII. A0 is front-matter that names each idea the later chapters teach.

---

## A0 · Foundations — what we are building

The framework the rest of the course runs on, told three ways: **why** a pragmatic, story-led, agent-driven workflow works; **what** it is made of — two layers, four artifacts, one loop; and **who** drives it. Each foundations piece foreshadows the chapter that later teaches it in depth.

- **A0.1 · Why it works** — the case for the workflow in one sitting: small batches, a spec that is the single source of truth, and a human/agent loop that keeps both honest. (Expanded in A1.)
- **A0.2 · What we are building** — the framework's anatomy: a roadmap layer over a spec layer over a framework-free domain core; the four artifacts every rung uses; and the loop between two roles.
  - **A0.2.1 · The two-layer model** — a roadmap layer that plans delivery sits over a spec layer that defines and proves each rung, both resting on the domain core; why the spec is the source of truth.
  - **A0.2.1 deep dive · Anatomy of a `roadmap.md`** — the parts of a roadmap: milestones, the rungs that ship value, and a definition of done; what "thin but robust" means for a rung.
  - **A0.2.2 · The four artifacts** — the `roadmap.md`, the spec, the user stories, and the agent brief (`.llms.md`), and the distinct question each one answers.
  - **A0.2.3 · The Author/Operator loop** — the Operator (human) sharpens, reviews, and accepts; the Author (Claude agent) specifies, builds, and ships; they meet on the spec, and feedback edits it each turn.
- **A0.3 · Who** — the two roles in full, what each owns, and where authority sits when they disagree. (Expanded across A5 and A6.)

## A1 · Why an Agile Agent Workflow — *Part I*

Why a disciplined workflow beats both extremes. Names the two failure modes a coding agent falls into without one, frames the work as pragmatic programming for agents, and introduces the loop, the two layers, and the running project.

- **A1.1** — two failure modes: vibe-coding that drifts, and big-bang plans that never ship.
- **A1.2** — Pragmatic Programming, re-read for a world where an agent writes the code.
- **A1.3** — the Author/Operator loop: who decides, who builds, who accepts.
- **A1.4** — two layers: a roadmap that plans and a spec that defines.
- **A1.5** — what "correct by definition" means, and why it needs a written spec.
- **A1.6** — meet Portal, the project every later chapter builds.

## A2 · Decomposition — *Part II*

Turning a product vision into a ladder of small, valuable, testable user stories. Value over tasks, the story form and its conversations, INVEST as a quality bar, acceptance criteria as examples, and how to split a story that is too big.

- **A2.1** — slice by value delivered, not by technical task.
- **A2.2** — the Connextra story form and the three Cs (card, conversation, confirmation).
- **A2.3** — INVEST: independent, negotiable, valuable, estimable, small, testable.
- **A2.4** — Given / When / Then: acceptance criteria written as concrete examples.
- **A2.5** — splitting a story along its seams while keeping each slice shippable.
- **A2.6** — the value ladder: ordering stories so every rung is worth standing on.
- **A2.7** — workshop: decompose a Portal capability end to end.

## A3 · The roadmap layer — *Part III*

The planning layer. Agile and XP distilled to what an agent workflow needs, the anatomy of a `roadmap.md`, thin-but-robust rungs, milestones and iterations, and tracer bullets that prove a path through the whole system early.

- **A3.1** — Agile distilled: the few practices that actually move delivery.
- **A3.2** — XP and small batches: shorten the loop, lower the risk.
- **A3.3** — the anatomy of a `roadmap.md`: milestones, rungs, definition of done.
- **A3.4** — thin but robust: a rung that is small yet production-grade.
- **A3.5** — milestones and iterations: grouping rungs into shippable arcs.
- **A3.6** — the program roadmap: many milestones toward one outcome.
- **A3.7** — tracer bullets and walking skeletons: prove the path before filling it in.
- **A3.8** — workshop: draft Portal's roadmap.

## A4 · The spec layer — *Part IV*

The defining layer. Specification by Example, the triad of spec, stories, and brief, the anatomy of a spec, stories captured as a `.stories.md`, invariants that must always hold, and traceability from example to test.

- **A4.1** — Specification by Example: agree on behaviour with concrete cases.
- **A4.2** — the triad: how the spec, the stories, and the agent brief relate.
- **A4.3** — the anatomy of a spec: scope, behaviour, invariants, examples.
- **A4.4** — stories to `.stories.md`: a durable, machine-readable record.
- **A4.5** — invariants: the properties the system holds at every step.
- **A4.6** — traceability: every example maps to a test, every test to a story.
- **A4.7** — workshop: specify a Portal rung.

## A5 · The agent brief (`.llms.md`) — *Part V*

The execution layer for the agent. The `llms.txt` convention, references and requirements, the execution topology, agent stories, the implementation prompt, and how to run Claude agents well as a matter of pragmatic practice.

- **A5.1** — the `llms.txt` convention and why a brief is a file, not a chat.
- **A5.2** — references and requirements: what the agent must read and honour.
- **A5.3** — execution topology: how the work is split and sequenced.
- **A5.4** — agent stories: stories written for an agent to execute.
- **A5.5** — the implementation prompt: turning a rung into instructions.
- **A5.6** — running Claude agents well: context, review, and acceptance.
- **A5.7** — Pragmatic Programming with Claude agents: the practices that compound.
- **A5.8** — workshop: write the brief for a Portal rung.

## A6 · Reliability and correctness — *Part VI*

Making each increment correct by construction. Let-it-crash and OTP, boundaries between core and shell, the master invariant, parse-don't-validate, making illegal states unrepresentable, railway error handling, event sourcing with a Decider, property-based testing, and quality gates encoded as code.

- **A6.1** — let it crash: OTP supervision and isolating failure.
- **A6.2** — boundaries: a pure core inside an imperative shell.
- **A6.3** — the master invariant: the one property the whole system protects.
- **A6.4** — parse, don't validate: turn input into trustworthy data once.
- **A6.5** — make illegal states unrepresentable in the type and data model.
- **A6.6** — railway-oriented error handling: a single happy path with explicit exits.
- **A6.7** — event sourcing and the Decider: state as a fold over events.
- **A6.8** — property-based testing: assert the invariants, not just examples.
- **A6.9** — quality gates as code: the checks that block a bad build.
- **A6.10** — workshop: harden a Portal rung to production.

## A7 · Portal — zero to production — *Part VII*

The exemplar. The whole workflow applied to one system, built in shippable rungs: a branded store, an event-sourced engine behind one facade, a Phoenix web app, a Telegram bot, a student dashboard, and the work of shipping it, closing with a retrospective.

- **A7.1** — the branded store: identifiers and persistence done once, well.
- **A7.2** — the engine: event-sourced domain behind a single facade.
- **A7.3** — the web: Phoenix over the engine, nothing leaking through.
- **A7.4** — the Telegram bot: a second interface on the same core.
- **A7.5** — the student dashboard: read models for the people using it.
- **A7.6** — shipping to production: the release, the gates, the cutover.
- **A7.7** — retrospective: what the workflow bought, and what it cost.
