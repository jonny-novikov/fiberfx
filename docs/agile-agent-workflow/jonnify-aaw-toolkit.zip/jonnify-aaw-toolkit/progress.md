# Progress — Agile Agent Workflow in Elixir

Status of the course pages as registered in `toolkit/build_page.py`. Every built page passes all nine Apollo gates (grade **A+**) and is verified headless on desktop (1280px) and mobile (390px): subtitle reads *agile agents*, the branded build-id stamp decodes to a `TSK` namespace and a numeric Snowflake, interactives update their readouts, and there is no horizontal overflow and no console error.

All routes are under the prefix `/course/agile-agent-workflow`; the table shows the tail. The slug routes are tagged ahead of release, so internal links pass the gates before every target page exists.

## Built — gated A+

| Page | Route tail | Output file | Build key |
| --- | --- | --- | --- |
| Course home / overview | `/` | `agile-agent-workflow.html` | `aaw-course` |
| A0 · Foundations — landing | `/intro` | `agile-agent-workflow-intro.html` | `aaw-a0` |
| A0.2 · What we are building — hub | `/what` | `agile-agent-workflow-what.html` | `aaw-what` |
| A0.2.1 · The two-layer model | `/what/two-layer-model` | `agile-agent-workflow-what-two-layer-model.html` | `aaw-a0-1` |
| A0.2.2 · The four artifacts | `/what/four-artifacts` | `agile-agent-workflow-what-four-artifacts.html` | `aaw-a0-2` |
| A0.2.3 · The Author/Operator loop | `/what/author-operator-loop` | `agile-agent-workflow-what-author-operator-loop.html` | `aaw-a0-3` |
| A0.2.1 deep dive · Anatomy of a `roadmap.md` | `/what/two-layer-model/roadmap-anatomy` | `agile-agent-workflow-what-two-layer-model-roadmap-anatomy.html` | `aaw-a0-1-roadmap` |
| Decomposition — landing | `/decomposition` | `agile-agent-workflow-decomposition.html` | `aaw-a1` |

Eight pages built. The first seven cover the **A0 Foundations** chapter (its landing, the *what* hub, three subpages, and one deep dive). The eighth is the **Decomposition** landing.

## Tagged — route reserved, page not yet built

These routes are in `EXTRA_ROUTES` so links resolve through the gates; the pages return 404 until authored.

| Chapter | Route tail | Maps to TOC |
| --- | --- | --- |
| A1 · Why an Agile Agent Workflow | `/why` | Part I |
| A0.3 · Who | `/who` | foundations front-matter |
| A3 · The roadmap layer | `/roadmap` | Part III |
| A4 · The spec layer | `/spec` | Part IV |
| A5 · The agent brief | `/brief` | Part V |
| A6 · Reliability and correctness | `/reliability` | Part VI |
| A7 · Portal — zero to production | `/portal` | Part VII |

## Planned content beyond the landings

Each chapter resolves into a hub plus per-module subpages, following the abstracts in `abstracts.md` and the lesson lists in the TOC:

- **A0 Foundations** — author the two *soon* modules: A0.1 *Why it works* and A0.3 *Who*. The A0.2 *What* module and its three subpages plus the roadmap-anatomy deep dive are built.
- **A1 Why an Agile Agent Workflow** — chapter landing at `/why`, then its lessons (1.1–1.6) as modules/subpages.
- **A2 Decomposition** — the landing is built; author its modules and subpages (2.1–2.7).
- **A3 The roadmap layer** — landing at `/roadmap`, then 3.1–3.8.
- **A4 The spec layer** — landing at `/spec`, then 4.1–4.7.
- **A5 The agent brief** — landing at `/brief`, then 5.1–5.8.
- **A6 Reliability and correctness** — landing at `/reliability`, then 6.1–6.10.
- **A7 Portal exemplar** — landing at `/portal`, then the seven build steps (7.1–7.7).

## Known follow-ups

- **Numbering reconciliation.** The Decomposition landing is registered under the key `aaw-a1` and titled *A1 — Decomposition* (an earlier scheme). In the home-page narrative it is the second workflow chapter, **A2**, mapping to Part II of the TOC. Reconcile the page's internal label and the build key to A2 when the surrounding chapters are authored.
- **Route overlap at `/why`.** `/why` is currently tagged for the A1 chapter; the A0 foundations landing also speaks of an A0.1 *why it works* module. Decide whether A0.1 gets its own route or folds into the A1 landing before building either.
- **Standing validation suite.** The eight pages are validated with targeted headless checks. Fold them into a single reusable suite (alongside `validator/validator.js`) so `node` over the whole course is one command.
