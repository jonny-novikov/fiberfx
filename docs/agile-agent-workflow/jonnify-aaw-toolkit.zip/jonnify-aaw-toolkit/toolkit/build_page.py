#!/usr/bin/env python3
"""
build_page.py — page builder + Apollo quality gates for the
"Functional Programming in Elixir" course (jonnify dark-editorial system).

The manifest below is the single source of truth. Statuses drive whether the
contents directory renders a *link* (live / built) or a *non-linking card*
(planned / soon). The builder injects the generated contents, the chapter
data for the interactive arc, and a freshly minted branded Snowflake build id
into a hand-authored content fragment, then runs Apollo. Any STATUS: FAIL is a
hard stop.

Commands
    extract-head            write the shared <head> partial to _head.html (run once)
    build  --page KEY       assemble a page from content/<file> -> output, then check
    build  --all            build every registered page
    check  FILE [FILE ...]  run the Apollo gates on existing file(s)
    manifest                print the module manifest
    routes                  print route -> status -> file
    id mint   --ns TSK [--node N] [--seq N] [--at ISO8601]
    id decode BRANDED

Stdlib only. No third-party dependencies.
"""

from __future__ import annotations

import argparse
import html as _html
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# --------------------------------------------------------------------------- #
# Branded Snowflake IDs                                                        #
#   layout : timestamp(41) << 22 | node(10) << 12 | seq(12)                    #
#   epoch  : 2024-01-01T00:00:00Z                                             #
#   id     : <NS:3 chars> + base62(snowflake) left-padded to 11               #
#   example: TSK0KHTOWnGLuC <-> 274557032793636864 <-> 2026-01-27 15:11:37 UTC #
# --------------------------------------------------------------------------- #
EPOCH_MS = 1_704_067_200_000
B62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
B62_WIDTH = 11
TS_SHIFT, NODE_SHIFT = 22, 12
NODE_MASK, SEQ_MASK = 0x3FF, 0xFFF


def b62_encode(n: int, width: int = B62_WIDTH) -> str:
    if n < 0:
        raise ValueError("snowflake must be non-negative")
    if n == 0:
        s = "0"
    else:
        out = []
        while n > 0:
            n, r = divmod(n, 62)
            out.append(B62[r])
        s = "".join(reversed(out))
    return s.rjust(width, "0")


def b62_decode(s: str) -> int:
    n = 0
    for ch in s:
        n = n * 62 + B62.index(ch)
    return n


def snowflake(ts_ms: int, node: int = 0, seq: int = 0) -> int:
    rel = ts_ms - EPOCH_MS
    if rel < 0:
        raise ValueError("timestamp predates the snowflake epoch")
    return (rel << TS_SHIFT) | ((node & NODE_MASK) << NODE_SHIFT) | (seq & SEQ_MASK)


def mint(ns: str, node: int = 0, seq: int = 0, at: datetime | None = None) -> str:
    if len(ns) != 3:
        raise ValueError("namespace prefix must be exactly 3 characters")
    at = at or datetime.now(timezone.utc)
    ts_ms = int(at.timestamp() * 1000)
    return ns + b62_encode(snowflake(ts_ms, node, seq))


def decode(branded: str) -> dict:
    ns, rest = branded[:3], branded[3:]
    snow = b62_decode(rest)
    ts = snow >> TS_SHIFT
    node = (snow >> NODE_SHIFT) & NODE_MASK
    seq = snow & SEQ_MASK
    dt = datetime.fromtimestamp((EPOCH_MS + ts) / 1000, tz=timezone.utc)
    return {
        "branded": branded,
        "namespace": ns,
        "snowflake": snow,
        "node": node,
        "seq": seq,
        "timestamp": dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
    }


# --------------------------------------------------------------------------- #
# Manifest — chapters and modules (single source of truth)                     #
# --------------------------------------------------------------------------- #
# status: live | built (linkable)  ·  planned | soon (non-linking card)
ROOT_ROUTE = "/elixir"

# Agile Agent Workflow (AAW) course - thematic slug routes (tagged ahead of release).
EXTRA_ROUTES = {
    "/course/agile-agent-workflow",
    "/course/agile-agent-workflow/intro",
    "/course/agile-agent-workflow/why",
    "/course/agile-agent-workflow/what",
    "/course/agile-agent-workflow/what/two-layer-model",
    "/course/agile-agent-workflow/what/four-artifacts",
    "/course/agile-agent-workflow/what/author-operator-loop",
    "/course/agile-agent-workflow/what/two-layer-model/roadmap-anatomy",
    "/course/agile-agent-workflow/who",
    "/course/agile-agent-workflow/decomposition",
    "/course/agile-agent-workflow/roadmap",
    "/course/agile-agent-workflow/spec",
    "/course/agile-agent-workflow/brief",
    "/course/agile-agent-workflow/reliability",
    "/course/agile-agent-workflow/portal",
}


CHAPTERS = [
    dict(id='F0', title='History', slug='course', route='/elixir/course',
         status='live',
         one='Where this came from — the languages, the runtimes, and the BEAM.',
         reuses='Context, not a prerequisite. F1 stands on its own.',
         accent='blue'),
    dict(id='F1', title='Algebra', slug='algebra', route='/elixir/algebra',
         status='built',
         one='The functional mindset, straight from the math you already know.',
         reuses='Starts from the algebra you already know.',
         accent='gold'),
    dict(id='F2', title='Functional Programming', slug='functional', route='/elixir/functional',
         status='built',
         one='Pure functions, immutability, and higher-order functions on their own terms.',
         reuses='Builds on F1 · Algebra.',
         accent='elixir'),
    dict(id='F3', title='The Elixir Language', slug='language', route='/elixir/language',
         status='built',
         one='Syntax, pipelines, pattern matching, and structs on the BEAM.',
         reuses='Builds on F2 · Functional Programming.',
         accent='elixir'),
    dict(id='F4', title='Algorithms & Data Structures', slug='algorithms', route='/elixir/algorithms',
         status='built',
         one='Classical and advanced problems, from lists to branded CHAMP tries.',
         reuses='Builds on F3 · The Elixir Language.',
         accent='sage'),
    dict(id='F5', title='Pragmatic Programming', slug='pragmatic', route='/elixir/pragmatic',
         status='built',
         one='Real-world engineering: structure, contracts, CQRS, testing, boundaries.',
         reuses='Builds on F4 · Algorithms & Data Structures.',
         accent='sage'),
    dict(id='F6', title='Phoenix Framework', slug='phoenix', route='/elixir/phoenix',
         status='built',
         one='Web applications on Elixir, and the road into real-time LiveView.',
         reuses='Builds on F5 · Pragmatic Programming.',
         accent='blue'),
]

# modules[chapter_id] -> list of dicts {n,title,one,slug,status,lab,dives?}
MODULES = {
    'F0': [
        dict(n='F0.1', title='The evolution of functional languages & runtimes',
             one='From the lambda calculus to LISP, the ML and Haskell branch, and the immutable turn',
             slug='fp-evolution', status="built", lab=False),
        dict(n='F0.2', title='The evolution of Erlang, the BEAM & OTP',
             one='Telecom roots and “let it crash”, the reduction-counting scheduler and per-process heaps, and the OTP',
             slug='beam-evolution', status="built", lab=False),
    ],
    'F1': [
        dict(n='F1.01', title='What a function really is',
             one='A function as a mapping',
             slug='functions', status="built", lab=False),
        dict(n='F1.02', title='The substitution model',
             one='Equals for equals',
             slug='substitution', status="built", lab=False),
        dict(n='F1.03', title='Composition, f∘g',
             one='Chaining functions into new ones',
             slug='composition', status="built", lab=False),
        dict(n='F1.04', title='Immutability & binding',
             one='A name is a fixed value, not a box',
             slug='immutability', status="built", lab=False),
        dict(n='F1.05', title='Sets, sequences & mappings',
             one='Three shapes of collection',
             slug='collections', status="built", lab=False),
        dict(n='F1.06', title='Recursion & induction',
             one='Base case plus step: the call stack of a recursive sum, why the base case makes it terminate, and induction',
             slug='recursion', status="built", lab=False),
        dict(n='F1.07', title='Higher-order operators (Σ, Π)',
             one='Σ and Π as operators over a function, the map / filter / reduce trio and how each reshapes a collection, and',
             slug='higher-order', status="built", lab=False),
        dict(n='F1.08', title='Equations & pattern matching',
             one='Solving by structure',
             slug='pattern-matching', status="built", lab=False),
        dict(n='F1.09', title='Functions on the plane',
             one='The F1 lab',
             slug='plotting-lab', status="built", lab=True),
    ],
    'F2': [
        dict(n='F2.01', title='Pure functions & side effects',
             one='What purity buys and how to keep it',
             slug='pure', status="built", lab=False),
        dict(n='F2.02', title='Immutability & persistent data',
             one='Why copying is cheap',
             slug='persistence', status="built", lab=False),
        dict(n='F2.03', title='Higher-order functions',
             one='Functions as values',
             slug='higher-order', status="built", lab=False),
        dict(n='F2.04', title='Recursion patterns & tail calls',
             one='Recursion as the functional way to repeat',
             slug='recursion', status="built", lab=False),
        dict(n='F2.05', title='map / filter / reduce (folds)',
             one='reduce as the universal fold',
             slug='folds', status="built", lab=False),
        dict(n='F2.06', title='Closures & partial application',
             one='A closure is a function plus the environment it captured.',
             slug='closures', status="built", lab=False),
        dict(n='F2.07', title='Algebraic data types',
             one='The algebra of types',
             slug='adt', status="built", lab=False),
        dict(n='F2.08', title='Composition & pipelines',
             one='Building programs by combining functions',
             slug='composition', status="built", lab=False),
        dict(n='F2.09', title='The data-pipeline lab',
             one='The F2 capstone',
             slug='pipeline-lab', status="built", lab=True),
    ],
    'F3': [
        dict(n='F3.01', title='Values, types & IEx',
             one='The data Elixir is built from',
             slug='values', status="built", lab=False),
        dict(n='F3.02', title='Pattern matching & the match operator',
             one='Pattern matching is how Elixir reads the shape of data and pulls it apart.',
             slug='match', status="built", lab=False),
        dict(n='F3.03', title='Functions, modules & the pipe',
             one='Functions are the unit of work, modules group them, and the pipe composes them.',
             slug='modules', status="built", lab=False),
        dict(n='F3.04', title='Enumerables & streams',
             one='A collection is anything that implements the Enumerable protocol; Enum walks it eagerly, and Stream walks it lazily.',
             slug='enum-streams', status="built", lab=False),
        dict(n='F3.05', title='Structs, maps & keyword lists',
             one='Three containers for key-and-value data',
             slug='structs', status="built", lab=False),
        dict(n='F3.06', title='Protocols & behaviours',
             one='Two kinds of polymorphism in Elixir',
             slug='protocols', status="built", lab=False),
        dict(n='F3.07', title='Processes & the actor model',
             one="A process is the BEAM's isolated unit of concurrency, coordinating only by messages",
             slug='processes', status="built", lab=False),
        dict(n='F3.08', title='OTP: GenServer & supervisors',
             one='OTP wraps the actor model in tested patterns',
             slug='otp', status="built", lab=False),
        dict(n='F3.09', title='The process playground',
             one='The F3 capstone lab: a live supervised tree you drive',
             slug='playground', status="built", lab=True),
    ],
    'F4': [
        dict(n='F4.01', title='Lists, recursion & complexity',
             one='The BEAM list is a linked list of cons cells, not an array',
             slug='lists', status="built", lab=False),
        dict(n='F4.02', title='Trees & traversals',
             one='A binary tree is a cons cell with two pointers: a node is {value, left, right} or nil.',
             slug='trees', status="built", lab=False),
        dict(n='F4.03', title='Sorting & searching',
             one='Sorting and searching are two halves of one bargain',
             slug='sorting', status="built", lab=False),
        dict(n='F4.04', title='Maps, sets & hashing',
             one='The course you are reading runs on Phoenix LiveView, and its data layer is built from these structures',
             slug='maps', status="built", lab=False),
        dict(n='F4.05', title='Hash array mapped tries',
             one='A HAMT spreads a hash table over a tree',
             slug='hamt', status="built", lab=False),
        dict(n='F4.06', title='CHAMP maps',
             one='A CHAMP is the compressed successor to the HAMT',
             slug='champ', status="built", lab=False),
        dict(n='F4.07', title='Identifiers, Snowflake & branded ids',
             one='Every record in the portal needs a name.',
             slug='identifiers', status="built", lab=False),
        dict(n='F4.08', title='Branded ids & persistence',
             one='A branded Snowflake is the key everywhere the portal stores data',
             slug='persistence', status="built", lab=False),
        dict(n='F4.09', title='Branded CHAMP maps & GenServer',
             one='The chapter folds together',
             slug='branded-champ', status="built", lab=False),
        dict(n='F4.10', title='Practical recipes in Elixir',
             one="The chapter's structures turned into the Portal's everyday code through three recurring recipes",
             slug='recipes', status="built", lab=False),
        dict(n='F4.11', title='Dynamic programming & advanced problems',
             one='Dynamic programming solves a problem with overlapping subproblems by solving each once and reusing it, in two',
             slug='dynamic-programming', status="built", lab=False),
        dict(n='F4.12', title='Lab: build a branded CHAMP store',
             one='The capstone lab assembles the chapter into one Portal.Store',
             slug='lab', status="built", lab=True),
    ],
    'F5': [
        dict(n='F5.01', title='Start thin: a running Portal from day one',
             one='Pragmatic programming starts with a system that runs.',
             slug='foundations', status="built", lab=False),
        dict(n='F5.02', title='Modeling the Portal domain',
             one='The engine needs a shape before it needs behavior.',
             slug='domain', status="built", lab=False),
        dict(n='F5.03', title='Tracer bullets: a walking skeleton',
             one='With a running server and a domain model in hand, F5.03 wires them together by driving one use case',
             slug='tracer-bullets', status="built", lab=False),
        dict(n='F5.04', title='Design by contract',
             one='Every command on the engine carries a contract',
             slug='contracts', status="built", lab=False),
        dict(n='F5.05', title='Commands, queries & events',
             one='With the enroll command now contract-checked, F5.05 formalizes how the engine handles change',
             slug='cqrs', status="built", lab=False),
        dict(n='F5.06', title='Where engine state lives',
             one='The F5.05 fold is pure: it computes the current state from the event log and forgets it.',
             slug='state', status="built", lab=False),
        dict(n='F5.07', title='Pragmatic testing',
             one='The engine was built to be tested',
             slug='testing', status="built", lab=False),
        dict(n='F5.08', title='Boundaries & integration seams',
             one='The engine works, but its callers still have to know it is a process with message shapes and a chosen store.',
             slug='boundaries', status="built", lab=False),
        dict(n='F5.09', title='Lab: the Portal engine, LiveView-ready',
             one='The finale assembles eight modules into one running Portal',
             slug='engine-lab', status="built", lab=True),
    ],
    'F6': [
        dict(n='F6.01', title='Architecture & the request lifecycle',
             one='How a request travels through Phoenix and where it meets the F5 engine',
             slug='lifecycle', status="built", lab=False),
        dict(n='F6.02', title='Routing, controllers & plugs',
             one='The plug pipeline that carries a request to a controller',
             slug='routing', status="built", lab=False),
        dict(n='F6.03', title='Ecto: schemas, changesets & queries',
             one='Ecto in three pieces',
             slug='ecto', status="built", lab=False),
        dict(n='F6.04', title='Contexts & domain design',
             one='A context is a dedicated module that groups related functionality behind a public API and hides its schemas',
             slug='contexts', status="built", lab=False),
        dict(n='F6.05', title='Templates, components & HEEx',
             one='HEEx is the view half of the request a controller returns',
             slug='heex', status="built", lab=False),
        dict(n='F6.06', title='Phoenix LiveView fundamentals',
             one='LiveView makes the F6.05 templates live',
             slug='liveview', status="built", lab=False),
        dict(n='F6.07', title='PubSub, channels & real-time',
             one='PubSub turns one LiveView into many that update together',
             slug='pubsub', status="built", lab=False),
        dict(n='F6.08', title='Auth, deployment & going live',
             one='Taking the whole application to production',
             slug='deployment', status="built", lab=False),
        dict(n='F6.09', title='The live dashboard',
             one='The capstone lab: a real-time operations dashboard that converges the whole course.',
             slug='live-dashboard', status="built", lab=True),
    ],
}

LINKABLE = {"live", "built"}


SUBPAGES = {
    # A module can have deep-dive subpages. Their routes become linkable once the
    # parent module itself is linkable. Subpages are NOT counted as modules.
    'F4.01': [
        dict(slug='big-o', title='Complexity & big-O on the BEAM', one='Big-O for a list is concrete: count the cons cells an operation touches.'),
        dict(slug='cons', title='Cons cells & the shape of a list', one='A cons cell is a head and a tail pointer.'),
        dict(slug='recursion', title='Recursion over lists', one='You walk a list by recursion, not a loop: match [h | t], act on the head, recurse on the tail, and stop at [].'),
    ],
    'F6.01': [
        dict(slug='controllers', title='Controllers, views & the facade seam', one='Where your code lives in the lifecycle'),
        dict(slug='endpoint', title='The endpoint, supervised', one='PortalWeb.Endpoint has two roles: the outermost plug'),
        dict(slug='request-path', title='The request lifecycle', one='A request from the browser to the response, step by step'),
    ],
    'F5.01': [
        dict(slug='replaceable', title='A web layer built for replacement', one='The thin server is a detail, by design.'),
        dict(slug='roadmap', title='The development roadmap', one='The whole course is one development roadmap'),
        dict(slug='thin-server', title='A thin web server in Elixir', one='A minimal HTTP front end for the Portal'),
    ],
    'F4.02': [
        dict(slug='bfs', title='Breadth-first & balance', one='Breadth-first traversal walks the tree level by level with a FIFO queue.'),
        dict(slug='dfs', title='Depth-first: pre, in, post-order', one='Depth-first traversal makes the same two recursive calls and differs only in when it visits the node'),
        dict(slug='shape', title='Binary trees & recursive shape', one='A node is {value, left, right} or nil, so every tree function handles nil as the base case and a node by'),
    ],
    'F3.02': [
        dict(slug='branching', title='Branching with case, with & guards', one='Dispatching on shape: function-head matching, case, guards, and the with pipeline'),
        dict(slug='destructuring', title='Destructuring portal data', one='Pulling fields out of tuples, lists, maps, and structs in a single match'),
        dict(slug='operator', title='The match operator', one='= asserts that a value matches a pattern and binds the rest'),
    ],
    'F6.02': [
        dict(slug='pipelines', title='Pipelines & scopes', one='A named pipeline is a reusable, ordered stack of plugs; a scope runs a group of routes through one with pipe_through.'),
        dict(slug='plugs', title='Writing a plug', one='The contract every stage of the pipeline shares'),
        dict(slug='routes', title='Routes & verbs', one='How a verb and a path map to one controller action'),
    ],
    'F5.02': [
        dict(slug='api', title="A context's public API", one='Each context exposes a small set of public functions'),
        dict(slug='contexts', title='Bounded contexts', one='A bounded context is a module that owns a few entities and guards their rules'),
        dict(slug='structs', title='Structs & typespecs', one='An entity is a plain struct'),
    ],
    'F4.03': [
        dict(slug='cost', title='Stability & sort cost', one='Sorts are ranked on average, worst case, space, and stability — whether equal keys keep their order.'),
        dict(slug='search', title='Linear & binary search', one='Linear search checks elements one by one over any sequence — O(n).'),
        dict(slug='sorts', title='Merge & quicksort', one='The two workhorse comparison sorts are both divide-and-conquer.'),
    ],
    'F3.03': [
        dict(slug='functions', title='Defining functions', one='Named functions with def and defp, multiple clauses that dispatch by pattern and guard, arity, anonymous'),
        dict(slug='organising', title='Organising with modules', one='defmodule, module attributes, alias and import, and documentation'),
        dict(slug='pipe', title='The pipe operator', one='|> threads a value as the first argument to the next call, turning nested calls into a readable pipeline'),
    ],
    'F6.03': [
        dict(slug='changesets', title='Changesets & validation', one='A changeset is a pure pipeline'),
        dict(slug='repo', title='Queries & the repo', one='The Repo executes composable Ecto queries and persists changesets'),
        dict(slug='schemas', title='Schemas & migrations', one='A migration creates and evolves a database table'),
    ],
    'F5.03': [
        dict(slug='iterating', title='Iterating the slice', one='Once the skeleton walks, you grow it one thin vertical slice at a time'),
        dict(slug='prototypes', title='Tracer bullets vs prototypes', one='Both are built fast, but their fates are opposite.'),
        dict(slug='skeleton', title='The walking skeleton', one='The enroll-a-learner slice, end to end'),
    ],
    'F4.04': [
        dict(slug='hashing', title='Hashing & collisions', one='Maps and sets reach O(1) by hashing'),
        dict(slug='lookup', title='Maps & key lookup', one='A map associates keys with values and looks one up in effectively constant time.'),
        dict(slug='sets', title='MapSet & membership', one='A MapSet stores unique elements and answers membership in O(1).'),
    ],
    'F2.04': [
        dict(slug='patterns', title='Recursion patterns', one='sum, length, reverse, map, and filter written recursively — and why each one is a fold over the list.'),
        dict(slug='shape', title='The shape of recursion', one='Base case and recursive case, and the call stack growing then unwinding as a body-recursive function runs to a result.'),
        dict(slug='tail-calls', title='Tail calls & accumulators', one='Body versus tail recursion, the accumulator pattern, and how a tail call reuses the stack frame to run in'),
    ],
    'F3.04': [
        dict(slug='comprehensions', title='Comprehensions', one='The for comprehension'),
        dict(slug='enum', title='Enum, the eager workhorse', one='The Enumerable protocol unifies lists, ranges, maps, and streams, and the Enum module is the toolkit that'),
        dict(slug='streams', title='Lazy streams', one='Stream builds a lazy recipe that computes nothing until an Enum function pulls values through'),
    ],
    'F6.04': [
        dict(slug='boundaries', title='Context boundaries', one='A context groups related functionality behind a public API and keeps its schemas and the Repo private.'),
        dict(slug='composition', title='Composing contexts', one='How one context depends on another without breaking boundaries'),
        dict(slug='vs-facade', title='Contexts vs the F5 facade', one='A Phoenix context and the F5 Portal facade are the same idea — a public API over a slice of the domain.'),
    ],
    'F5.04': [
        dict(slug='assertions', title='Assertions in Elixir', one='Elixir has no design-by-contract keywords, so contracts are written in its idioms'),
        dict(slug='conditions', title='Preconditions, postconditions & invariants', one='A contract has three parts and three owners.'),
        dict(slug='fail-fast', title='Failing fast', one='Check at the boundary and stop on the first violation, before the struct is built or the store is touched.'),
    ],
    'F4.05': [
        dict(slug='bitmap', title='Bitmapped nodes', one='A HAMT node keeps one 32-bit bitmap marking which of its slots are occupied and one packed array holding only'),
        dict(slug='indexing', title='Hash-prefix indexing', one="A HAMT reads the key's hash in five-bit chunks from the low end"),
        dict(slug='sharing', title='Structural sharing', one='An insert builds new nodes only along the path from the root to the changed leaf and shares every other'),
    ],
    'F2.05': [
        dict(slug='advanced', title='Advanced folds', one='The Enum toolkit as folds with extra structure'),
        dict(slug='filter', title='filter', one='Keeping elements that pass a predicate: filter and its inverse reject, and filtering then mapping as a pipeline.'),
        dict(slug='map', title='map', one='Transforming every element with a function'),
        dict(slug='reduce', title='reduce', one='The general fold: accumulators of any shape — numbers, lists, maps — and building a frequency map step by step.'),
    ],
    'F3.05': [
        dict(slug='defaults', title='Enforcing keys & defaults', one='@enforce_keys for required fields and keyword defaults in defstruct'),
        dict(slug='define', title='Defining a struct', one='defstruct over Portal.Accounts.User'),
        dict(slug='matching', title="Matching on a struct's type", one='The %Struct{} pattern dispatches on the __struct__ tag across function clauses'),
    ],
    'F6.05': [
        dict(slug='components', title='Function components & slots', one='A function component is a pure function from assigns to markup, declared with attr and slot so its inputs are'),
        dict(slug='forms', title='Forms & inputs', one='A form is a changeset turned into a form with to_form/1.'),
        dict(slug='templates', title='Templates & assigns', one='A HEEx template renders the assigns a controller set'),
    ],
    'F5.05': [
        dict(slug='cqs', title='Command/query separation', one='Command/query separation is one rule'),
        dict(slug='events', title='Domain events', one='Model every change as a past-tense fact: %LearnerEnrolled{}, %LessonDelivered{}, %ProgressRecorded{}.'),
        dict(slug='reducer', title='The engine as a reducer', one='State is not stored so much as derived'),
    ],
    'F4.06': [
        dict(slug='equality', title='Canonical equality', one='CHAMP maintains one canonical shape per set of entries, so two equal maps are structurally identical trees'),
        dict(slug='iteration', title='Cache-friendly iteration', one='Because a CHAMP node keeps its entries contiguous and separate from sub-node pointers, iteration walks the'),
        dict(slug='layout', title='Compressed node layout', one='A CHAMP node carries a datamap and a nodemap'),
    ],
    'F2.06': [
        dict(slug='capture', title='The capture operator', one='The & shorthand for anonymous functions'),
        dict(slug='currying', title='Partial application & currying', one='Fixing arguments to specialise a function, and building curried functions by hand — applying arguments one at a time.'),
        dict(slug='environment', title='Capturing the environment', one='What a closure captures and when'),
    ],
    'F3.06': [
        dict(slug='behaviours', title='Behaviours & callbacks', one='@callback declares a typed contract on a module'),
        dict(slug='defimpl', title='Implementing for a struct', one='defimpl Protocol, for'),
        dict(slug='define', title='Defining a protocol', one='defprotocol declares a contract of function signatures'),
    ],
    'F6.06': [
        dict(slug='events', title='handle_event & state', one='Bindings like phx-click, phx-change, and phx-submit send events to handle_event/3, which transforms the'),
        dict(slug='mount', title='mount & assigns', one='A LiveView is a stateful process connected to the browser over a socket.'),
        dict(slug='render', title='render & diffs', one='render/1 returns HEEx from the assigns, and LiveView tracks which assigns changed to send only those values'),
    ],
    'F5.06': [
        dict(slug='choosing', title='Choosing where state lives', one='Three holders for live state on the BEAM are not interchangeable'),
        dict(slug='genserver', title='The engine GenServer', one='Three callbacks carry the engine.'),
        dict(slug='supervision', title='Supervision', one='Let it crash: a process holding state will eventually fail, so a supervisor sits above the engine and restarts it.'),
    ],
    'F4.07': [
        dict(slug='branded', title='Branded ids', one='A branded id encodes the 64-bit Snowflake in base62 over 0-9A-Za-z, left-pads it to eleven characters, and'),
        dict(slug='choosing', title='Choosing an identifier', one='An auto-increment counter is ordered and tiny but needs one writer, so it cannot scale across machines'),
        dict(slug='snowflake', title='The Snowflake bigint', one='A Snowflake packs three fields into 64 bits'),
    ],
    'F2.07': [
        dict(slug='matching', title='Pattern matching on data', one='Taking algebraic data apart'),
        dict(slug='product', title='Product types', one='Tuples and structs'),
        dict(slug='sum', title='Sum types', one='Tagged tuples and variants'),
    ],
    'F3.07': [
        dict(slug='messages', title='Sending & receiving messages', one='send/2 appends a term to a mailbox and returns'),
        dict(slug='spawn', title='Spawning a process', one='spawn/1 starts a function as a new process and returns a PID at once'),
        dict(slug='state', title='Holding state in a loop', one='A process holds state as the argument to a recursive receive loop, tail-calling itself with the updated value'),
    ],
    'F6.07': [
        dict(slug='broadcast', title='Broadcasting engine events', one='Phoenix.PubSub is process-to-process publish/subscribe over a string topic.'),
        dict(slug='presence', title='Channels & presence', one='Channels are the lower-level real-time primitive LiveView is built on, with explicit join and handle_in for'),
        dict(slug='subscribe', title='Subscribing a LiveView', one='A LiveView subscribes to a topic on its connected mount and receives broadcasts in handle_info/2'),
    ],
    'F5.07': [
        dict(slug='contract-tests', title='Contract tests', one='The F5.04 contract written as tests'),
        dict(slug='property', title='Property-based testing', one='State a property true for every valid input and let StreamData generate hundreds of cases, shrinking any'),
        dict(slug='pure-core', title='Testing the pure core', one='decide, evolve, and replay are pure functions, so a test is three lines'),
    ],
    'F4.08': [
        dict(slug='keys', title='Branded ids as keys', one='The database stores the 64-bit integer as a bigint primary key'),
        dict(slug='redis', title='Redis keys', one='In Redis the id is a namespaced string key, user:USR0NbWMtkosp8.'),
        dict(slug='sql', title='SQLite & PostgreSQL', one='Because the high bits of the id are a timestamp, a window of time is a contiguous window of ids'),
    ],
    'F2.08': [
        dict(slug='compose', title='Function composition', one='Composing functions by hand — f after g — why the order matters, and chaining three together.'),
        dict(slug='pipe', title='The pipe operator', one='The |> operator'),
        dict(slug='pipeline', title='Building pipelines', one='Composing map, filter, and reduce into a pipeline over a dataset, watching the value transform at each stage.'),
    ],
    'F3.08': [
        dict(slug='call-cast', title='Synchronous call, asynchronous cast', one='GenServer.call sends a request and blocks for the reply, routing to handle_call'),
        dict(slug='genserver', title='The GenServer behaviour', one='A GenServer abstracts the receive loop into a behaviour'),
        dict(slug='supervisors', title='Supervisors & restart strategies', one='A supervisor starts child processes and restarts them when they crash, by strategy'),
    ],
    'F6.08': [
        dict(slug='auth', title='Sessions & authentication', one='mix phx.gen.auth generates an Accounts context, a User schema, and the session plumbing.'),
        dict(slug='deploy', title='Deploying to production', one='The deploy is build, migrate, boot'),
        dict(slug='releases', title='Releases & config', one='mix release packages the app, its dependencies, and the BEAM into one self-contained artifact.'),
    ],
    'F5.08': [
        dict(slug='errors', title='Error contracts for the UI', one='Failure is part of the contract'),
        dict(slug='facade', title='The engine facade', one='The driving port: a small context module'),
        dict(slug='ports', title='Ports & adapters', one='A port is an Elixir behaviour the core depends on'),
    ],
    'F4.09': [
        dict(slug='genserver', title='Own it with a GenServer', one="The Portal's session store is a CHAMP behind a GenServer."),
        dict(slug='partition', title='Partition by namespace', one="The Portal's entity registry keeps users, sessions, lessons, and pages in one store"),
        dict(slug='trie', title='Structural sharing', one="Inside a partition the CHAMP is keyed on the lesson's Snowflake, and Portal.Progress marks a lesson complete"),
    ],
    'F6.09': [
        dict(slug='build', title='Build the dashboard', one='The dashboard is a LiveView that holds a read model on its socket'),
        dict(slug='multi-client', title='Many clients, live', one='One broadcast reaches every connected dashboard at once, so all viewers update together, and Presence reports'),
        dict(slug='stream', title='Broadcast engine events', one='The domain emits events after a write (F6.07) and the dashboard subscribes to the topic on its connected mount.'),
    ],
    'F5.09': [
        dict(slug='end-to-end', title='The engine facade end to end', one='The full supervision tree'),
        dict(slug='handoff', title='What ships in F6', one='The handoff'),
        dict(slug='mount', title='A LiveView mount sketch', one='A LiveView that touches only the facade'),
    ],
    'F4.10': [
        dict(slug='patterns', title='Idiomatic patterns', one='A request to view a lesson clears four gates'),
        dict(slug='pipelines', title='Streams & pipelines', one='The activity feed wants the three most recent completions for a course.'),
        dict(slug='profiling', title='Profiling & complexity', one='Every request finds an active session.'),
    ],
    'F4.11': [
        dict(slug='memoization', title='Memoization & overlapping subproblems', one='The longest prerequisite chain to a lesson is one plus the deepest of its prerequisites — a recursion.'),
        dict(slug='problems', title='Classic DP problems', one='Edit distance'),
        dict(slug='tabulation', title='Tabulation & bottom-up', one='The fewest modules (worth 1, 3, or 4 credits) summing to a target is one more than the best answer for the'),
    ],
    'F4.12': [
        dict(slug='grow', title='Watch a branded CHAMP grow', one="Each put reads a branded id's three-letter namespace and drops the entry into that namespace's partition,"),
        dict(slug='range', title='Query by time range', one='Because a Snowflake puts the timestamp in its high bits, ids sort by creation time and a time window becomes'),
        dict(slug='registry', title='A Snowflake registry', one='Hand the store any branded id and get/1 resolves it in one call'),
    ],
}


CHAPTER_SUBPAGES = {
    # A chapter can have front-matter subpages (intro material at the chapter route,
    # not under any module). Linkable once the chapter is linkable; not counted as
    # modules.
    'F0': [
        dict(slug='csharp', title='Elixir for C# developers', one='A bridge from .NET to the BEAM'),
    ],
    'F3': [
        dict(slug='history', title='A short history of Elixir', one='Why José Valim built Elixir on the Erlang VM in 2011, what it inherited from Erlang, Ruby, and Clojure, and'),
        dict(slug='timeline', title='The Elixir release timeline', one="An interactive timeline of Elixir's milestones, from the first commit in 2011 to the current stable release,"),
        dict(slug='under-the-hood', title='Under the hood', one='How Elixir source becomes BEAM bytecode'),
    ],
    'F5': [
        dict(slug='architecture', title='The Portal engine blueprint', one='The system this chapter builds, at a glance'),
        dict(slug='domain-model', title='The domain model', one='The data the Portal engine owns: three bounded contexts'),
        dict(slug='flow', title='The command & event flow', one='How one use case moves through the engine'),
    ],
    'F6': [
        dict(slug='blueprint', title="What we're building", one='The Portal as a real learning platform: browse, enroll, lessons, live progress, and a dashboard.'),
        dict(slug='journey', title='The developer journey', one='The path F6 walks, from the F5 facade to a deployed, real-time learning platform, in four arcs'),
        dict(slug='wiring', title='Wiring Phoenix onto the F5 engine', one='The seam the chapter turns on, in code'),
    ],
}


def _module_route(mid: str):
    for ch in CHAPTERS:
        for m in MODULES[ch["id"]]:
            if m["n"] == mid:
                return f'{ch["route"]}/{m["slug"]}', m["status"]
    return None, None


def subpages_of(mid: str):
    """(route, title, one) for each subpage of a module."""
    mroute, _ = _module_route(mid)
    if not mroute:
        return []
    return [(f'{mroute}/{s["slug"]}', s["title"], s["one"]) for s in SUBPAGES.get(mid, [])]


def chapter_subpages_of(cid: str):
    """(route, title, one) for each front-matter subpage of a chapter."""
    chapter = next((c for c in CHAPTERS if c["id"] == cid), None)
    if not chapter:
        return []
    return [(f'{chapter["route"]}/{s["slug"]}', s["title"], s["one"]) for s in CHAPTER_SUBPAGES.get(cid, [])]


def allowed_routes() -> set[str]:
    routes = {ROOT_ROUTE}
    routes |= EXTRA_ROUTES
    for ch in CHAPTERS:
        if ch["status"] in LINKABLE:
            routes.add(ch["route"])
    for cid, mods in MODULES.items():
        chapter = next(c for c in CHAPTERS if c["id"] == cid)
        for m in mods:
            if m["status"] in LINKABLE:
                routes.add(f'{chapter["route"]}/{m["slug"]}')
    # subpages of a module are linkable once the parent module is linkable
    for mid in SUBPAGES:
        mroute, mstatus = _module_route(mid)
        if mroute and mstatus in LINKABLE:
            for s in SUBPAGES[mid]:
                routes.add(f'{mroute}/{s["slug"]}')
    # front-matter subpages of a chapter are linkable once the chapter is linkable
    for cid in CHAPTER_SUBPAGES:
        chapter = next((c for c in CHAPTERS if c["id"] == cid), None)
        if chapter and chapter["status"] in LINKABLE:
            for s in CHAPTER_SUBPAGES[cid]:
                routes.add(f'{chapter["route"]}/{s["slug"]}')
    return routes


def module_count() -> int:
    # The six numbered chapters (F1–F6) are the course spine. Five carry nine
    # modules; F4 (Algorithms) carries twelve — 57 in all. The optional F0 history
    # chapter is surfaced separately, so it is not folded into this figure (that is
    # what the landing copy promises).
    return sum(len(MODULES[ch["id"]]) for ch in CHAPTERS if ch["id"] != "F0")


# --------------------------------------------------------------------------- #
# Shared head — jonnify dark-editorial design tokens + base CSS                 #
# --------------------------------------------------------------------------- #
HEAD_CSS = """
:root{
  --ink:#0a0e1a; --ink-2:#10162b; --ink-3:#161d38;
  --cream:#ece4d0; --cream-soft:#d7cfb9; --cream-dim:#a39c89;
  --gold:#d4a85a; --gold-bright:#f0cd7f;
  --blue:#5a87c4; --blue-bright:#9fc0ea;
  --sage:#7ba387; --sage-bright:#a7c9b1;
  --burgundy:#c4504c;
  --elixir:#b39ddb; --elixir-bright:#cdb8f0;
  --line:#2a3252;
  --serif-display:"Cormorant Garamond", Georgia, "Times New Roman", serif;
  --serif:"PT Serif", Georgia, serif;
  --sans:"Manrope", ui-sans-serif, system-ui, sans-serif;
  --mono:"JetBrains Mono", ui-monospace, "SF Mono", Menlo, monospace;
  --measure:68ch;
}
*{box-sizing:border-box}
html{font-size:16px;-webkit-text-size-adjust:100%;scroll-behavior:smooth}
@media (prefers-reduced-motion: reduce){html{scroll-behavior:auto}}
body{
  margin:0; color:var(--cream); background:var(--ink);
  font-family:var(--serif);
  font-size:clamp(1.02rem,0.97rem+0.28vw,1.18rem);
  line-height:1.62; letter-spacing:.005em;
  background-image:
    radial-gradient(1100px 560px at 50% -8%, rgba(179,157,219,.12), transparent 60%),
    radial-gradient(820px 460px at 88% 4%, rgba(212,168,90,.07), transparent 56%),
    radial-gradient(900px 700px at 8% 22%, rgba(90,135,196,.06), transparent 60%);
  background-attachment:fixed;
}
body::after{ /* faint vignette for depth */
  content:""; position:fixed; inset:0; pointer-events:none; z-index:0;
  box-shadow:inset 0 0 240px 40px rgba(4,6,14,.55);
}
.skip{position:absolute;left:-9999px;top:0;background:var(--gold);color:var(--ink);
  padding:.6rem 1rem;border-radius:0 0 10px 0;font-family:var(--sans);font-weight:600;z-index:50}
.skip:focus{left:0}
::selection{background:var(--gold);color:var(--ink)}
img,svg{max-width:100%}
a{color:var(--gold-bright);text-decoration:none}
a:hover{color:var(--cream)}
hr.rule{border:0;height:1px;margin:2.2rem 0;
  background:linear-gradient(90deg,transparent,var(--gold) 18%,var(--gold) 82%,transparent)}

/* ---- layout ---- */
.wrap{max-width:1080px;margin:0 auto;padding:0 clamp(1.1rem,3vw,2.4rem);position:relative;z-index:1}
main{display:block}
section{padding:clamp(2.6rem,6vw,4.6rem) 0}
section + section{border-top:1px solid var(--line)}
.prose{max-width:var(--measure)}
.prose p{margin:0 0 1.05rem}

/* ---- type ---- */
h1,h2,h3,h4{font-family:var(--serif-display);font-weight:600;line-height:1.04;
  letter-spacing:-.01em;color:var(--cream);margin:0 0 .5em}
h1{font-size:clamp(2.7rem,1.9rem+4.2vw,5.1rem);font-weight:600}
h1 .ex{color:var(--elixir-bright);font-style:italic;font-weight:500}
h2{font-size:clamp(1.85rem,1.3rem+1.9vw,2.7rem)}
h3{font-size:clamp(1.3rem,1.1rem+.6vw,1.6rem)}
.eyebrow{font-family:var(--sans);font-weight:600;font-size:.72rem;
  text-transform:uppercase;letter-spacing:.24em;color:var(--gold);
  display:inline-flex;align-items:center;gap:.6rem;margin:0 0 1rem}
.eyebrow::before{content:"";width:26px;height:1px;background:var(--gold);display:inline-block}
.lede{font-family:var(--serif-display);font-weight:500;font-style:italic;
  font-size:clamp(1.25rem,1rem+1vw,1.7rem);line-height:1.32;color:var(--cream-soft);
  max-width:46ch;margin:0 0 1.6rem}
.kicker{font-family:var(--sans);color:var(--cream-dim);font-size:.95rem;max-width:var(--measure)}
.math{font-family:var(--serif);font-style:italic;color:var(--elixir-bright);white-space:nowrap}
strong{color:var(--cream);font-weight:700}

/* ---- site header / footer ---- */
.site{position:sticky;top:0;z-index:30;backdrop-filter:blur(9px);
  background:rgba(10,14,26,.74);border-bottom:1px solid var(--line)}
.site .wrap{display:flex;align-items:center;justify-content:space-between;
  height:58px;font-family:var(--sans)}
.brand{display:inline-flex;align-items:baseline;gap:.5rem;font-family:var(--serif-display);
  font-size:1.32rem;font-weight:600;color:var(--cream);letter-spacing:.01em}
.brand .dot{width:7px;height:7px;border-radius:50%;background:var(--gold);
  display:inline-block;transform:translateY(-2px)}
.brand .sub{font-family:var(--sans);font-size:.66rem;letter-spacing:.22em;
  text-transform:uppercase;color:var(--cream-dim)}
.site nav a{font-size:.82rem;color:var(--cream-soft);letter-spacing:.04em}
.route-tag{font-family:var(--mono);font-size:.78rem;color:var(--gold);
  border:1px solid var(--line);border-radius:999px;padding:.2rem .7rem}
.site-foot{border-top:1px solid var(--line);background:rgba(8,11,22,.6);
  font-family:var(--sans);color:var(--cream-dim);font-size:.86rem}
.site-foot .wrap{padding-top:2.4rem;padding-bottom:3rem;display:flex;
  flex-wrap:wrap;gap:1.4rem 2.4rem;justify-content:space-between;align-items:flex-start}

/* ---- hero ---- */
.hero{padding-top:clamp(3rem,8vw,6rem)}
.hero .cta-row{display:flex;flex-wrap:wrap;gap:.8rem;margin-top:1.7rem}
.btn{font-family:var(--sans);font-weight:600;font-size:.92rem;letter-spacing:.02em;
  display:inline-flex;align-items:center;gap:.55rem;padding:.72rem 1.25rem;border-radius:12px;
  border:1px solid var(--gold);color:var(--ink);background:var(--gold);
  transition:transform .18s ease, box-shadow .18s ease, background .18s ease}
.btn:hover{background:var(--gold-bright);color:var(--ink);transform:translateY(-2px);
  box-shadow:0 10px 30px -12px rgba(212,168,90,.6)}
.btn.ghost{background:transparent;color:var(--gold-bright);border-color:var(--line)}
.btn.ghost:hover{border-color:var(--gold);color:var(--cream);box-shadow:none}
.hero-motif{margin-top:2.4rem;width:100%;height:auto;display:block;opacity:.9}

/* ---- figures / takeaways ---- */
.fig{margin:1.8rem 0 0;border:1px solid var(--line);border-radius:16px;
  background:linear-gradient(180deg,rgba(16,22,43,.6),rgba(10,14,26,.35));
  padding:clamp(1rem,2.4vw,1.6rem)}
.fig svg{display:block;width:100%;height:auto}
.take{margin:1.1rem 0 0;font-family:var(--serif-display);font-style:italic;
  font-size:1.18rem;line-height:1.35;color:var(--cream-soft);
  padding-left:1rem;border-left:2px solid var(--gold)}

/* ---- interactive shells (shared with lesson pages) ---- */
.solid-select{display:flex;flex-wrap:wrap;gap:.5rem}
.solid-select button{font-family:var(--sans);font-weight:600;font-size:.84rem;
  cursor:pointer;padding:.5rem .9rem;border-radius:10px;color:var(--cream-soft);
  background:var(--ink-2);border:1px solid var(--line);transition:.16s ease}
.solid-select button:hover{border-color:var(--cream-dim)}
.solid-select button.active{color:var(--ink);background:var(--cream-soft);border-color:transparent;font-weight:700}
.solid-select button.active[data-c="blue"]{background:var(--blue-bright)}
.solid-select button.active[data-c="sage"]{background:var(--sage-bright)}
.solid-select button.active[data-c="gold"]{background:var(--gold-bright)}
.solid-select button.active[data-c="elixir"]{background:var(--elixir-bright)}
.fold-ctrl{display:flex;align-items:center;gap:1rem;margin:.2rem 0;font-family:var(--sans)}
.fold-ctrl label{min-width:7.5rem;font-size:.86rem;color:var(--cream-soft);letter-spacing:.03em}
.fold-ctrl input[type=range]{flex:1;accent-color:var(--gold);height:2px}
.fold-ctrl .val{font-family:var(--mono);color:var(--gold-bright);min-width:2.5rem;text-align:right}
.geo-readout{font-family:var(--mono);font-size:.95rem;color:var(--gold-bright);
  background:var(--ink);border:1px solid var(--line);border-radius:10px;
  padding:.7rem .9rem;margin-top:1rem;white-space:normal;overflow-wrap:break-word;word-break:break-word}
.geo-readout .dim{color:var(--cream-dim)}
.controls{display:flex;flex-wrap:wrap;gap:1.4rem 2rem;align-items:center;margin-bottom:1rem}

/* ---- code ---- */
pre.code{font-family:var(--mono);font-size:.92rem;line-height:1.6;color:var(--cream);
  background:var(--ink);border:1px solid var(--line);border-radius:12px;
  padding:1rem 1.1rem;margin:1rem 0 0;overflow-x:auto;white-space:pre}
pre.code .op{color:var(--elixir-bright)}
pre.code .fn{color:var(--cream)}
pre.code .fn.blue{color:var(--blue-bright)}
pre.code .fn.sage{color:var(--sage-bright)}
pre.code .fn.gold{color:var(--gold-bright)}
pre.code .fn.elixir{color:var(--elixir-bright)}
pre.code .fn.burg{color:#e08f8b}
pre.code .res{color:var(--gold-bright)}
pre.code .str{color:var(--sage-bright)}
pre.code .cmt{color:var(--cream-dim)}
code.inl{font-family:var(--mono);font-size:.9em;color:var(--elixir-bright);
  background:var(--ink-2);border:1px solid var(--line);border-radius:6px;padding:.05em .4em}

/* ---- arc svg ---- */
.arc-node rect{transition:fill .2s ease, stroke .2s ease}
.arc-node{cursor:pointer}
.arc-node .num{font-family:var(--serif-display);font-weight:600;fill:var(--cream)}
.arc-node .nm{font-family:var(--sans);font-weight:600;fill:var(--cream-dim);letter-spacing:.02em}
.arc-node:hover rect{stroke:var(--cream-dim)}
.arc-node.active rect{fill:var(--ink-3);stroke:var(--elixir-bright)}
.arc-node.active .num{fill:var(--gold-bright)}
.arc-node.active .nm{fill:var(--elixir-bright)}
.arc-node:focus{outline:none}
.arc-node:focus-visible rect{stroke:var(--gold-bright)}
.arc-flow{stroke:var(--line);stroke-width:2;fill:none;stroke-dasharray:6 9}
.arc-arrow{fill:var(--cream-dim)}
@media (prefers-reduced-motion: no-preference){
  .arc-flow{animation:flow 1.6s linear infinite}
}
@keyframes flow{to{stroke-dashoffset:-30}}
.arc-readout{margin-top:1.1rem}
.arc-readout .nm{font-family:var(--serif-display);font-size:1.5rem;color:var(--cream);font-weight:600}
.arc-readout .one{font-family:var(--serif);color:var(--cream-soft);margin:.25rem 0 .5rem;max-width:60ch}
.arc-readout .meta{font-family:var(--sans);font-size:.82rem;color:var(--cream-dim);
  display:flex;flex-wrap:wrap;gap:.4rem 1.2rem;align-items:center}
.arc-readout .meta b{color:var(--gold)}
.arc-open{margin-top:.7rem;font-family:var(--sans);font-size:.9rem}
.arc-open .muted{color:var(--cream-dim)}

/* ---- contents directory ---- */
.legend{display:flex;flex-wrap:wrap;gap:.6rem 1.1rem;font-family:var(--sans);
  font-size:.78rem;color:var(--cream-dim);margin:.4rem 0 1.8rem}
.legend span{display:inline-flex;align-items:center;gap:.45rem}
.pill{font-family:var(--sans);font-size:.64rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.12em;padding:.18rem .5rem;border-radius:999px;border:1px solid}
.pill.live{color:var(--sage-bright);border-color:var(--sage)}
.pill.built{color:var(--gold-bright);border-color:var(--gold)}
.pill.planned{color:var(--blue-bright);border-color:var(--blue)}
.pill.soon{color:var(--elixir-bright);border-color:var(--elixir)}
.chap{padding-top:2.2rem}
.chap:first-of-type{padding-top:.4rem}
.chap-head{display:flex;flex-wrap:wrap;align-items:baseline;gap:.5rem 1rem;
  padding-bottom:.6rem;border-bottom:1px solid var(--line);margin-bottom:1.1rem}
.chap-head .cid{font-family:var(--mono);font-size:.95rem;color:var(--gold)}
.chap-head h3{margin:0}
.chap-head .c-one{font-family:var(--sans);font-size:.86rem;color:var(--cream-dim);
  flex-basis:100%;margin-top:.1rem}
.chap-head .chap-link{font-family:var(--sans);font-size:.82rem;margin-left:auto}
.mods{display:grid;grid-template-columns:repeat(3,1fr);gap:.8rem}
.mod{display:block;border:1px solid var(--line);border-radius:13px;padding:.85rem .95rem;
  background:linear-gradient(180deg,rgba(16,22,43,.5),rgba(10,14,26,.3));
  transition:transform .16s ease, border-color .16s ease, box-shadow .16s ease}
a.mod:hover{transform:translateY(-3px);border-color:var(--gold);
  box-shadow:0 14px 34px -18px rgba(212,168,90,.5)}
.mod .top{display:flex;align-items:center;justify-content:space-between;gap:.5rem;margin-bottom:.35rem}
.mod .num{font-family:var(--mono);font-size:.78rem;color:var(--gold)}
.mod .t{font-family:var(--serif-display);font-size:1.14rem;font-weight:600;
  color:var(--cream);line-height:1.12;margin:0 0 .25rem}
.mod .o{font-family:var(--sans);font-size:.8rem;color:var(--cream-dim);line-height:1.4}
.mod.is-quiet{opacity:.66;border-style:dashed}
.mod.is-quiet .t{color:var(--cream-soft)}
.mod.lab{border-left:2px solid var(--elixir)}
.mod.lab .num::after{content:" · lab";color:var(--elixir-bright)}
.dives{list-style:none;margin:.6rem 0 0;padding:.6rem 0 0;border-top:1px dashed var(--line);
  font-family:var(--sans);font-size:.78rem;color:var(--cream-dim);display:grid;gap:.3rem}
.dives li{display:flex;gap:.5rem}
.dives .dn{font-family:var(--mono);color:var(--gold);min-width:3.6rem}

/* ---- pager ---- */
.pager{display:flex;flex-wrap:wrap;gap:1rem;justify-content:space-between;
  align-items:center;font-family:var(--sans)}
.pager .p-left{color:var(--cream-dim);font-size:.9rem}
.pager .spacer{flex:1}

/* ---- branded stamp ---- */
.stamp{font-family:var(--mono);font-size:.8rem;color:var(--cream-dim);
  cursor:pointer;border:1px solid var(--line);border-radius:10px;padding:.45rem .7rem;
  background:var(--ink);user-select:none}
.stamp:hover{border-color:var(--gold)}
.stamp .id{color:var(--gold-bright)}
.stamp .panel{display:none;margin-top:.6rem;color:var(--cream-soft);
  display:none;grid-template-columns:auto 1fr;gap:.25rem .9rem;font-size:.76rem}
.stamp.open .panel{display:grid}
.stamp .panel dt{color:var(--cream-dim)}
.stamp .panel dd{margin:0;color:var(--cream)}
.colophon{max-width:42ch}
.colophon b{color:var(--cream-soft)}

/* ---- reveal (JS-gated; content visible without JS) ---- */
html.js .reveal{opacity:0;transform:translateY(14px)}
html.js .reveal.in{opacity:1;transform:none;transition:opacity .7s ease, transform .7s ease}
@media (prefers-reduced-motion: reduce){
  html.js .reveal,html.js .reveal.in{opacity:1;transform:none;transition:none}
}

/* ---- responsive ---- */
@media (max-width:760px){
  .mods{grid-template-columns:1fr}
  .site nav{display:none}
  .lede{max-width:none}
  .take{font-size:1.08rem}
}

/* ---- module / lesson page additions (additive; shared head) ---- */
.crumbs{font-family:var(--sans);font-size:.8rem;color:var(--cream-dim);
  display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:0 0 1.1rem}
.crumbs a{color:var(--cream-soft)}
.crumbs .sep{opacity:.45}
.crumbs .here{color:var(--gold)}
.toc-mini{display:flex;flex-wrap:wrap;gap:.5rem;font-family:var(--sans);font-size:.82rem;margin:1.4rem 0 0}
.toc-mini a{border:1px solid var(--line);border-radius:999px;padding:.32rem .85rem;color:var(--cream-soft)}
.toc-mini a:hover{border-color:var(--gold);color:var(--cream)}
.bridge{display:grid;grid-template-columns:1fr auto 1fr;gap:1rem;align-items:stretch;margin:1.7rem 0 0}
.bridge .cell{border:1px solid var(--line);border-radius:14px;padding:1rem 1.1rem;
  background:linear-gradient(180deg,rgba(16,22,43,.55),rgba(10,14,26,.3))}
.bridge .cell .lbl{font-family:var(--sans);font-size:.64rem;letter-spacing:.18em;
  text-transform:uppercase;margin:0 0 .55rem;color:var(--cream-dim)}
.bridge .cell.idea .lbl{color:var(--gold)}
.bridge .cell.elix .lbl{color:var(--elixir-bright)}
.bridge .cell p{margin:0;font-family:var(--serif);font-size:.98rem;color:var(--cream-soft)}
.bridge .arrow{align-self:center;font-family:var(--serif-display);font-size:1.7rem;color:var(--cream-dim)}
@media (max-width:760px){
  .bridge{grid-template-columns:1fr;gap:.7rem}
  .bridge .arrow{justify-self:center;transform:rotate(90deg)}
}
.dive{scroll-margin-top:74px}
.dive-head{display:flex;flex-wrap:wrap;align-items:baseline;gap:.5rem .9rem;margin:0 0 .5em}
.dive-tag{font-family:var(--mono);font-size:.72rem;color:var(--elixir-bright);
  border:1px solid var(--elixir);border-radius:999px;padding:.14rem .6rem}
.deflist{display:grid;grid-template-columns:auto 1fr;gap:.35rem 1rem;
  font-family:var(--sans);font-size:.86rem;margin:1.1rem 0 0}
.deflist dt{color:var(--gold);font-family:var(--mono);font-size:.82rem}
.deflist dd{margin:0;color:var(--cream-soft)}
.note{font-family:var(--sans);font-size:.88rem;color:var(--cream-dim);
  border-left:2px solid var(--blue);padding-left:.95rem;margin:1.5rem 0 0}
pre.code .rdx{background:rgba(179,157,219,.18);border-radius:4px;padding:0 .18em;color:var(--elixir-bright)}
pre.code .step{color:var(--cream-dim)}
.lin-arrow{fill:var(--cream-dim)}
/* ---- references ---- */
.refs{margin-top:1.4rem;border-top:1px solid var(--line);padding-top:1.3rem}
.refs h3{font-family:var(--sans);font-size:.72rem;font-weight:700;text-transform:uppercase;
  letter-spacing:.18em;color:var(--cream-dim);margin:1.3rem 0 .6rem}
.refs h3:first-child{margin-top:0}
.refs ul{list-style:none;margin:0;padding:0;display:grid;gap:.45rem}
.refs li{font-family:var(--sans);font-size:.9rem;color:var(--cream-soft);line-height:1.45}
.refs a{color:var(--sage-bright)}
.refs a:hover{color:var(--cream)}
.refs code{font-family:var(--mono);font-size:.86em;color:var(--gold-bright)}
"""

HEAD_HTML = (
    "<head>\n"
    '<meta charset="utf-8">\n'
    '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
    "<title>{{TITLE}}</title>\n"
    '<meta name="description" content="{{DESC}}">\n'
    '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
    '<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,500;1,600&family=PT+Serif:ital,wght@0,400;0,700;1,400&family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">\n'
    "<style>" + HEAD_CSS + "</style>\n"
    "</head>"
)

BOOTSTRAP = """<script>
/* progressive enhancement: mark JS on, then reveal-on-scroll */
document.documentElement.classList.add('js');
document.addEventListener('DOMContentLoaded', function () {
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var els = document.querySelectorAll('.reveal');
  if (reduce || !('IntersectionObserver' in window)) {
    els.forEach(function (e) { e.classList.add('in'); });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, { threshold: 0.12 });
  els.forEach(function (e) { io.observe(e); });
});
</script>"""


# --------------------------------------------------------------------------- #
# Contents directory + arc data (generated from the manifest)                  #
# --------------------------------------------------------------------------- #
def esc(s: str) -> str:
    return _html.escape(s, quote=True)


def _pill(status: str) -> str:
    return f'<span class="pill {status}">{status}</span>'


def _module_card(chapter: dict, m: dict) -> str:
    classes = ["mod"]
    if m.get("lab"):
        classes.append("lab")
    linkable = m["status"] in LINKABLE
    if not linkable:
        classes.append("is-quiet")
    cls = " ".join(classes)
    route = f'{chapter["route"]}/{m["slug"]}'
    inner = (
        f'<div class="top"><span class="num">{esc(m["n"])}</span>{_pill(m["status"])}</div>'
        f'<p class="t">{esc(m["title"])}</p>'
        f'<p class="o">{esc(m["one"])}</p>'
    )
    dives = m.get("dives")
    if dives:
        items = "".join(
            f'<li><span class="dn">{esc(d["n"])}</span><span>{esc(d["title"])}</span></li>'
            for d in dives
        )
        inner += f'<ul class="dives">{items}</ul>'
    if linkable:
        return f'<a class="{cls}" href="{esc(route)}">{inner}</a>'
    return f'<div class="{cls}">{inner}</div>'


def render_contents() -> str:
    out = []
    for ch in CHAPTERS:
        head = [f'<div class="chap-head">',
                f'<span class="cid">{esc(ch["id"])}</span>',
                f'<h3>{esc(ch["title"])}</h3>']
        if ch["status"] in LINKABLE:
            head.append(
                f'<a class="chap-link" href="{esc(ch["route"])}">Open chapter →</a>')
        else:
            head.append(f'{_pill(ch["status"])}')
        head.append(f'<p class="c-one">{esc(ch["one"])}</p>')
        head.append("</div>")
        cards = "".join(_module_card(ch, m) for m in MODULES[ch["id"]])
        out.append(
            f'<section class="chap reveal">{"".join(head)}'
            f'<div class="mods">{cards}</div></section>'
        )
    return "\n".join(out)


def chapters_json() -> str:
    data = []
    for ch in CHAPTERS:
        if ch["id"] == "F0":
            continue  # the arc shows the F1..F6 spine
        data.append({
            "id": ch["id"],
            "name": ch["title"],
            "route": ch["route"],
            "live": ch["status"] in LINKABLE,
            "modules": len(MODULES[ch["id"]]),
            "one": ch["one"],
            "reuses": ch["reuses"],
        })
    return json.dumps(data, ensure_ascii=False)


# --------------------------------------------------------------------------- #
# Apollo — quality gates                                                       #
# --------------------------------------------------------------------------- #
FORBIDDEN = re.compile(
    r"\b(revolutionary|blazing[\s-]?fast|magical|simply|just|obviously|effortless)\b",
    re.I,
)
CONTAINER_TAGS = {"div", "section", "main", "header", "footer", "nav",
                  "article", "figure", "aside"}
TAG_RE = re.compile(r"<(/?)([a-zA-Z][\w-]*)([^>]*?)(/?)>")


def _strip_code(s: str) -> str:
    s = re.sub(r"<script\b[^>]*>.*?</script>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<style\b[^>]*>.*?</style>", " ", s, flags=re.S | re.I)
    return s


def _visible_text(s: str) -> str:
    s = _strip_code(s)
    s = re.sub(r"<svg\b[^>]*>.*?</svg>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    return _html.unescape(s)


def gate_containers(doc: str):
    body = _strip_code(doc)
    body = re.sub(r"<svg\b[^>]*>.*?</svg>", " ", body, flags=re.S | re.I)
    stack = []
    for m in TAG_RE.finditer(body):
        closing, name, _attrs, selfclose = m.group(1), m.group(2).lower(), m.group(3), m.group(4)
        if name not in CONTAINER_TAGS:
            continue
        if selfclose:
            continue
        if closing:
            if not stack or stack[-1][0] != name:
                top = stack[-1][0] if stack else "—"
                return False, f"unbalanced </{name}> (open container was <{top}>)"
            stack.pop()
        else:
            stack.append((name, m.start()))
    if stack:
        nm = stack[-1][0]
        return False, f"unclosed <{nm}> — check for a missing </div> in a section"
    return True, "container tags balanced"


def gate_svg_wellformed(doc: str):
    o = len(re.findall(r"<svg\b", doc, re.I))
    c = len(re.findall(r"</svg>", doc, re.I))
    if o == 0:
        return False, "no <svg> present — every page carries a seen argument"
    if o != c:
        return False, f"svg open/close mismatch ({o} open, {c} close)"
    return True, f"{o} svg block(s), well formed"


def gate_no_future(doc: str):
    return ("/future" not in doc), ("no /future links" if "/future" not in doc
                                    else "found a link to /future")


def gate_forbidden(doc: str):
    hits = sorted({h.group(0).lower() for h in FORBIDDEN.finditer(_visible_text(doc))})
    return (not hits), ("no hype / dismissive words" if not hits
                        else "forbidden words: " + ", ".join(hits))


def gate_storage(doc: str):
    bad = re.search(r"\b(localStorage|sessionStorage)\b", doc)
    return (bad is None), ("no web storage APIs" if bad is None
                           else "uses " + bad.group(0))


def gate_reduced_motion(doc: str):
    ok = "prefers-reduced-motion" in doc
    return ok, ("honours prefers-reduced-motion" if ok
                else "missing prefers-reduced-motion handling")


def gate_reveal_degrades(doc: str):
    if ".reveal" not in doc:
        return True, "no reveal animation"
    ok = "html.js .reveal" in doc or ".js .reveal" in doc
    return ok, ("reveal is JS-gated; content visible without JS" if ok
                else "reveal hides content without a JS gate")


def gate_links(doc: str):
    allowed = allowed_routes()
    bad = []
    for m in re.finditer(r'href="([^"]+)"', doc):
        href = m.group(1)
        if href.startswith(("#", "http://", "https://", "mailto:", "tel:", "//")):
            continue
        if href in allowed:
            continue
        bad.append(href)
    bad = sorted(set(bad))
    return (not bad), ("all internal links resolve to live/built routes"
                       if not bad else "dangling internal links: " + ", ".join(bad))


def gate_pager(doc: str):
    if 'class="pager"' not in doc:
        return False, "no .pager navigation block"
    allowed = allowed_routes()
    has = any(m.group(1) in allowed
              for m in re.finditer(r'href="([^"]+)"', doc))
    return has, ("pager links to a real route" if has
                 else "pager has no link to a live/built route")


APOLLO_GATES = [
    ("containers", gate_containers),
    ("svg",        gate_svg_wellformed),
    ("no-future",  gate_no_future),
    ("voice",      gate_forbidden),
    ("storage",    gate_storage),
    ("motion",     gate_reduced_motion),
    ("degrade",    gate_reveal_degrades),
    ("links",      gate_links),
    ("pager",      gate_pager),
]


def apollo(doc: str):
    results = [(name, *fn(doc)) for name, fn in APOLLO_GATES]
    passed = all(ok for _, ok, _ in results)
    return passed, results


def print_apollo(path: str, passed: bool, results) -> None:
    print(f"\nApollo · {path}")
    for name, ok, detail in results:
        mark = "PASS" if ok else "FAIL"
        print(f"  [{mark}] {name:<11} {detail}")
    grade = "A+" if passed else "—"
    print(f"  grade: {grade}")
    print(f"STATUS: {'PASS' if passed else 'FAIL'}")


# --------------------------------------------------------------------------- #
# Build                                                                        #
# --------------------------------------------------------------------------- #
PAGES = {
    # key -> (content fragment, output file, title, description)
    "aaw-course": (
        "content/aaw-course.html",
        "agile-agent-workflow.html",
        "Agile Agent Workflow in Elixir \u2014 Pragmatic Programming with Claude Agents \u00b7 jonnify",
        "A practitioner's course on shipping reliable software with a human and a Claude agent: decompose into user "
        "stories, plan a roadmap, write the spec and the agent brief, and prove each increment correct \u2014 built "
        "end to end on the Portal, from zero to production.",
    ),
    "aaw-a0": (
        "content/aaw-a0.html",
        "agile-agent-workflow-intro.html",
        "A0 \u2014 Foundations \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "Chapter A0, the foundations: why a pragmatic, story-led, agent-driven workflow works (why), the framework it "
        "runs on \u2014 two layers, four artifacts, one loop (what) \u2014 and the two roles that drive it (who).",
    ),
    "aaw-what": (
        "content/aaw-what.html",
        "agile-agent-workflow-what.html",
        "A0.2 \u2014 What we are building \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "The A0.2 module: the framework the course runs on \u2014 the two-layer model, the four artifacts, and the "
        "Author/Operator loop \u2014 three subpages that lay out its structure, vocabulary, and motion.",
    ),
    "aaw-a0-1": (
        "content/aaw-a0-1.html",
        "agile-agent-workflow-what-two-layer-model.html",
        "A0.2.1 \u2014 The two-layer model \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "The framework's structure: a roadmap layer that plans delivery over a spec layer that defines and proves each "
        "rung, both sitting on the framework-free domain core \u2014 and why the spec is the single source of truth.",
    ),
    "aaw-a0-2": (
        "content/aaw-a0-2.html",
        "agile-agent-workflow-what-four-artifacts.html",
        "A0.2.2 \u2014 The four artifacts \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "The framework's vocabulary: the roadmap.md, the spec, the user stories, and the agent brief (.llms.md) \u2014 "
        "the four artifacts every rung uses, and the distinct question each one answers.",
    ),
    "aaw-a0-3": (
        "content/aaw-a0-3.html",
        "agile-agent-workflow-what-author-operator-loop.html",
        "A0.2.3 \u2014 The Author/Operator loop \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "The framework's motion: a loop between two roles \u2014 the Operator (human) who sharpens, reviews, and "
        "accepts, and the Author (Claude agent) who specifies, builds, and ships \u2014 meeting on the spec, with "
        "feedback editing it each turn.",
    ),
    "aaw-a0-1-roadmap": (
        "content/aaw-a0-1-roadmap.html",
        "agile-agent-workflow-what-two-layer-model-roadmap-anatomy.html",
        "A0.2.1 deep dive \u2014 Anatomy of a roadmap.md \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "A deep dive into the roadmap layer: the parts of a roadmap.md \u2014 milestones, the rungs that ship value, "
        "and a definition of done \u2014 and what it means for a rung to be thin but robust.",
    ),
    "aaw-a1": (
        "content/aaw-a1.html",
        "agile-agent-workflow-decomposition.html",
        "A1 \u2014 Decomposition \u00b7 Agile Agent Workflow \u00b7 jonnify",
        "Chapter A1, Decomposition: turning a product vision into a ladder of small, valuable, testable user stories "
        "\u2014 value not tasks, the story form, INVEST, acceptance criteria, splitting, and the value ladder.",
    ),
}


def cmd_extract_head(_args) -> int:
    (ROOT / "_head.html").write_text(HEAD_HTML, encoding="utf-8")
    print("wrote _head.html")
    return 0


def _assemble(fragment: str, title: str, desc: str) -> str:
    head = (ROOT / "_head.html").read_text(encoding="utf-8")
    head = head.replace("{{TITLE}}", esc(title)).replace("{{DESC}}", esc(desc))
    build_id = mint("TSK")
    info = decode(build_id)
    fragment = (fragment
                .replace("{{CONTENTS}}", render_contents())
                .replace("{{CHAPTERS_JSON}}", chapters_json())
                .replace("{{BUILD_ID}}", build_id)
                .replace("{{BUILD_TS}}", info["timestamp"])
                .replace("{{MODULE_COUNT}}", str(module_count())))
    return ("<!doctype html>\n<html lang=\"en\">\n"
            + head + "\n<body>\n" + fragment + "\n" + BOOTSTRAP + "\n</body>\n</html>\n")


def _build_one(key: str) -> bool:
    frag_path, out_name, title, desc = PAGES[key]
    if not (ROOT / "_head.html").exists():
        print("error: _head.html missing — run `extract-head` first", file=sys.stderr)
        return False
    fragment = (ROOT / frag_path).read_text(encoding="utf-8")
    doc = _assemble(fragment, title, desc)
    out = ROOT / out_name
    out.write_text(doc, encoding="utf-8")
    print(f"built {out_name}  ({len(doc):,} bytes)  from {frag_path}")
    passed, results = apollo(doc)
    print_apollo(out_name, passed, results)
    return passed


def cmd_build(args) -> int:
    keys = list(PAGES) if args.all else [args.page]
    if not args.all and args.page not in PAGES:
        print(f"unknown page '{args.page}'. known: {', '.join(PAGES)}", file=sys.stderr)
        return 2
    ok = True
    for k in keys:
        ok = _build_one(k) and ok
    return 0 if ok else 1


def cmd_check(args) -> int:
    ok = True
    for p in args.files:
        doc = Path(p).read_text(encoding="utf-8")
        passed, results = apollo(doc)
        print_apollo(p, passed, results)
        ok = passed and ok
    return 0 if ok else 1


def cmd_manifest(_args) -> int:
    print(f"{'ID':<8} {'STATUS':<8} TITLE")
    for ch in CHAPTERS:
        print(f"{ch['id']:<8} {ch['status']:<8} {ch['title']}  [{ch['route']}]")
        for m in MODULES[ch["id"]]:
            lab = " (lab)" if m.get("lab") else ""
            print(f"  {m['n']:<6} {m['status']:<8} {m['title']}{lab}")
            for d in m.get("dives", []):
                print(f"    {d['n']:<6} {d['status']:<8} {d['title']}")
    print(f"\ntotal modules (incl. dives): {module_count()}")
    return 0


def cmd_routes(_args) -> int:
    # Every linkable route the manifest knows: ROOT, chapters, modules, module
    # deep-dives, and chapter front-matter — one bare route per line. With every
    # chapter/module/subpage live this is exactly the on-disk elixir/ route tree.
    for route in sorted(allowed_routes()):
        print(route)
    return 0


def cmd_id(args) -> int:
    if args.id_cmd == "mint":
        at = datetime.fromisoformat(args.at).astimezone(timezone.utc) if args.at else None
        print(mint(args.ns, node=args.node, seq=args.seq, at=at))
    else:
        for k, v in decode(args.branded).items():
            print(f"{k:<11}: {v}")
    return 0


# --------------------------------------------------------------------------- #
# CLI                                                                          #
# --------------------------------------------------------------------------- #
def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="build_page.py", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("extract-head").set_defaults(func=cmd_extract_head)

    b = sub.add_parser("build")
    b.add_argument("--page", default="landing")
    b.add_argument("--all", action="store_true")
    b.set_defaults(func=cmd_build)

    c = sub.add_parser("check")
    c.add_argument("files", nargs="+")
    c.set_defaults(func=cmd_check)

    sub.add_parser("manifest").set_defaults(func=cmd_manifest)
    sub.add_parser("routes").set_defaults(func=cmd_routes)

    i = sub.add_parser("id")
    isub = i.add_subparsers(dest="id_cmd", required=True)
    im = isub.add_parser("mint")
    im.add_argument("--ns", default="TSK")
    im.add_argument("--node", type=int, default=0)
    im.add_argument("--seq", type=int, default=0)
    im.add_argument("--at", default=None, help="ISO 8601, e.g. 2026-01-27T15:11:37Z")
    id_ = isub.add_parser("decode")
    id_.add_argument("branded")
    i.set_defaults(func=cmd_id)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
