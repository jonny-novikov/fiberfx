Prebuilt snapshots of the eight Agile Agent Workflow pages, produced by ../build_page.py.
Each is a single self-contained HTML file — open any of them directly in a browser.
Internal links point to /course/agile-agent-workflow/... routes and resolve on a server, not as local files.
To regenerate: from the toolkit/ directory run  python3 build_page.py build --all
(the builder writes the bare output filenames into toolkit/, then move them here).
