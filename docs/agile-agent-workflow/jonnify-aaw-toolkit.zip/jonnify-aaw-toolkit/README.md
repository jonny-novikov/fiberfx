# jonnify — Agile Agent Workflow toolkit

A complete, self-contained kit for building **jonnify dark-editorial** static-HTML course pages, packaged around the *Agile Agent Workflow in Elixir* course. It is the same machinery used to produce that course: a Python builder, the shared design-system head, a headless validator, the live content fragments as worked examples, and the course's planning documents.

Everything here is stdlib-Python plus Node for validation. There is no framework and no runtime — each built page is a single self-contained HTML file with inline CSS from a shared head, one inline script, and one or more inline SVG/HTML interactive components.

## What is in this archive

The four pieces you asked for, plus this README:

- **`toolkit/`** — the page-building kit (builder, head, validator, examples, deep-reference playbook). This realizes the principles and styles below.
- **`agile-agent-workflow.toc.md`** — the **course TOC**: the full table of contents, seven parts, forty-seven lessons, with the appendix canon and its sources.
- **`abstracts.md`** — the **abstracts**: a one-paragraph abstract for the course and for each chapter (A0–A7), with a one-line abstract per module/lesson.
- **`progress.md`** — the **progress** ledger: which pages are built and gated A+, which are planned, with routes, output filenames, and gate status.

```
.
├── README.md
├── agile-agent-workflow.toc.md      ← course TOC
├── abstracts.md                     ← abstracts
├── progress.md                      ← progress
└── toolkit/
    ├── build_page.py                ← the engine: assemble + nine Apollo gates + branded IDs
    ├── _head.html                   ← shared <head>: all design tokens + base CSS (the styles)
    ├── content/                     ← eight AAW fragments (hand-authored sources)
    ├── examples/                    ← the eight built pages (open any in a browser)
    ├── validator/                   ← headless DOM validator (zero screenshots)
    └── docs/authoring-playbook.md   ← the in-depth authoring brief
```

## Quickstart

From inside `toolkit/`:

```sh
# Build one page (assemble fragment → inline head → mint a build id → run gates → write file)
python3 build_page.py build --page aaw-course

# Build every registered page
python3 build_page.py build --all

# Run the gates on an already-built file
python3 build_page.py check examples/agile-agent-workflow.html

# Inspect the manifest and the route table
python3 build_page.py manifest
python3 build_page.py routes

# Branded Snowflake IDs
python3 build_page.py id mint --ns TSK
python3 build_page.py id decode TSK0KHTOWnGLuC

# Re-emit the shared head after editing HEAD_CSS in build_page.py, then rebuild
python3 build_page.py extract-head
```

Headless validation (no images, ever):

```sh
cd validator && npm install   # Playwright; resolves from the environment if present
node validator.js             # see validator/README.md for the Validator API
```

## The principles, in brief

A page is a hand-authored **fragment** in `content/`. The builder injects a freshly minted branded build id, wraps the fragment in the shared head and a small bootstrap script, runs nine gates, and writes a flat HTML file. Any gate failure is a hard stop — only an all-pass page is written as A+.

**The nine Apollo gates.** `containers` (balanced tags, with svg/script/style stripped first) · `svg` (at least one well-formed `<svg>`) · `no-future` (no future-dated references) · `voice` (no hype words — *revolutionary, blazing-fast, magical, simply, just, obviously, effortless* — in visible text) · `storage` (no `localStorage`/`sessionStorage`) · `motion` (the document carries `prefers-reduced-motion`) · `degrade` (if `.reveal` is used, `html.js .reveal` must exist so no-JS still shows content) · `links` (every `href` is a fragment/`http`/`https`/`mailto`/`tel`/protocol-relative link, or a route the manifest knows) · `pager` (a `class="pager"` block with at least one known route).

**Branded Snowflake IDs.** Integer Snowflakes — `timestamp(41) << 22 | node(10) << 12 | seq(12)`, epoch `2024-01-01T00:00:00Z` — rendered for transport as a three-letter namespace plus base62, left-padded to eleven characters. The canonical example round-trips both ways: `TSK0KHTOWnGLuC` ⇄ `274557032793636864` ⇄ `2026-01-27 15:11:37 UTC`. Every built page stamps one in its footer; the footer's decoder script reverses it in the browser.

**The styles.** `_head.html` is the single source of the look: dark surfaces (`--ink` family), warm cream text, five accents (gold, blue, sage, elixir-purple, burgundy), and four fonts (Cormorant Garamond display, PT Serif, Manrope, JetBrains Mono). Components are plain classes — `.hero`, `.bridge`, `.deflist`, `.note`, `.take`, `.refs`, `.mod`/`.mods`, `.pill`, `.solid-select`, `.geo-readout`, `pre.code`, `.pager`, the footer family. SVGs must use **literal hex** colours, not CSS variables (variables do not resolve inside SVG).

**Fragment anatomy.** skip-link → `header.site` → `main#main.wrap` → hero → sections → an optional References block → `.pager` → footer (with the build-id stamp + decoder script). The interactive contract is one `.solid-select` button group that swaps an SVG's strokes/fills and writes a `.geo-readout` (seeded for no-JS, updated live with one small script per page).

**Registering a page.** Add a four-tuple to the `PAGES` dict in `build_page.py`:

```python
"my-key": (
    "content/my-fragment.html",   # the hand-authored fragment
    "my-output.html",             # the flat file the builder writes
    "Page title · jonnify",       # <title> and og:title
    "One- or two-sentence description for meta + social cards.",
),
```

If the fragment links to new routes, add them to `EXTRA_ROUTES` (or model them in the chapter/module data) so the `links` and `pager` gates accept them.

## A note on the engine

`build_page.py` is the **shared jonnify builder**. Its `PAGES` manifest registers the eight `aaw-*` build targets — the only pages this kit builds — so `build --all` produces exactly the eight Agile Agent Workflow pages. The builder also retains the jonnify chapter and module reference data that powers the contents and arc generators; those generators are dormant for the AAW fragments, which carry their own navigation. The AAW course uses thematic slug routes under `/course/agile-agent-workflow/…` (for example `/intro`, `/what`, `/decomposition`), declared in `EXTRA_ROUTES` and tagged ahead of release so internal links pass the gates before every target page exists.

The `HEAD_CSS` baked into this builder is the mobile-safe design system the AAW fragments were authored against: the `.geo-readout` wraps long prose, and the `.refs` references styling is present. (An earlier head iteration set the readout to `white-space:nowrap`, which overflowed the viewport on narrow screens — corrected here.) After any edit to `HEAD_CSS`, run `extract-head` to refresh `_head.html`, then rebuild.

For the full reasoning, the worked recipe, the voice guide, and the copy-paste fragment skeleton, read **`toolkit/docs/authoring-playbook.md`**.
