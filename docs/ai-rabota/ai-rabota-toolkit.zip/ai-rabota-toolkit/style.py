#!/usr/bin/env python3
"""Дизайн-система курса «ИИ на работе» — футуристичный «Neural HUD».
Тёмная космо-индиго база, доминанта — электрический циан, резкие акценты —
фиолетовый/маджента; стеклянные панели с угловыми скобками, точечная сетка и
аврора-свечение, неоновые градиентные заголовки, моно-подписи в стиле HUD.
Шрифты: Chakra Petch (дисплей), Hanken Grotesk (текст), JetBrains Mono (данные).

Экспортирует:
  PALETTE  — slug -> (accent, bright, deep, "r,g,b")
  head(title, desc, slug) -> строка <!doctype>…</head> с акцентом под slug
  NAV_JS   — прогресс-бар, scroll-spy section-nav, кнопка «наверх»
  QUIZ_JS  — движок квиза (localStorage, разбор по клику, счёт, сброс)
"""

PALETTE = {
    'global':    ('#2fe6e6', '#7df7f7', '#0f8f93', '47,230,230'),    # циан — бренд
    'vvedenie':  ('#2fe6e6', '#7df7f7', '#0f8f93', '47,230,230'),    # Гл.1 введение — циан
    'proverka':  ('#a78bff', '#c9b6ff', '#5b46b0', '167,139,255'),   # Гл.2 проверять — фиолет
    'schitat':   ('#54e39b', '#8af0bd', '#1f8f5e', '84,227,155'),    # Гл.3 считать — зелёный
    'promt':     ('#ffb454', '#ffd08a', '#b9772a', '255,180,84'),    # Гл.4 промт — янтарь
    'scenarii':  ('#ff6fae', '#ff9ec8', '#b23c75', '255,111,174'),   # Гл.5 сценарии — маджента
    'vnedrenie': ('#5b8cff', '#8fb0ff', '#2f57b0', '91,140,255'),    # Гл.6 внедрение — синий
}

_CSS = r"""
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#070912; --bg2:#0b0e1c; --panel:rgba(255,255,255,.035); --panel2:rgba(255,255,255,.06);
  --line:rgba(120,160,255,.16); --line-soft:rgba(120,160,255,.09);
  --ink:#e8ecff; --ink-soft:#b9c2e6; --muted:#7f8bb5;
  --accent:#2fe6e6; --accent-bright:#7df7f7; --accent-deep:#0f8f93; --rgb:47,230,230;
  --violet:#a78bff; --violet-rgb:167,139,255; --ok:#54e39b; --warn:#ff6f7d;
  --display:'Chakra Petch',sans-serif; --sans:'Hanken Grotesk',sans-serif; --mono:'JetBrains Mono',monospace;
}
html{font-size:17px;scroll-behavior:smooth;-webkit-text-size-adjust:100%}
@media(min-width:1024px){html{font-size:18px}}
body{font-family:var(--sans);background:var(--bg);color:var(--ink);line-height:1.62;
  overflow-x:hidden;letter-spacing:.005em;-webkit-font-smoothing:antialiased}
/* атмосфера: аврора + точечная сетка */
body::before{content:"";position:fixed;inset:0;z-index:-2;pointer-events:none;
  background:
    radial-gradient(60vw 50vh at 12% -8%, rgba(var(--rgb),.16), transparent 60%),
    radial-gradient(55vw 45vh at 95% 6%, rgba(var(--violet-rgb),.14), transparent 60%),
    radial-gradient(70vw 60vh at 50% 115%, rgba(var(--rgb),.08), transparent 60%),
    var(--bg);}
body::after{content:"";position:fixed;inset:0;z-index:-2;pointer-events:none;opacity:.5;
  background-image:radial-gradient(rgba(130,170,255,.10) 1px, transparent 1px);
  background-size:30px 30px;mask-image:radial-gradient(ellipse at 50% 30%, #000 35%, transparent 85%);
  -webkit-mask-image:radial-gradient(ellipse at 50% 30%, #000 35%, transparent 85%);}
::selection{background:rgba(var(--rgb),.32);color:#fff}
a{color:inherit;text-decoration:none}
.container{max-width:1080px;margin:0 auto;padding:0 26px}

/* прогресс-бар */
.progress-bar{position:fixed;top:0;left:0;height:2px;width:0;z-index:60;
  background:linear-gradient(90deg,var(--accent),var(--violet));box-shadow:0 0 12px rgba(var(--rgb),.8)}

/* верхняя панель */
.topbar{position:sticky;top:0;z-index:50;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
  background:linear-gradient(180deg,rgba(8,11,24,.86),rgba(8,11,24,.55));border-bottom:1px solid var(--line-soft)}
.topbar-inner{max-width:1080px;margin:0 auto;padding:11px 26px;display:flex;align-items:center;gap:18px}
.brand{display:flex;align-items:center;gap:12px;margin-right:auto}
.brand-mark{width:34px;height:34px;display:grid;place-items:center;border-radius:9px;font-size:1.05rem;
  color:#05121a;font-weight:800;background:linear-gradient(135deg,var(--accent-bright),var(--violet));
  box-shadow:0 0 18px rgba(var(--rgb),.5)}
.brand-text{display:flex;flex-direction:column;line-height:1.15}
.brand-name{font-family:var(--display);font-weight:600;font-size:.96rem;letter-spacing:.01em}
.brand-sub{font-family:var(--mono);font-size:.62rem;letter-spacing:.22em;text-transform:uppercase;color:var(--accent)}
.breadcrumb{display:flex;align-items:center;gap:8px;font-family:var(--mono);font-size:.7rem;color:var(--muted);
  flex-wrap:wrap;letter-spacing:.04em}
.breadcrumb a:hover{color:var(--accent-bright)} .breadcrumb .sep{opacity:.4}
.breadcrumb .current{color:var(--ink)}
.back-link{font-family:var(--mono);font-size:.72rem;letter-spacing:.06em;color:var(--accent);
  border:1px solid var(--line);border-radius:7px;padding:6px 12px;white-space:nowrap;transition:.18s}
.back-link:hover{background:rgba(var(--rgb),.1);box-shadow:0 0 14px rgba(var(--rgb),.3)}

/* герой */
.hero{position:relative;padding:74px 0 40px}
.hero .container{position:relative}
.kicker{display:inline-flex;align-items:center;gap:9px;font-family:var(--mono);font-size:.72rem;
  letter-spacing:.2em;text-transform:uppercase;color:var(--accent);margin-bottom:20px}
.kicker::before{content:"›";color:var(--violet);font-weight:700}
.hero-mark{font-size:1.6rem;margin-bottom:14px;filter:drop-shadow(0 0 16px rgba(var(--rgb),.7))}
h1{font-family:var(--display);font-weight:700;font-size:clamp(2.1rem,6vw,4rem);line-height:1.04;
  letter-spacing:-.01em;margin-bottom:22px;background:linear-gradient(112deg,var(--ink) 12%,var(--accent-bright) 52%,var(--violet) 96%);
  -webkit-background-clip:text;background-clip:text;color:transparent}
h1 .em{background:linear-gradient(112deg,var(--accent),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}
.hero-lead{font-size:1.16rem;color:var(--ink-soft);max-width:60ch;margin-bottom:26px}
.chip-row{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:30px}
.chip{font-family:var(--mono);font-size:.82rem;color:var(--ink);padding:9px 14px;border-radius:9px;
  border:1px solid var(--line);background:var(--panel);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.chip .fc-l{color:var(--accent);text-transform:uppercase;font-size:.62rem;letter-spacing:.16em;margin-right:8px}
.stat-row{display:flex;flex-wrap:wrap;gap:26px;margin-top:6px}
.stat{display:flex;flex-direction:column}
.stat b{font-family:var(--display);font-size:1.7rem;color:var(--accent-bright);line-height:1}
.stat span{font-family:var(--mono);font-size:.66rem;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-top:6px}

/* кнопки-действия */
.btn-row{display:flex;flex-wrap:wrap;gap:14px;margin-top:8px}
.btn{font-family:var(--mono);font-size:.86rem;letter-spacing:.04em;padding:13px 22px;border-radius:10px;
  cursor:pointer;border:1px solid transparent;transition:.18s;display:inline-flex;align-items:center;gap:9px}
.btn.primary{color:#05121a;font-weight:700;background:linear-gradient(120deg,var(--accent-bright),var(--violet));
  box-shadow:0 0 22px rgba(var(--rgb),.4)}
.btn.primary:hover{box-shadow:0 0 34px rgba(var(--rgb),.65);transform:translateY(-1px)}
.btn.ghost{color:var(--accent);border-color:var(--line);background:var(--panel)}
.btn.ghost:hover{background:rgba(var(--rgb),.08);box-shadow:0 0 16px rgba(var(--rgb),.25)}

/* секц-навигация (scroll-spy) */
.section-nav{position:sticky;top:57px;z-index:40;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
  background:rgba(8,11,24,.66);border-top:1px solid var(--line-soft);border-bottom:1px solid var(--line-soft)}
.section-nav-inner{max-width:1080px;margin:0 auto;padding:0 26px;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none}
.section-nav-inner::-webkit-scrollbar{display:none}
.section-nav a{font-family:var(--mono);font-size:.74rem;letter-spacing:.03em;color:var(--muted);
  padding:13px 14px;white-space:nowrap;border-bottom:2px solid transparent;transition:.16s;display:flex;gap:8px;align-items:center}
.section-nav a .sn-n{color:var(--accent);opacity:.7}
.section-nav a:hover{color:var(--ink)}
.section-nav a.active{color:var(--ink);border-bottom-color:var(--accent);text-shadow:0 0 12px rgba(var(--rgb),.5)}
.section-nav a.active .sn-n{opacity:1}

/* секции и блоки */
.sect{padding:54px 0;border-bottom:1px solid var(--line-soft)}
.sect .container{position:relative}
.sect-head{margin-bottom:24px}
.sect-head .kicker{margin-bottom:14px}
h2{font-family:var(--display);font-weight:600;font-size:clamp(1.5rem,3.4vw,2.2rem);line-height:1.12;letter-spacing:-.005em}
h2 .em{color:var(--accent)} h3 .em{color:var(--accent)}
.lead{font-size:1.08rem;color:var(--ink-soft);max-width:64ch;margin-top:12px}
.sect-block{margin-top:18px;color:var(--ink-soft);font-size:1.02rem}
.sect-block p+p{margin-top:12px}
.sect-block ul{list-style:none;margin-top:6px;display:flex;flex-direction:column;gap:11px}
.sect-block ul li{position:relative;padding-left:26px}
.sect-block ul li::before{content:"▹";position:absolute;left:2px;top:1px;color:var(--accent);
  text-shadow:0 0 10px rgba(var(--rgb),.6)}
.sect-block b,.sect-block strong{color:var(--ink)}

/* выноски */
.callout{margin-top:18px;padding:16px 18px;border-radius:11px;border:1px solid var(--line);
  background:var(--panel);position:relative;color:var(--ink-soft);font-size:.98rem;
  border-left:3px solid var(--accent)}
.callout.warn{border-left-color:var(--warn);background:rgba(255,111,125,.06)}
.callout.warn b{color:var(--warn)}

/* формула-бокс */
.formula-box{margin:20px 0;padding:22px 22px 20px;border-radius:13px;border:1px solid var(--line);
  background:linear-gradient(180deg,rgba(var(--rgb),.06),var(--panel));position:relative;overflow:hidden}
.formula-box::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;
  background:linear-gradient(var(--accent),var(--violet));box-shadow:0 0 14px rgba(var(--rgb),.5)}
.formula-box .fb-cap{font-family:var(--mono);font-size:.64rem;letter-spacing:.18em;text-transform:uppercase;
  color:var(--accent);margin-bottom:10px}
.formula-box .katex{color:var(--ink);font-size:1.2rem}

/* интерактив-панель */
.task-block{margin:8px 0 4px;padding:24px;border-radius:15px;border:1px solid var(--line);position:relative;
  background:linear-gradient(180deg,var(--panel2),rgba(8,11,24,.4));backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
  box-shadow:0 24px 60px -34px rgba(0,0,0,.9), inset 0 1px 0 rgba(255,255,255,.04)}
/* угловые скобки HUD */
.task-block::before,.task-block::after{content:"";position:absolute;width:16px;height:16px;pointer-events:none}
.task-block::before{left:10px;top:10px;border-left:2px solid var(--accent);border-top:2px solid var(--accent);opacity:.7}
.task-block::after{right:10px;bottom:10px;border-right:2px solid var(--accent);border-bottom:2px solid var(--accent);opacity:.7}
.task-head{display:flex;flex-direction:column;gap:8px;margin-bottom:8px}
.task-tag{font-family:var(--mono);font-size:.64rem;letter-spacing:.18em;text-transform:uppercase;color:var(--accent)}
.task-head h4{font-family:var(--display);font-weight:600;font-size:1.18rem;color:var(--ink)}
.task-intro{color:var(--ink-soft);font-size:.98rem;margin-bottom:16px}
.calc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:8px}
.calc-field{display:flex;flex-direction:column;gap:7px}
.calc-field label{font-family:var(--mono);font-size:.72rem;letter-spacing:.03em;color:var(--ink-soft)}
.calc-field input{font-family:var(--mono);font-size:1rem;color:var(--ink);background:rgba(0,0,0,.34);
  border:1px solid var(--line);border-radius:8px;padding:11px 13px;width:100%;transition:.16s}
.calc-field input:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--rgb),.18)}
input[type=range]{accent-color:var(--accent);height:26px}
.calc-btn{margin-top:16px;font-family:var(--mono);font-size:.84rem;letter-spacing:.05em;color:#05121a;font-weight:700;
  background:linear-gradient(120deg,var(--accent-bright),var(--violet));border:none;border-radius:10px;
  padding:13px 24px;cursor:pointer;transition:.18s;box-shadow:0 0 20px rgba(var(--rgb),.34)}
.calc-btn:hover{box-shadow:0 0 32px rgba(var(--rgb),.6);transform:translateY(-1px)}
.calc-result{margin-top:16px;border-radius:12px;border:1px solid var(--line);overflow:hidden;
  max-height:0;opacity:0;transition:max-height .35s ease,opacity .35s ease;
  background:linear-gradient(180deg,rgba(var(--rgb),.08),rgba(0,0,0,.18))}
.calc-result.show{max-height:520px;opacity:1;padding:18px 20px}
.calc-result .cr-big{font-family:var(--display);font-weight:700;font-size:2rem;color:var(--accent-bright);
  line-height:1.05;text-shadow:0 0 22px rgba(var(--rgb),.4)}
.calc-result .cr-t{color:var(--ink-soft);font-size:.96rem;margin-top:8px}
.disclaimer{margin-top:14px;font-family:var(--mono);font-size:.68rem;color:var(--muted);letter-spacing:.02em}
/* сегментный переключатель */
.seg{display:inline-flex;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:rgba(0,0,0,.28)}
.seg button{font-family:var(--mono);font-size:.78rem;letter-spacing:.03em;color:var(--muted);background:none;border:none;
  padding:10px 16px;cursor:pointer;transition:.16s}
.seg button.on{color:#05121a;font-weight:700;background:linear-gradient(120deg,var(--accent-bright),var(--accent));
  box-shadow:0 0 16px rgba(var(--rgb),.4)}

/* выводы */
.takeaways{margin-top:26px;display:grid;gap:10px}
.takeaway-item{position:relative;padding:13px 16px 13px 44px;border-radius:10px;border:1px solid var(--line-soft);
  background:var(--panel);color:var(--ink-soft);font-size:.97rem}
.takeaway-item::before{content:"✓";position:absolute;left:15px;top:13px;color:var(--ok);font-weight:700;
  text-shadow:0 0 10px rgba(84,227,155,.6)}

/* квиз */
.quiz{padding:40px 0}
.quiz .container{position:relative}
.quiz-head{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:8px}
.quiz-tag{font-family:var(--mono);font-size:.66rem;letter-spacing:.18em;text-transform:uppercase;color:var(--accent)}
.quiz-score{font-family:var(--mono);font-size:.82rem;color:var(--ink);border:1px solid var(--line);border-radius:20px;
  padding:6px 14px;background:var(--panel)}
.quiz-intro{color:var(--ink-soft);margin-bottom:20px;font-size:.98rem}
.quiz-q{margin-bottom:16px;padding:18px;border-radius:13px;border:1px solid var(--line-soft);background:var(--panel)}
.q-text{display:flex;gap:12px;align-items:baseline;margin-bottom:14px;font-size:1.04rem;color:var(--ink)}
.q-num{font-family:var(--mono);font-size:.78rem;color:#05121a;font-weight:700;background:var(--accent);
  border-radius:6px;min-width:26px;height:24px;display:inline-flex;align-items:center;justify-content:center}
.q-options{display:grid;gap:9px}
.q-opt{font-family:var(--sans);text-align:left;font-size:.97rem;color:var(--ink-soft);background:rgba(0,0,0,.26);
  border:1px solid var(--line);border-radius:9px;padding:12px 14px;cursor:pointer;transition:.14s}
.q-opt:hover:not(.disabled){border-color:var(--accent);color:var(--ink)}
.q-opt.correct{border-color:var(--ok);background:rgba(84,227,155,.12);color:#dffaec;box-shadow:0 0 16px rgba(84,227,155,.22)}
.q-opt.incorrect{border-color:var(--warn);background:rgba(255,111,125,.1);color:#ffe2e5}
.q-opt.disabled{cursor:default;opacity:.85}
.q-explain{max-height:0;opacity:0;overflow:hidden;transition:.3s;font-size:.93rem;color:var(--ink-soft)}
.q-explain.show{max-height:240px;opacity:1;margin-top:12px;padding-top:12px;border-top:1px dashed var(--line)}
.q-explain b{color:var(--accent-bright)}
.quiz-foot{margin-top:8px}
.quiz-reset{font-family:var(--mono);font-size:.74rem;letter-spacing:.04em;color:var(--accent);background:none;
  border:1px solid var(--line);border-radius:8px;padding:9px 16px;cursor:pointer;transition:.16s}
.quiz-reset:hover{background:rgba(var(--rgb),.08)}

/* сетка глав */
.ch-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px;margin-top:8px}
.ch-tile{position:relative;display:flex;flex-direction:column;padding:22px;border-radius:15px;border:1px solid var(--line);
  background:linear-gradient(180deg,var(--panel2),rgba(8,11,24,.4));backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  transition:.2s;overflow:hidden;--t:var(--accent);--tb:var(--accent-bright);--trgb:var(--rgb)}
.ch-tile::after{content:"";position:absolute;inset:0;border-radius:15px;pointer-events:none;
  box-shadow:inset 0 0 0 1px rgba(var(--trgb),.0);transition:.2s}
.ch-tile:hover{transform:translateY(-3px);border-color:rgba(var(--trgb),.5)}
.ch-tile:hover::after{box-shadow:inset 0 0 0 1px rgba(var(--trgb),.4),0 0 40px -12px rgba(var(--trgb),.5)}
.ct-top{display:flex;align-items:center;gap:11px;margin-bottom:14px}
.ct-n{font-family:var(--display);font-weight:700;font-size:1.05rem;color:#05121a;background:var(--tb);
  width:32px;height:32px;border-radius:8px;display:grid;place-items:center;box-shadow:0 0 16px rgba(var(--trgb),.45)}
.ct-tag{font-family:var(--mono);font-size:.62rem;letter-spacing:.16em;text-transform:uppercase;color:var(--t)}
.ch-tile h3{font-family:var(--display);font-weight:600;font-size:1.16rem;color:var(--ink);margin-bottom:8px}
.ct-topic{color:var(--ink-soft);font-size:.93rem;flex:1}
.ct-foot{display:flex;align-items:center;justify-content:space-between;margin-top:16px;
  padding-top:14px;border-top:1px solid var(--line-soft)}
.ct-form{font-family:var(--mono);font-size:.72rem;color:var(--muted)}
.ct-go{font-family:var(--mono);font-size:.74rem;color:var(--t);letter-spacing:.04em}
.ch-tile.is-soon{opacity:.62}
.ch-tile.is-soon .ct-go{color:var(--muted)}

/* столпы / подход */
.pillars{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:8px}
.pillar{padding:20px;border-radius:13px;border:1px solid var(--line-soft);background:var(--panel)}
.pillar .p-ico{font-size:1.3rem;margin-bottom:10px;filter:drop-shadow(0 0 12px rgba(var(--rgb),.5))}
.pillar h4{font-family:var(--display);font-weight:600;font-size:1.06rem;color:var(--ink);margin-bottom:7px}
.pillar p{color:var(--ink-soft);font-size:.92rem}

/* финальный CTA */
.cta{padding:56px 0}
.cta-inner{position:relative;padding:40px 32px;border-radius:18px;border:1px solid var(--line);overflow:hidden;
  background:linear-gradient(135deg,rgba(var(--rgb),.12),rgba(var(--violet-rgb),.1)),var(--panel2)}
.cta-inner h3{font-family:var(--display);font-weight:700;font-size:clamp(1.5rem,3vw,2rem);margin-bottom:12px;color:var(--ink)}
.cta-inner h3 .em{background:linear-gradient(120deg,var(--accent),var(--violet));-webkit-background-clip:text;background-clip:text;color:transparent}
.cta-inner p{color:var(--ink-soft);max-width:60ch;margin-bottom:22px}

/* навигация пред/след */
.nav-prev-next{max-width:1080px;margin:30px auto 0;padding:0 26px;display:grid;grid-template-columns:1fr 1fr;gap:14px}
.nav-card{padding:16px 18px;border-radius:13px;border:1px solid var(--line);background:var(--panel);transition:.18s;
  display:flex;flex-direction:column;gap:5px}
.nav-card:hover{border-color:rgba(var(--rgb),.5);box-shadow:0 0 26px -10px rgba(var(--rgb),.5)}
.nav-card.next{text-align:right}
.nv-label{font-family:var(--mono);font-size:.66rem;letter-spacing:.14em;text-transform:uppercase;color:var(--accent)}
.nv-title{font-family:var(--display);font-weight:600;color:var(--ink);font-size:1.02rem}

/* наверх */
.to-top{max-width:1080px;margin:24px auto 0;padding:0 26px;text-align:center}
.to-top a{font-family:var(--mono);font-size:.74rem;letter-spacing:.05em;color:var(--accent);
  border:1px solid var(--line);border-radius:20px;padding:9px 20px;transition:.16s}
.to-top a:hover{background:rgba(var(--rgb),.08)}

/* банер-заметка */
.note-banner{max-width:1080px;margin:0 auto;padding:14px 26px}
.note-banner>div{padding:14px 18px;border-radius:12px;border:1px solid var(--line);background:var(--panel);
  border-left:3px solid var(--violet);color:var(--ink-soft);font-size:.92rem}
.note-banner b{color:var(--ink)}

/* подвал */
.footer{margin-top:30px;border-top:1px solid var(--line-soft);padding:40px 0 60px;text-align:center}
.foot-mark{font-size:1.4rem;margin-bottom:12px;filter:drop-shadow(0 0 14px rgba(var(--rgb),.6))}
.footer p{color:var(--muted);font-size:.9rem;margin-bottom:6px}
.footer a{color:var(--accent)}
.foot-links{display:flex;gap:18px;justify-content:center;margin-top:12px;font-family:var(--mono);font-size:.78rem}

/* анимация появления */
@keyframes rise{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
.rise{animation:rise .7s cubic-bezier(.22,.61,.36,1) both}
@media(prefers-reduced-motion:reduce){
  *{animation:none!important;transition:none!important;scroll-behavior:auto!important}
}
@media(max-width:640px){
  .nav-prev-next{grid-template-columns:1fr}
  .topbar-inner{flex-wrap:wrap;gap:10px}.back-link{order:3}
}
"""

_HEAD = """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@500;600;700&family=Hanken+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css">
<script defer src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js"></script>
<script defer src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/contrib/auto-render.min.js"></script>
<style>{css}
:root{{--accent:{a};--accent-bright:{b};--accent-deep:{d};--rgb:{rgb}}}</style>
</head>
"""

def head(title, desc, slug='global'):
    a, b, d, rgb = PALETTE.get(slug, PALETTE['global'])
    return _HEAD.format(title=title, desc=desc, css=_CSS, a=a, b=b, d=d, rgb=rgb)

# прогресс-бар + scroll-spy + KaTeX рендер
NAV_JS = r"""
(function(){
  var bar=document.querySelector('.progress-bar');
  function prog(){ if(!bar) return; var h=document.documentElement;
    var sc=h.scrollTop||document.body.scrollTop, mx=(h.scrollHeight-h.clientHeight)||1;
    bar.style.width=Math.min(100,sc/mx*100)+'%'; }
  document.addEventListener('scroll',prog,{passive:true}); prog();
  var links=[].slice.call(document.querySelectorAll('.section-nav a'));
  var secs=links.map(function(l){ return document.querySelector(l.getAttribute('href')); });
  if('IntersectionObserver' in window && secs.some(Boolean)){
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){ if(e.isIntersecting){ var i=secs.indexOf(e.target);
        links.forEach(function(x){x.classList.remove('active');}); if(i>=0)links[i].classList.add('active'); } });
    },{rootMargin:'-130px 0px -62% 0px'});
    secs.forEach(function(s){ if(s) io.observe(s); });
  }
})();
function renderMath(){ if(window.renderMathInElement) renderMathInElement(document.body,{
  delimiters:[{left:'$$',right:'$$',display:true},{left:'$',right:'$',display:false}], throwOnError:false }); }
if(document.readyState!=='loading') renderMath(); else document.addEventListener('DOMContentLoaded',renderMath);
window.addEventListener('load',renderMath);
"""

# движок квиза: localStorage, разбор по клику, счёт, сброс
QUIZ_JS = r"""const QUIZ_KEY='@@QUIZ_KEY@@';
const QUIZ=@@QUIZ_JSON@@;
let qs={};
function qSave(){ try{localStorage.setItem(QUIZ_KEY,JSON.stringify(qs));}catch(e){} }
function qLoad(){ try{var r=localStorage.getItem(QUIZ_KEY); if(r) qs=JSON.parse(r);}catch(e){qs={};} }
function qBuild(){
  var root=document.getElementById('quiz-root'),h='';
  QUIZ.forEach(function(it,qi){
    h+='<div class="quiz-q" data-q="'+qi+'"><div class="q-text"><span class="q-num">'+(qi+1)+'</span><span>'+it.q+'</span></div><div class="q-options">';
    it.options.forEach(function(o,oi){ h+='<button class="q-opt" data-q="'+qi+'" data-o="'+oi+'">'+o+'</button>'; });
    h+='</div><div class="q-explain" id="qe-'+qi+'">'+it.explain+'</div></div>';
  });
  root.innerHTML=h;
  root.querySelectorAll('.q-opt').forEach(function(b){ b.addEventListener('click',qOpt); });
  Object.keys(qs).forEach(function(qi){ qApply(Number(qi)); });
}
function qApply(qi){
  var it=QUIZ[qi],st=qs[qi]; if(!st) return;
  var el=document.querySelector('.quiz-q[data-q="'+qi+'"]'); if(!el) return;
  el.querySelectorAll('.q-opt').forEach(function(b,oi){ b.classList.add('disabled'); if(oi===it.correct) b.classList.add('correct'); else if(oi===st.choice) b.classList.add('incorrect'); });
  document.getElementById('qe-'+qi).classList.add('show');
}
function qOpt(e){ var qi=Number(e.currentTarget.dataset.q),oi=Number(e.currentTarget.dataset.o); if(qs[qi]) return; qs[qi]={correct:oi===QUIZ[qi].correct,choice:oi}; qApply(qi); qSave(); qScore(); }
function qScore(){
  var N=QUIZ.length,ans=Object.keys(qs).length,ok=Object.values(qs).filter(function(s){return s.correct;}).length;
  var el=document.getElementById('quiz-score');
  if(ans===0){ el.textContent='0 / '+N; return; }
  var t=ok+' / '+N+' верно';
  if(ans===N) t+= ok===N?' — отлично!':(ok>=Math.ceil(N*0.6)?' — хорошо!':' — стоит перечитать');
  el.textContent=t;
}
qLoad(); qBuild(); qScore();
document.getElementById('quiz-reset').addEventListener('click',function(){ qs={}; try{localStorage.removeItem(QUIZ_KEY);}catch(e){} qBuild(); qScore(); });"""
