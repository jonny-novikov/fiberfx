#!/usr/bin/env python3
"""Генератор модулей курса «ИИ на работе» (/ai-rabota) на дизайн-системе style.py.
Каждый модуль: 4 раздела + 1 интерактив + квиз из 5 вопросов + навигация.
Здесь собран вводный модуль 1.1 «ИИ как инструмент, а не оракул»."""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style

BASE = os.path.dirname(os.path.abspath(__file__))

# ===== интерактив 1.1: сколько часов в неделю вернёт ИИ =====
HOURS_HTML = """    <div class="task-block">
      <div class="task-head"><span class="task-tag">Интерактив · оценка</span><h4>Сколько часов в неделю вернёт ИИ</h4></div>
      <p class="task-intro">Грубая прикидка: сколько часов в неделю уходит на рутинную задачу, какую долю реально ускорить ИИ и во сколько раз. Точную окупаемость посчитаем в главе «Считать».</p>
      <div class="calc-grid">
        <div class="calc-field"><label>Часов в неделю на задачу</label><input id="hb-t" type="number" inputmode="decimal" value="8"></div>
        <div class="calc-field"><label>Доля, ускоряемая ИИ, проценты</label><input id="hb-p" type="number" inputmode="decimal" value="50"></div>
        <div class="calc-field"><label>Во сколько раз быстрее</label><input id="hb-k" type="number" inputmode="decimal" value="4"></div>
      </div>
      <button class="calc-btn" id="hb-btn">Оценить</button>
      <div class="calc-result" id="hb-res"></div>
      <div class="disclaimer">Учебная оценка: значения нигде не сохраняются и не передаются. Год — 48 рабочих недель.</div>
    </div>"""

HOURS_JS = """function hbFmt(x){ return (Math.round(x*10)/10).toString().replace('.',','); }
function hbCalc(){
  var res=document.getElementById('hb-res');
  function show(h){ res.innerHTML=h; res.classList.add('show'); }
  var t=parseFloat(document.getElementById('hb-t').value),
      p=parseFloat(document.getElementById('hb-p').value),
      k=parseFloat(document.getElementById('hb-k').value);
  if(isNaN(t)||isNaN(p)||isNaN(k)){ show('<p class="cr-t">Заполните все три поля.</p>'); return; }
  if(t<0||p<0){ show('<p class="cr-t">Значения не бывают отрицательными.</p>'); return; }
  if(k<1){ show('<p class="cr-t">Ускорение — это «во сколько раз», оно не меньше 1.</p>'); return; }
  if(p>100) p=100;
  var saved=t*(p/100)*(1-1/k), yearly=saved*48;
  show('<div class="cr-big">'+hbFmt(saved)+' ч/нед</div><p class="cr-t">Это около '+hbFmt(yearly)+' часов в год. Но вернёте вы их только если будете проверять ответы ИИ — иначе время уйдёт на исправление ошибок. Этому курс и учит.</p>');
}
document.getElementById('hb-btn').addEventListener('click', hbCalc);"""

M11 = dict(
    slug='instrument', chapter='vvedenie', pal='vvedenie', num='1.1', name='ИИ как инструмент',
    chnum='1', chname='Введение',
    title='Модуль 1.1 · ИИ как инструмент, а не оракул · ИИ на работе',
    desc='Вводный модуль 1.1: три глагола курса (считать, проверять, автоматизировать), почему ИИ — инструмент с ненулевой ошибкой, и сколько часов он может вернуть. Интерактивная оценка и самопроверка.',
    kicker='Глава 1 · Модуль 1.1',
    h1='ИИ как инструмент, <span class="em">а не оракул</span>',
    hero_formula='t \\cdot p \\cdot \\left(1 - \\frac{1}{k}\\right)',
    lead='ИИ кажется всезнающим, но это инструмент с ненулевой ошибкой. Польза появляется не от слепого доверия, а от трёх навыков: считать выгоду, проверять ответ и автоматизировать то, что окупается.',
    secnav=['Три глагола', 'Инструмент, не оракул', 'Сколько вернёт', 'Как учиться'],
    sections=[
        """    <div class="sect-head"><span class="kicker">Раздел 1 · Три глагола</span><h2>Три <span class="em">глагола</span> курса</h2><p class="lead">Весь курс держится на трёх действиях, вынесенных в название.</p></div>
    <div class="sect-block"><ul>
      <li><b>Считать.</b> Оценивать выгоду: стоит ли вообще доверять задачу ИИ и окупится ли автоматизация.</li>
      <li><b>Проверять.</b> Не принимать ответ на веру: сверять числа, факты и источники.</li>
      <li><b>Автоматизировать.</b> Ставить задачу модели как техзадание и встраивать ИИ туда, где он окупается.</li>
    </ul>
    <div class="callout">Эти три глагола — и есть «прикладной ИИ»: не магия, а инструмент, которым пользуются осознанно.</div></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 2 · Инструмент, не оракул</span><h2>Инструмент, <span class="em">а не оракул</span></h2><p class="lead">У ИИ есть сильные стороны и ненулевая вероятность ошибки.</p></div>
    <div class="sect-block"><ul>
      <li>ИИ хорош в черновиках, переформулировании, разборе и рутине по образцу.</li>
      <li>Он может уверенно выдумать факт, число или источник — это не «сбой», а свойство.</li>
      <li>Поэтому ценность = польза от скорости <b>минус</b> риск необнаруженной ошибки.</li>
    </ul>
    <div class="callout warn"><b>Главная ловушка — слепое доверие.</b> Уверенный тон ответа не означает его правильность. Любой результат, который что-то решает, нужно проверять.</div></div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 3 · Сколько вернёт</span><h2>Сколько времени <span class="em">это вернёт</span></h2><p class="lead">Прикинем верхнюю оценку выигрыша от ускорения рутинной задачи.</p></div>
    <div class="formula-box"><div class="fb-cap">Сэкономленное время в неделю</div>$$E = t \\cdot p \\cdot \\left(1 - \\frac{1}{k}\\right)$$</div>
    <div class="sect-block"><ul>
      <li><b>$t$</b> — часов в неделю на задачу, <b>$p$</b> — доля, которую ускоряет ИИ, <b>$k$</b> — во сколько раз быстрее.</li>
      <li>Пример: $8$ часов, половина задачи и ускорение в $4$ раза дают около $3$ часов в неделю.</li>
      <li>Это <em>верхняя</em> оценка: без проверки часть выигрыша съедают ошибки.</li>
    </ul>
""" + HOURS_HTML + """
    </div>""",
        """    <div class="sect-head"><span class="kicker">Раздел 4 · Как учиться</span><h2>Как устроен <span class="em">курс</span></h2><p class="lead">Дальше каждый модуль идёт по одной схеме.</p></div>
    <div class="sect-block"><ul>
      <li>Четыре коротких раздела, один интерактив и квиз из пяти вопросов.</li>
      <li>Главы по порядку: проверять, считать, промт как спецификация, сценарии по ролям, план внедрения.</li>
      <li>Все цифры в калькуляторах заранее проверены — им можно доверять как опоре для своих расчётов.</li>
    </ul>
    <div class="callout">Следующий шаг — научиться проверять ответы ИИ, чтобы сэкономленное время не утекало в исправление ошибок.</div></div>""",
    ],
    takeaway=[
        'ИИ — инструмент с ненулевой ошибкой, а не оракул; пользу от него нужно считать и проверять.',
        'Три глагола курса: считать, проверять, автоматизировать.',
        'Сэкономленное время: $E = t \\cdot p \\cdot \\left(1 - \\frac{1}{k}\\right)$ — но только при проверке ответов.',
        'Уверенный тон ответа не равен правильности: всё, что что-то решает, проверяем.',
    ],
    quiz=[
        {"q": "Какая главная идея курса об ИИ?", "options": ["ИИ — инструмент с ненулевой ошибкой, пользу нужно считать и проверять", "ИИ — оракул, которому можно доверять", "ИИ всегда ошибается и бесполезен", "ИИ заменит любого работника"], "correct": 0,
         "explain": "<b>Инструмент с ошибкой.</b> Ценность — в осознанном использовании, а не в слепом доверии."},
        {"q": "Три глагола курса — это:", "options": ["считать, проверять, автоматизировать", "читать, писать, считать", "копировать, вставлять, отправлять", "спросить, поверить, забыть"], "correct": 0,
         "explain": "<b>Считать, проверять, автоматизировать.</b> Они вынесены в название."},
        {"q": "Почему нельзя доверять ответу ИИ вслепую?", "options": ["он может уверенно выдумать факт, число или источник", "он отвечает слишком медленно", "он не понимает русский", "он всегда отказывается отвечать"], "correct": 0,
         "explain": "<b>Выдуманные факты.</b> Уверенный тон не означает правильность."},
        {"q": "Что значит «считать» применительно к ИИ?", "options": ["оценивать выгоду против риска ошибки и стоимости настройки", "складывать числа в уме", "считать символы в ответе", "считать, сколько раз спросил"], "correct": 0,
         "explain": "<b>Ожидаемая ценность.</b> Польза от скорости минус риск ошибки."},
        {"q": "По оценке: 8 ч/нед, половина задачи, ускорение в 4 раза — экономия около:", "options": ["3 часов в неделю", "8 часов в неделю", "30 минут в неделю", "16 часов в неделю"], "correct": 0,
         "explain": "<b>3 часа.</b> $8 \\cdot 0{,}5 \\cdot (1 - \\tfrac{1}{4}) = 3$."},
    ],
    interactive_js=HOURS_JS, quiz_key='air-vvedenie-instrument-quiz',
    prev=('/ai-rabota', 'К курсу', 'ИИ на работе'),
    nxt=('/ai-rabota/vvedenie/silnye-slabye', 'Модуль 1.2', 'Сильные и слабые стороны'),
)

MODULES = [M11]

_BODY = """<body id="top">
<div class="progress-bar"></div>

<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="/ai-rabota">
      <div class="brand-mark">&#9651;</div>
      <div class="brand-text"><span class="brand-name">ИИ на работе</span><span class="brand-sub">__CHNAME__</span></div>
    </a>
    <nav class="breadcrumb"><a href="/ai-rabota">Курс</a><span class="sep">/</span><a href="/ai-rabota#program">Гл. __CHNUM__</a><span class="sep">/</span><span class="current">__NUM__</span></nav>
    <a class="back-link" href="/ai-rabota">К курсу</a>
  </div>
</header>

<section class="hero">
  <div class="container">
    <span class="kicker rise">__KICKER__</span>
    <h1 class="rise">__H1__</h1>
    <div class="chip-row rise"><span class="chip"><span class="fc-l">формула</span> $__HEROF__$</span></div>
    <p class="hero-lead rise">__LEAD__</p>
  </div>
</section>

<div class="note-banner"><div><b>Заметка.</b> Образовательный материал по прикладному ИИ. Инструменты быстро меняются — приёмы важнее конкретных кнопок.</div></div>

<nav class="section-nav" aria-label="Навигация по разделам">
  <div class="section-nav-inner">__SECNAV__</div>
</nav>

__SECTIONS__

<section class="sect">
  <div class="container">
    <div class="sect-head"><span class="kicker">Итоги</span><h2>Главное за <span class="em">минуту</span></h2></div>
    <div class="takeaways">__TAKEAWAYS__</div>
  </div>
</section>

<section class="quiz" id="kviz">
  <div class="container">
    <div class="quiz-head"><span class="quiz-tag">Самопроверка</span><span class="quiz-score" id="quiz-score">0 / 5</span></div>
    <p class="quiz-intro">Пять вопросов по модулю. Выберите ответ — сразу увидите верный вариант и пояснение. Прогресс сохраняется в браузере.</p>
    <div id="quiz-root"></div>
    <div class="quiz-foot"><button class="quiz-reset" id="quiz-reset">Сбросить</button></div>
  </div>
</section>

<nav class="nav-prev-next">
  <a class="nav-card prev" href="__PREVH__"><span class="nv-label">__PREVL__</span><span class="nv-title">__PREVT__</span></a>
  <a class="nav-card next" href="__NEXTH__"><span class="nv-label">__NEXTL__</span><span class="nv-title">__NEXTT__</span></a>
</nav>
<div class="to-top"><a href="#top">&uarr; Наверх</a></div>

<footer class="footer">
  <div class="container">
    <div class="foot-mark">&#9651;</div>
    <p>Курс «ИИ на работе» &middot; __CHNAME__</p>
    <p class="foot-links"><a href="/ai-rabota">К курсу</a><a href="/ai-rabota#program">Программа</a></p>
  </div>
</footer>

<script>
__INTERACTIVE__
__QUIZJS__
__NAVJS__
</script>
</body>
</html>
"""

def _secnav(labels):
    out = ''
    for i, lab in enumerate(labels):
        out += ('\n    <a href="#s%d"><span class="sn-n">%02d</span>%s</a>' % (i + 1, i + 1, lab))
    return out

def _sections(secs):
    out = ''
    for i, sec in enumerate(secs):
        out += ('\n<section class="sect" id="s%d">\n  <div class="container">\n%s\n  </div>\n</section>\n' % (i + 1, sec))
    return out

def _takeaways(items):
    return ''.join('\n      <div class="takeaway-item">%s</div>' % t for t in items)

def build(c):
    h = style.head(c['title'], c['desc'], slug=c['pal'])
    quizjs = (style.QUIZ_JS
              .replace('@@QUIZ_KEY@@', c['quiz_key'])
              .replace('@@QUIZ_JSON@@', json.dumps(c['quiz'], ensure_ascii=False, indent=2)))
    body = _BODY
    rep = {
        '__CHNAME__': c['chname'], '__CHNUM__': c['chnum'], '__NUM__': c['num'],
        '__KICKER__': c['kicker'], '__H1__': c['h1'], '__HEROF__': c['hero_formula'], '__LEAD__': c['lead'],
        '__SECNAV__': _secnav(c['secnav']), '__SECTIONS__': _sections(c['sections']),
        '__TAKEAWAYS__': _takeaways(c['takeaway']),
        '__PREVH__': c['prev'][0], '__PREVL__': c['prev'][1], '__PREVT__': c['prev'][2],
        '__NEXTH__': c['nxt'][0], '__NEXTL__': c['nxt'][1], '__NEXTT__': c['nxt'][2],
        '__INTERACTIVE__': c['interactive_js'], '__QUIZJS__': quizjs, '__NAVJS__': style.NAV_JS,
    }
    for k, v in rep.items():
        body = body.replace(k, v)
    out_dir = os.path.join(BASE, 'site', 'ai-rabota', c['chapter'])
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, c['slug'] + '.html')
    open(out, 'w', encoding='utf-8').write(h + body)
    print('written:', out, '|', len(h + body), 'bytes')

if __name__ == '__main__':
    for c in MODULES:
        build(c)
