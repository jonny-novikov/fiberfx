#!/usr/bin/env python3
"""Статическая проверка контракта страниц курса «ИИ на работе»:
Главная, лендинги 6 глав и модуль 1.1. Квиз рендерится в браузере из JSON,
поэтому число вопросов проверяется по встроенному массиву QUIZ."""
import os, re, sys

BASE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(BASE, 'site')
fails = 0

def count(s, pat):
    return len(re.findall(pat, s))

def expect(label, got, op, exp):
    global fails
    ok = {'==': got == exp, '>=': got >= exp}[op]
    print("  [%s] %-44s %s %s (got %s)" % ('OK ' if ok else 'FAIL', label, op, exp, got))
    if not ok:
        fails += 1

print("=== Главная /ai-rabota ===")
land = open(os.path.join(SITE, 'ai-rabota', 'index.html'), encoding='utf-8').read()
expect('прогресс-бар', count(land, r'class="progress-bar"'), '==', 1)
expect('section-nav пунктов', count(land, r'class="sn-n"'), '==', 6)
expect('плиток глав (ch-tile)', count(land, r'class="ch-tile'), '==', 6)
expect('все плитки — ссылки', count(land, r'<a class="ch-tile'), '==', 6)
expect('столпов (pillar)', count(land, r'class="pillar '), '==', 4)
expect('флагман-интерактив (task-block)', count(land, r'class="task-block'), '==', 1)
expect('кнопка #ro-btn', count(land, r'id="ro-btn"'), '==', 1)
expect('ссылки на лендинги глав', count(land, r'href="/ai-rabota/(vvedenie|proverka|schitat|promt|scenarii|vnedrenie)"'), '==', 6)
expect('футер', count(land, r'<footer'), '==', 1)
expect('кнопка наверх', count(land, r'class="to-top"'), '==', 1)

CHAP = [('vvedenie', 3), ('proverka', 4), ('schitat', 4), ('promt', 4), ('scenarii', 4), ('vnedrenie', 4)]
for slug, nmod in CHAP:
    print("\n=== Лендинг главы /ai-rabota/%s ===" % slug)
    s = open(os.path.join(SITE, 'ai-rabota', slug, 'index.html'), encoding='utf-8').read()
    expect('прогресс-бар', count(s, r'class="progress-bar"'), '==', 1)
    expect('section-nav пунктов (2)', count(s, r'class="sn-n"'), '==', 2)
    expect('плиток модулей (ch-tile)', count(s, r'class="ch-tile'), '==', nmod)
    expect('герой-чип (chip-row)', count(s, r'class="chip-row'), '==', 1)
    expect('CTA (cta-inner)', count(s, r'class="cta-inner'), '==', 1)
    expect('nav-card пред/след (2)', count(s, r'class="nav-card'), '==', 2)
    expect('кнопка наверх', count(s, r'class="to-top"'), '==', 1)
    expect('футер', count(s, r'<footer'), '==', 1)
    expect('хлебные крошки .current', count(s, r'class="current"'), '==', 1)

print("\n=== Модуль 1.1 /ai-rabota/vvedenie/instrument ===")
mod = open(os.path.join(SITE, 'ai-rabota', 'vvedenie', 'instrument.html'), encoding='utf-8').read()
expect('section-nav пунктов (4)', count(mod, r'<a href="#s\d"'), '==', 4)
expect('разделов .sect[id=sN] (4)', count(mod, r'<section class="sect" id="s\d"'), '==', 4)
expect('пунктов-итогов (takeaway-item, 4)', count(mod, r'class="takeaway-item"'), '==', 4)
expect('интерактив (task-block, 1)', count(mod, r'class="task-block"'), '==', 1)
expect('блок квиза #quiz-root', count(mod, r'id="quiz-root"'), '==', 1)
expect('вопросов в массиве QUIZ ("q":)', count(mod, r'"q":'), '==', 5)
expect('nav-card пред/след (2)', count(mod, r'class="nav-card'), '==', 2)
expect('ключ localStorage air-', count(mod, r"air-vvedenie-instrument-quiz"), '>=', 1)

print("\n%s" % ('ВСЁ ОК' if fails == 0 else ('ОШИБОК: %d' % fails)))
sys.exit(1 if fails else 0)
