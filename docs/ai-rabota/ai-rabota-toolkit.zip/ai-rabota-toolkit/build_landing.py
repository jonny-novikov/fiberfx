#!/usr/bin/env python3
"""Главная (продающая) курса «ИИ на работе» (/ai-rabota) на дизайн-системе style.py.
Без эмодзи. Структура продающего лендинга: оффер -> ЦА -> задачи/цели ->
результат и инструмент -> демо-калькулятор -> программа -> почему мы -> CTA."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style

BASE = os.path.dirname(os.path.abspath(__file__))
M11 = '/ai-rabota/vvedenie/instrument'

# главы: (num, slug, accent-slug, заголовок, тема, готова?)
CH = [
    ('1', 'vvedenie',  'vvedenie',  'Введение: ИИ как инструмент', 'Три глагола курса и почему ИИ — инструмент с ненулевой ошибкой, а не оракул.', True),
    ('2', 'proverka',  'proverka',  'Проверять',                   'Как не доверять вслепую: факты, числа и источники в ответах ИИ.', False),
    ('3', 'schitat',   'schitat',   'Считать',                     'Ожидаемая ценность автоматизации: когда задачу действительно стоит автоматизировать.', False),
    ('4', 'promt',     'promt',     'Промт как спецификация',      'Чёткость, примеры и ограничения: промт как техзадание для модели.', False),
    ('5', 'scenarii',  'scenarii',  'Сценарии по ролям',           'Тексты, таблицы, код и анализ — рабочие сценарии для разных ролей.', False),
    ('6', 'vnedrenie', 'vnedrenie', 'План внедрения',              'Личный и командный план плюс финальная самопроверка.', False),
]

AUDIENCE = [
    '<b>Специалисты</b> — аналитики, маркетологи, поддержка, операционка: ускорить рутину без потери качества.',
    '<b>Разработчики</b> — делегировать шаблонную работу ИИ и уверенно проверять результат.',
    '<b>Руководители команд</b> — внедрить ИИ в процессы и считать отдачу, а не верить на слово.',
    '<b>Предприниматели и фрилансеры</b> — высвободить часы и снизить издержки без раздувания штата.',
]

TASKS = [
    'Считать, окупится ли автоматизация конкретной задачи — и за сколько недель.',
    'Оценивать, сколько часов в неделю реально вернёт ИИ именно вам.',
    'Находить выдуманные факты, неверные числа и подменённые источники в ответах модели.',
    'Писать промт как короткое техзадание — с примерами, форматом и ограничениями.',
    'Подбирать ИИ-сценарии под свою роль: тексты, таблицы, код, анализ.',
    'Составлять личный или командный план внедрения и расставлять приоритеты по выгоде.',
]

OUTCOMES = [
    'Рабочий метод «считать → проверять → автоматизировать», применимый к любой задаче.',
    'Набор проверенных калькуляторов: окупаемость автоматизации, экономия часов, цена ошибки.',
    'Чек-листы проверки ответов ИИ, чтобы не терять время на исправление ошибок.',
    'Личный план внедрения ИИ на ближайший месяц — с приоритетами.',
    'Чёткое понимание, какие задачи отдавать ИИ, а какие держать под контролем.',
]

TRUST = [
    ('01', 'Проверяемая математика', 'Каждая цифра в калькуляторах доказана в коде. Никаких выдуманных «процентов эффективности».'),
    ('02', 'Без воды', 'Не «100 промптов, которые всё изменят», а метод, который останется с вами после курса.'),
    ('03', 'Любой ИИ-ассистент', 'Подход не привязан к приложению: ChatGPT, Claude, Gigachat, Copilot — что угодно.'),
    ('04', 'Без рекламы и трекинга', 'Страницы ничего о вас не собирают и открываются мгновенно даже на телефоне.'),
]

ROI_HTML = """    <div class="task-block rise">
      <div class="task-head"><span class="task-tag">Интерактив · окупаемость</span><h4>Окупится ли автоматизация задачи</h4></div>
      <p class="task-intro">Прикиньте рутинную задачу: сколько она занимает сейчас, сколько — с ИИ, как часто повторяется и сколько часов уйдёт на настройку. Посчитаем экономию и срок окупаемости.</p>
      <div class="calc-grid">
        <div class="calc-field"><label>Минут на задачу сейчас</label><input id="ro-tb" type="number" inputmode="decimal" value="30"></div>
        <div class="calc-field"><label>Минут с ИИ</label><input id="ro-ta" type="number" inputmode="decimal" value="6"></div>
        <div class="calc-field"><label>Раз в неделю</label><input id="ro-n" type="number" inputmode="decimal" value="20"></div>
        <div class="calc-field"><label>Часов на настройку (разово)</label><input id="ro-su" type="number" inputmode="decimal" value="8"></div>
      </div>
      <button class="calc-btn" id="ro-btn">Посчитать окупаемость</button>
      <div class="calc-result" id="ro-res"></div>
      <div class="disclaimer">Учебный калькулятор: значения нигде не сохраняются и не передаются. Год считаем как 48 рабочих недель.</div>
    </div>"""

ROI_JS = """function roFmt(x){ return (Math.round(x*100)/100).toString().replace('.',','); }
function roCalc(){
  var res=document.getElementById('ro-res');
  function show(h){ res.innerHTML=h; res.classList.add('show'); }
  var tb=parseFloat(document.getElementById('ro-tb').value),
      ta=parseFloat(document.getElementById('ro-ta').value),
      n=parseFloat(document.getElementById('ro-n').value),
      su=parseFloat(document.getElementById('ro-su').value);
  if(isNaN(tb)||isNaN(ta)||isNaN(n)||isNaN(su)){ show('<p class="cr-t">Заполните все четыре поля.</p>'); return; }
  if(tb<0||ta<0||n<0||su<0){ show('<p class="cr-t">Значения не бывают отрицательными.</p>'); return; }
  if(ta>=tb){ show('<div class="cr-big">Экономии нет</div><p class="cr-t">С ИИ задача должна занимать меньше, чем сейчас. Уменьшите «минут с ИИ».</p>'); return; }
  var weekly=(tb-ta)/60*n, yearly=weekly*48, payback=su/weekly;
  show('<div class="cr-big">'+roFmt(weekly)+' ч/нед · окупится за '+roFmt(payback)+' нед</div>'+
       '<p class="cr-t">Экономия '+roFmt(weekly)+' часов в неделю и около '+roFmt(yearly)+' часов в год. Настройка ('+roFmt(su)+' ч) окупается примерно за '+roFmt(payback)+' недель — дальше время идёт в плюс.</p>');
}
document.getElementById('ro-btn').addEventListener('click', roCalc);"""

def _tiles():
    out = ''
    for num, slug, pal, title, topic, ready in CH:
        a, b, d, rgb = style.PALETTE[pal]
        st = '--t:%s;--tb:%s;--trgb:%s' % (a, b, rgb)
        foot = 'модуль 1.1 готов' if ready else 'обзор главы'
        out += ('\n        <a class="ch-tile rise" style="%s;animation-delay:%.2fs" href="/ai-rabota/%s">'
                '<div class="ct-top"><span class="ct-n">%s</span><span class="ct-tag">Глава %s</span></div>'
                '<h3>%s</h3><p class="ct-topic">%s</p>'
                '<div class="ct-foot"><span class="ct-form">%s</span><span class="ct-go">Открыть &rarr;</span></div></a>'
                % (st, 0.04 * int(num), slug, num, num, title, topic, foot))
    return out

def _ul(items):
    return ''.join('\n      <li>%s</li>' % it for it in items)

def _take(items):
    return ''.join('\n      <div class="takeaway-item">%s</div>' % it for it in items)

def _trust(cards):
    out = ''
    for num, title, desc in cards:
        out += ('\n      <div class="pillar rise">'
                '<div class="p-ico" style="font-family:var(--mono);font-size:1rem;font-weight:600;color:var(--accent);letter-spacing:.08em">%s</div>'
                '<h4>%s</h4><p>%s</p></div>' % (num, title, desc))
    return out

def build():
    h = style.head(
        'ИИ на работе: считать, проверять, автоматизировать — курс',
        'Курс для специалистов, команд и предпринимателей: научитесь считать выгоду автоматизации, проверять ответы ИИ и внедрять его там, где он окупается. С калькуляторами, чек-листами и планом внедрения.',
        slug='global')

    body = """<body id="top">
<div class="progress-bar"></div>

<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="/ai-rabota">
      <div class="brand-mark">&#9651;</div>
      <div class="brand-text"><span class="brand-name">ИИ на работе</span><span class="brand-sub">Прикладной ИИ</span></div>
    </a>
    <nav class="breadcrumb"><span class="current">Курс</span></nav>
    <a class="back-link" href="/">Все курсы</a>
  </div>
</header>

<section class="hero">
  <div class="container">
    <span class="kicker rise">Онлайн-курс &middot; прикладной ИИ для работы</span>
    <h1 class="rise">ИИ на работе: <span class="em">считать, проверять, автоматизировать</span></h1>
    <div class="chip-row rise">
      <span class="chip"><span class="fc-l">01</span>Считать</span>
      <span class="chip"><span class="fc-l">02</span>Проверять</span>
      <span class="chip"><span class="fc-l">03</span>Автоматизировать</span>
    </div>
    <p class="hero-lead rise">Перестаньте тратить часы на рутину и проверять ИИ наугад. За шесть глав вы научитесь считать выгоду автоматизации, проверять ответы модели и внедрять ИИ там, где он действительно окупается.</p>
    <p class="rise" style="color:var(--muted);font-family:var(--mono);font-size:.82rem;letter-spacing:.03em;margin:-10px 0 26px">Для специалистов, команд и предпринимателей, которые работают с ИИ каждый день.</p>
    <div class="btn-row rise">
      <a class="btn primary" href="__M11__">Начать курс &rarr;</a>
      <a class="btn ghost" href="#program">Программа курса</a>
    </div>
    <div class="stat-row rise" style="margin-top:32px">
      <div class="stat"><b>6</b><span>глав: от основ до внедрения</span></div>
      <div class="stat"><b>ROI</b><span>всё считаем в часах и деньгах</span></div>
      <div class="stat"><b>0</b><span>воды, рекламы и трекинга</span></div>
    </div>
  </div>
</section>

<div class="note-banner"><div><b>Формат.</b> Самодостаточные страницы с живыми калькуляторами и самопроверками. Метод не привязан к конкретному приложению и обновляется вслед за инструментами ИИ.</div></div>

<nav class="section-nav" aria-label="Навигация по разделам">
  <div class="section-nav-inner">
    <a href="#dlya-kogo"><span class="sn-n">01</span>Для кого</a>
    <a href="#zadachi"><span class="sn-n">02</span>Задачи</a>
    <a href="#rezultat"><span class="sn-n">03</span>Результат</a>
    <a href="#calc"><span class="sn-n">04</span>Калькулятор</a>
    <a href="#program"><span class="sn-n">05</span>Программа</a>
    <a href="#start"><span class="sn-n">06</span>Старт</a>
  </div>
</nav>

<section class="sect" id="dlya-kogo">
  <div class="container">
    <div class="sect-head"><span class="kicker">Для кого</span><h2>Кому подойдёт <span class="em">курс</span></h2><p class="lead">Для тех, кто уже пользуется ИИ на работе, но хочет делать это системно и с измеримой пользой, а не наугад.</p></div>
    <div class="sect-block"><ul>__AUDIENCE__
    </ul></div>
    <div class="callout warn"><b>Курс не подойдёт,</b> если вы ищете «волшебную кнопку» или список готовых промптов без понимания, что и зачем вы делаете.</div>
  </div>
</section>

<section class="sect" id="zadachi">
  <div class="container">
    <div class="sect-head"><span class="kicker">Цель курса</span><h2>Какие задачи научитесь <span class="em">решать</span></h2><p class="lead">Курс ведёт к конкретным навыкам. После него вы сможете сами:</p></div>
    <div class="sect-block"><ul>__TASKS__
    </ul></div>
  </div>
</section>

<section class="sect" id="rezultat">
  <div class="container">
    <div class="sect-head"><span class="kicker">Результат</span><h2>Что у вас будет в <span class="em">конце курса</span></h2><p class="lead">Не просто «посмотрел видео», а рабочие инструменты, которые останутся с вами.</p></div>
    <div class="takeaways">__OUTCOMES__
    </div>
    <div class="formula-box" style="margin-top:26px"><div class="fb-cap">Какой инструмент вы освоите</div>
      <p style="color:var(--ink-soft);font-size:1.02rem">Главный инструмент курса — не конкретное приложение, а <b>метод</b>. Он работает с любым ИИ-ассистентом (ChatGPT, Claude, Gigachat, Copilot и другими): вы применяете один и тот же подход независимо от модели. Плюс набор калькуляторов, которые превращают расплывчатое «ИИ помогает» в конкретные часы и деньги.</p>
    </div>
  </div>
</section>

<section class="sect" id="calc">
  <div class="container">
    <div class="sect-head"><span class="kicker">Попробуйте сейчас</span><h2>Главный вопрос курса — <span class="em">в одной формуле</span></h2><p class="lead">Окупаемость автоматизации: стоимость настройки, делённая на еженедельную экономию времени. Посчитайте на своей задаче.</p></div>
    <div class="formula-box"><div class="fb-cap">Срок окупаемости</div>$$P = \\frac{C}{(t_1 - t_2)\\,n}$$</div>
""" + ROI_HTML + """
  </div>
</section>

<section class="sect" id="program">
  <div class="container">
    <div class="sect-head"><span class="kicker">Программа</span><h2>Шесть <span class="em">глав</span></h2><p class="lead">От картины «что ИИ умеет» — к проверке, расчёту окупаемости, постановке задач, сценариям по ролям и плану внедрения. Сейчас открыт вводный модуль 1.1.</p></div>
    <div class="ch-grid">__TILES__
    </div>
  </div>
</section>

<section class="sect" id="pochemu">
  <div class="container">
    <div class="sect-head"><span class="kicker">Почему этот курс</span><h2>Чем он <span class="em">отличается</span></h2><p class="lead">Четыре принципа, по которым собран весь курс.</p></div>
    <div class="pillars">__TRUST__
    </div>
  </div>
</section>

<section class="cta" id="start">
  <div class="container">
    <div class="cta-inner rise">
      <h3>Начните с <span class="em">введения</span></h3>
      <p>Модуль 1.1 открыт и задаёт рамку всего курса: три глагола, почему ИИ — инструмент с ненулевой ошибкой и сколько времени он реально может вам вернуть.</p>
      <a class="btn primary" href="__M11__">Открыть модуль 1.1 &rarr;</a>
    </div>
  </div>
</section>

<div class="to-top"><a href="#top">&uarr; Наверх</a></div>

<footer class="footer">
  <div class="container">
    <div class="foot-mark">&#9651;</div>
    <p>Курс «ИИ на работе: считать, проверять, автоматизировать»</p>
    <p>Прикладной ИИ &middot; считать, проверять, автоматизировать</p>
    <p class="foot-links"><a href="/">Все курсы</a><a href="#program">Программа</a><a href="__M11__">Начать</a></p>
  </div>
</footer>

<script>
""" + ROI_JS + "\n" + style.NAV_JS + """
</script>
</body>
</html>
"""
    body = (body.replace('__AUDIENCE__', _ul(AUDIENCE)).replace('__TASKS__', _ul(TASKS))
                .replace('__OUTCOMES__', _take(OUTCOMES)).replace('__TRUST__', _trust(TRUST))
                .replace('__TILES__', _tiles()).replace('__M11__', M11))
    out_dir = os.path.join(BASE, 'site', 'ai-rabota')
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, 'index.html')
    open(out, 'w', encoding='utf-8').write(h + body)
    print('written:', out, '|', len(h + body), 'bytes')

if __name__ == '__main__':
    build()
