#!/usr/bin/env python3
"""Лендинги глав курса «ИИ на работе» (/ai-rabota/<глава>) на дизайн-системе style.py.
Каждая глава: герой с формулой/схемой, обзор + ключевые тезисы, плитки модулей,
CTA и навигация пред/след. Цепочка: Курс -> Гл.1 -> ... -> Гл.6 -> Курс."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style

BASE = os.path.dirname(os.path.abspath(__file__))

CHAPTERS = [
    dict(
        slug='vvedenie', num='1', pal='vvedenie',
        title='Глава 1 · Введение: ИИ как инструмент · ИИ на работе',
        desc='Глава 1: три глагола курса (считать, проверять, автоматизировать), ИИ как инструмент с ненулевой ошибкой и оценка сэкономленного времени. Вводный модуль 1.1 уже доступен.',
        kicker='Глава 1 · Введение',
        h1='ИИ как <span class="em">инструмент</span>',
        hero_formula='E = t \\cdot p \\cdot \\left(1 - \\frac{1}{k}\\right)',
        lead='С чего начать: понять, что ИИ — мощный, но небезошибочный инструмент, и освоить три глагола курса.',
        intro='Вводная глава задаёт рамку. ИИ ускоряет работу, но уверенно ошибается, поэтому пользу нужно считать и проверять. Здесь — три глагола курса и первая оценка того, сколько времени ИИ может вам вернуть.',
        points=[
            '<b>Три глагола:</b> считать, проверять, автоматизировать — каркас всего курса.',
            '<b>Инструмент, а не оракул:</b> у ИИ ненулевая вероятность ошибки.',
            '<b>Сколько вернёт:</b> верхняя оценка экономии, $E = t \\cdot p \\cdot (1 - \\frac{1}{k})$.',
            '<b>Как учиться:</b> каждый модуль — четыре раздела, интерактив и квиз.',
        ],
        mods=[
            ('1.1', 'instrument', 'ИИ как инструмент, а не оракул', 'Три глагола, инструмент против оракула и оценка экономии времени.', True),
            ('1.2', 'silnye-slabye', 'Сильные и слабые стороны ИИ', 'Где ИИ силён, а где предсказуемо ошибается.', False),
            ('1.3', 'oshibki', 'Где ИИ ошибается', 'Выдуманные факты, числа и источники — и почему это свойство.', False),
        ],
        ready=True,
        start=('/ai-rabota/vvedenie/instrument', 'Открыть модуль 1.1 &rarr;'),
        prev=('/ai-rabota', 'К курсу', 'ИИ на работе'),
        nxt=('/ai-rabota/proverka', 'Глава 2', 'Проверять'),
    ),
    dict(
        slug='proverka', num='2', pal='proverka',
        title='Глава 2 · Проверять · ИИ на работе',
        desc='Глава 2: как не доверять ответам ИИ вслепую — проверка фактов, источников и чисел, и цена непойманной ошибки.',
        kicker='Глава 2 · Проверять',
        h1='<span class="em">Проверять</span>',
        hero_formula='R = q \\cdot C',
        lead='ИИ ошибается уверенно. Эта глава — про то, как ловить ошибки до того, как они дорого обойдутся.',
        intro='Главный риск ИИ — не медлительность, а правдоподобная ошибка. Цена непойманной ошибки растёт с её вероятностью и последствиями. Учимся проверять факты, числа и источники — и понимать, где проверять особенно тщательно.',
        points=[
            '<b>Почему вслепую нельзя:</b> уверенный тон не равен правильности.',
            '<b>Факты и источники:</b> как отличить настоящую ссылку от выдуманной.',
            '<b>Числа и расчёты:</b> перепроверка вычислений ИИ.',
            '<b>Цена ошибки:</b> ожидаемый риск $R = q \\cdot C$ задаёт глубину проверки.',
        ],
        mods=[
            ('2.1', 'doverie', 'Почему нельзя доверять вслепую', 'Уверенный тон против правильности.', False),
            ('2.2', 'fakty', 'Проверка фактов и источников', 'Как поймать выдуманную ссылку.', False),
            ('2.3', 'chisla', 'Проверка чисел и расчётов', 'Перепроверяем арифметику ИИ.', False),
            ('2.4', 'cena-oshibki', 'Цена ошибки', 'Когда проверять особенно тщательно.', False),
        ],
        ready=False,
        start=('/ai-rabota', 'К программе курса'),
        prev=('/ai-rabota/vvedenie', 'Глава 1', 'Введение'),
        nxt=('/ai-rabota/schitat', 'Глава 3', 'Считать'),
    ),
    dict(
        slug='schitat', num='3', pal='schitat',
        title='Глава 3 · Считать · ИИ на работе',
        desc='Глава 3: ожидаемая ценность автоматизации — экономия времени, срок окупаемости и когда автоматизировать не стоит.',
        kicker='Глава 3 · Считать',
        h1='<span class="em">Считать</span>',
        hero_formula='P = \\frac{C}{(t_1 - t_2)\\,n}',
        lead='Когда автоматизация действительно окупается? Считаем экономию времени, срок окупаемости и ожидаемую ценность.',
        intro='«Считать» — это переводить ощущение «ИИ помогает» в числа: сколько времени экономит задача, за сколько окупится настройка и как ошибки уменьшают выгоду. Эта математика отделяет окупаемую автоматизацию от модной.',
        points=[
            '<b>Экономия времени:</b> $(t_1 - t_2)\\,n$ — сколько часов в неделю освобождается.',
            '<b>Окупаемость:</b> $P = \\frac{C}{(t_1 - t_2)\\,n}$ — за сколько вернётся настройка.',
            '<b>Ожидаемая ценность:</b> выгода минус риск ошибки.',
            '<b>Когда не стоит:</b> редкие или слишком рискованные задачи.',
        ],
        mods=[
            ('3.1', 'ekonomiya', 'Экономия времени', 'Считаем освобождённые часы в неделю.', False),
            ('3.2', 'okupaemost', 'Окупаемость автоматизации', 'За сколько вернётся настройка.', False),
            ('3.3', 'ozhidaemaya-cennost', 'Ожидаемая ценность', 'Выгода с поправкой на ошибки.', False),
            ('3.4', 'kogda-ne-stoit', 'Когда не стоит', 'Редкие и рискованные задачи.', False),
        ],
        ready=False,
        start=('/ai-rabota', 'К программе курса'),
        prev=('/ai-rabota/proverka', 'Глава 2', 'Проверять'),
        nxt=('/ai-rabota/promt', 'Глава 4', 'Промт как спецификация'),
    ),
    dict(
        slug='promt', num='4', pal='promt',
        title='Глава 4 · Промт как спецификация · ИИ на работе',
        desc='Глава 4: промт как техзадание — чёткая задача, примеры и формат, ограничения и итеративное уточнение.',
        kicker='Глава 4 · Промт',
        h1='Промт как <span class="em">спецификация</span>',
        chip_text='задача · примеры · ограничения',
        lead='Хороший промт — это короткое техзадание. Учимся ставить задачу так, чтобы ответ был предсказуемым и пригодным.',
        intro='Промт — не «заклинание», а спецификация: что нужно, в каком формате и чего делать нельзя. Чем чётче задача, примеры и ограничения, тем меньше итераций и тем надёжнее результат.',
        points=[
            '<b>Чёткая задача:</b> что именно нужно и зачем.',
            '<b>Примеры и формат:</b> образец ответа экономит итерации.',
            '<b>Ограничения:</b> длина, тон, что нельзя — часть техзадания.',
            '<b>Итерации:</b> как уточнять, а не начинать заново.',
        ],
        mods=[
            ('4.1', 'zadacha', 'Чёткая задача', 'Что нужно и зачем.', False),
            ('4.2', 'primery', 'Примеры и формат', 'Образец ответа как ориентир.', False),
            ('4.3', 'ogranicheniya', 'Ограничения и контекст', 'Длина, тон, запреты.', False),
            ('4.4', 'iteracii', 'Итерации и уточнение', 'Уточнять, а не начинать заново.', False),
        ],
        ready=False,
        start=('/ai-rabota', 'К программе курса'),
        prev=('/ai-rabota/schitat', 'Глава 3', 'Считать'),
        nxt=('/ai-rabota/scenarii', 'Глава 5', 'Сценарии по ролям'),
    ),
    dict(
        slug='scenarii', num='5', pal='scenarii',
        title='Глава 5 · Сценарии по ролям · ИИ на работе',
        desc='Глава 5: рабочие сценарии для текстов, таблиц, кода и анализа — где ИИ ускоряет и как сохранить контроль качества.',
        kicker='Глава 5 · Сценарии',
        h1='Сценарии по <span class="em">ролям</span>',
        chip_text='тексты · таблицы · код · анализ',
        lead='Где ИИ помогает в вашей работе: разбираем рабочие сценарии для текстов, таблиц, кода и анализа.',
        intro='От общих принципов — к конкретным задачам. Тексты и письма, таблицы и данные, код и рутина, анализ и решения: для каждой роли — где ИИ ускоряет и как при этом не потерять контроль качества.',
        points=[
            '<b>Тексты:</b> черновики, письма, переформулирование.',
            '<b>Таблицы и данные:</b> разбор, формулы, очистка.',
            '<b>Код:</b> рутина, шаблоны, объяснение чужого кода.',
            '<b>Анализ:</b> сводки, варианты, проверяемые выводы.',
        ],
        mods=[
            ('5.1', 'teksty', 'Тексты и коммуникация', 'Черновики, письма, переформулирование.', False),
            ('5.2', 'tablicy', 'Таблицы и данные', 'Разбор, формулы, очистка.', False),
            ('5.3', 'kod', 'Код и рутина', 'Шаблоны и объяснение кода.', False),
            ('5.4', 'analiz', 'Анализ и решения', 'Сводки и проверяемые выводы.', False),
        ],
        ready=False,
        start=('/ai-rabota', 'К программе курса'),
        prev=('/ai-rabota/promt', 'Глава 4', 'Промт как спецификация'),
        nxt=('/ai-rabota/vnedrenie', 'Глава 6', 'План внедрения'),
    ),
    dict(
        slug='vnedrenie', num='6', pal='vnedrenie',
        title='Глава 6 · План внедрения · ИИ на работе',
        desc='Глава 6: как превратить приёмы в систему — приоритизация по выгоде на усилие, личный и командный план, финальная самопроверка.',
        kicker='Глава 6 · Внедрение',
        h1='План <span class="em">внедрения</span>',
        hero_formula='\\frac{V}{U}',
        lead='Как превратить разрозненные приёмы в систему: с чего начать, личный и командный план, финальная самопроверка.',
        intro='Финальная глава собирает всё в план. Начинать стоит с задач, где выгода на усилие выше всего. Дальше — личный план, внедрение в команде и проверка того, что усвоено по всему курсу.',
        points=[
            '<b>Приоритеты:</b> сначала там, где выше $\\frac{V}{U}$ — выгода на усилие.',
            '<b>Личный план:</b> две-три задачи под автоматизацию на месяц.',
            '<b>Команда:</b> общие правила, проверка, обмен промптами.',
            '<b>Финал:</b> сквозная самопроверка по всему курсу.',
        ],
        mods=[
            ('6.1', 'prioritety', 'Что внедрять первым', 'Приоритизация по выгоде на усилие.', False),
            ('6.2', 'lichnyy-plan', 'Личный план', 'Задачи под автоматизацию на месяц.', False),
            ('6.3', 'komanda', 'Внедрение в команде', 'Правила, проверка, обмен промптами.', False),
            ('6.4', 'final', 'Финал и самопроверка', 'Сквозная проверка по всему курсу.', False),
        ],
        ready=False,
        start=('/ai-rabota', 'К программе курса'),
        prev=('/ai-rabota/scenarii', 'Глава 5', 'Сценарии по ролям'),
        nxt=('/ai-rabota', 'К курсу', 'Вернуться к программе'),
    ),
]

_BODY = """<body id="top">
<div class="progress-bar"></div>

<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="/ai-rabota">
      <div class="brand-mark">&#9651;</div>
      <div class="brand-text"><span class="brand-name">ИИ на работе</span><span class="brand-sub">Глава __NUM__</span></div>
    </a>
    <nav class="breadcrumb"><a href="/ai-rabota">Курс</a><span class="sep">/</span><span class="current">Глава __NUM__</span></nav>
    <a class="back-link" href="/ai-rabota">К курсу</a>
  </div>
</header>

<section class="hero">
  <div class="container">
    <span class="kicker rise">__KICKER__</span>
    <h1 class="rise">__H1__</h1>
    <div class="chip-row rise">__CHIP__</div>
    <p class="hero-lead rise">__LEAD__</p>
    <div class="stat-row rise" style="margin-top:26px"><div class="stat"><b>__NMOD__</b><span>модулей в главе</span></div></div>
  </div>
</section>

<div class="note-banner"><div>__NOTE__</div></div>

<nav class="section-nav" aria-label="Навигация по разделам">
  <div class="section-nav-inner">
    <a href="#about"><span class="sn-n">01</span>Обзор</a>
    <a href="#modules"><span class="sn-n">02</span>Модули</a>
  </div>
</nav>

<section class="sect" id="about">
  <div class="container">
    <div class="sect-head"><span class="kicker">Обзор</span><h2>О чём эта <span class="em">глава</span></h2><p class="lead">__INTRO__</p></div>
    <div class="sect-block"><ul>__POINTS__
    </ul></div>
  </div>
</section>

<section class="sect" id="modules">
  <div class="container">
    <div class="sect-head"><span class="kicker">Модули</span><h2>Модули <span class="em">главы</span></h2><p class="lead">Каждый модуль — четыре раздела, один интерактив и квиз из пяти вопросов.</p></div>
    <div class="ch-grid">__TILES__
    </div>
  </div>
</section>

<section class="cta">
  <div class="container">
    <div class="cta-inner rise">
      <h3>__CTAH__</h3>
      <p>__CTAP__</p>
      <a class="btn primary" href="__STARTH__">__STARTL__</a>
    </div>
  </div>
</section>

<nav class="nav-prev-next">
  <a class="nav-card prev" href="__PREVH__"><span class="nv-label">__PREVL__</span><span class="nv-title">__PREVT__</span></a>
  <a class="nav-card next" href="__NEXTH__"><span class="nv-label">__NEXTL__</span><span class="nv-title">__NEXTT__</span></a>
</nav>
<div class="to-top"><a href="#top">&uarr; Наверх</a></div>

<footer class="footer">
  <div class="container">
    <div class="foot-mark">&#9651;</div>
    <p>Курс «ИИ на работе» &middot; Глава __NUM__</p>
    <p class="foot-links"><a href="/ai-rabota">К курсу</a><a href="/ai-rabota#program">Программа</a></p>
  </div>
</footer>

<script>
__NAVJS__
</script>
</body>
</html>
"""

def _points(points):
    return ''.join('\n      <li>%s</li>' % p for p in points)

def _tiles(chapter_slug, mods):
    out = ''
    for i, (mnum, mslug, mtitle, mtopic, ready) in enumerate(mods, 1):
        if ready:
            out += ('\n        <a class="ch-tile rise" style="animation-delay:%.2fs" href="/ai-rabota/%s/%s">'
                    '<div class="ct-top"><span class="ct-n">%d</span><span class="ct-tag">Модуль %s</span></div>'
                    '<h3>%s</h3><p class="ct-topic">%s</p>'
                    '<div class="ct-foot"><span class="ct-form">готов</span><span class="ct-go">Открыть &rarr;</span></div></a>'
                    % (0.04 * i, chapter_slug, mslug, i, mnum, mtitle, mtopic))
        else:
            out += ('\n        <div class="ch-tile is-soon">'
                    '<div class="ct-top"><span class="ct-n">%d</span><span class="ct-tag">Модуль %s</span></div>'
                    '<h3>%s</h3><p class="ct-topic">%s</p>'
                    '<div class="ct-foot"><span class="ct-form">скоро</span><span class="ct-go">в разработке</span></div></div>'
                    % (i, mnum, mtitle, mtopic))
    return out

def build(c):
    h = style.head(c['title'], c['desc'], slug=c['pal'])
    if c.get('hero_formula'):
        chip = '<span class="chip"><span class="fc-l">формула</span> $%s$</span>' % c['hero_formula']
    else:
        chip = '<span class="chip"><span class="fc-l">схема</span> %s</span>' % c['chip_text']
    if c['ready']:
        note = '<b>Глава открыта.</b> Доступен вводный модуль 1.1; остальные модули главы в разработке.'
        ctah = 'Начать <span class="em">главу</span>'
        ctap = 'Первый модуль задаёт рамку всего курса — три глагола и первая оценка выгоды.'
    else:
        note = '<b>Глава в разработке.</b> Обзор, ключевые идеи и список модулей — ниже; страницы модулей появятся по мере готовности.'
        ctah = 'Глава <span class="em">в разработке</span>'
        ctap = 'Модули этой главы скоро появятся. Пока можно вернуться к программе курса или начать с введения.'
    body = _BODY
    rep = {
        '__NUM__': c['num'], '__KICKER__': c['kicker'], '__H1__': c['h1'], '__CHIP__': chip,
        '__LEAD__': c['lead'], '__NMOD__': str(len(c['mods'])), '__NOTE__': note,
        '__INTRO__': c['intro'], '__POINTS__': _points(c['points']),
        '__TILES__': _tiles(c['slug'], c['mods']),
        '__CTAH__': ctah, '__CTAP__': ctap, '__STARTH__': c['start'][0], '__STARTL__': c['start'][1],
        '__PREVH__': c['prev'][0], '__PREVL__': c['prev'][1], '__PREVT__': c['prev'][2],
        '__NEXTH__': c['nxt'][0], '__NEXTL__': c['nxt'][1], '__NEXTT__': c['nxt'][2],
        '__NAVJS__': style.NAV_JS,
    }
    for k, v in rep.items():
        body = body.replace(k, v)
    out_dir = os.path.join(BASE, 'site', 'ai-rabota', c['slug'])
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, 'index.html')
    open(out, 'w', encoding='utf-8').write(h + body)
    print('written:', out, '|', len(h + body), 'bytes')

if __name__ == '__main__':
    for c in CHAPTERS:
        build(c)
