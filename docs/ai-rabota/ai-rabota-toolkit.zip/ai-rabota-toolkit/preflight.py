#!/usr/bin/env python3
"""Преполёт по собранным HTML: запрещённые символы внутри $...$ (KaTeX strict),
вложенные <a>, наличие <body> и <footer>. Запуск: python3 preflight.py <files...>"""
import re, sys

BAD = set('№₽«»“”„…•—–·×÷≤≥≠')

def katex_hits(s):
    out = []
    for m in re.finditer(r'\$\$?[^$]+?\$\$?', s):
        seg = m.group(0)
        bad = [ch for ch in seg if ch in BAD]
        if bad:
            out.append((seg[:50], ''.join(sorted(set(bad)))))
    return out

def nested_anchor(s):
    """Стек по токенам <a ...> / </a>; глубина > 1 => вложение."""
    depth = 0
    for m in re.finditer(r'<a\b|</a>', s, re.I):
        if m.group(0).lower() == '</a>':
            depth = max(0, depth - 1)
        else:
            depth += 1
            if depth > 1:
                return True
    return False

def scan(path):
    s = open(path, encoding='utf-8').read()
    problems = []
    for seg, bad in katex_hits(s):
        problems.append("KaTeX: '%s' содержит [%s]" % (seg, bad))
    if nested_anchor(s):
        problems.append("вложенный <a> внутри <a>")
    if '<body' not in s:
        problems.append("нет <body>")
    if '<footer' not in s:
        problems.append("нет <footer>")
    return problems

def main(paths):
    total = 0
    for p in paths:
        probs = scan(p)
        total += len(probs)
        if probs:
            print("  ✗ %s:" % p)
            for pr in probs:
                print("      -", pr)
        else:
            print("  ✓ %s: 0 проблем" % p)
    print("\nИтого проблем:", total)
    return total

if __name__ == '__main__':
    sys.exit(1 if main(sys.argv[1:]) else 0)
