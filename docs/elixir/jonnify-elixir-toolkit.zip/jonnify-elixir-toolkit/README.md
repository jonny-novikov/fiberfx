# jonnify — Functional Programming in Elixir · authoring toolkit

This archive is the complete toolkit used to author the **"Functional Programming in Elixir"** course on the
**jonnify dark-editorial design system** (live at https://jonnify.fly.dev/elixir). The course is a set of
interconnected static HTML pages, each graded **A+ across nine Apollo quality gates** and assembled by a single
Python builder from hand-authored content fragments. Nothing here is a hand-rolled page; pages are always built,
checked, and validated through the tools below.

## What's in here

| Path | What it is |
| --- | --- |
| `build_page.py` | The single source of truth: the **manifest** (chapters, modules, dives, subpages, pages), the page **assembler**, the **nine quality gates**, and the **branded-Snowflake ID** tools + CLI. |
| `_gen_course_md.py` | Generates `functional-programming-in-elixir.md` (the syllabus) from the manifest's abstract map. |
| `_gen_refs_md.py` | Generates `elixir-references.md` (per-module references) from the manifest's reference map. |
| `_head.html` | The cached `<head>` (design tokens, fonts, the full stylesheet) injected into every page. |
| `content/` | The 96 hand-authored page **fragments** — the source of every page. A fragment starts at the skip-link, not `<head>`. |
| `build-guide/` | Writerside-markdown **build specs** for the course's worked example, the Portal engine (`pragmatic.md` TOC + one guide per module, each with content, specs, actionables, and copy-paste build prompts). |
| `validator/` | A headless Playwright **validation suite** (`suite.elixir.js`) plus the harness (`validator.js`, `visual.js`), its own README, and `package.json`. |
| `docs/` | The two **generated** reference documents, included for convenience (regenerable from the manifest). |
| `SKILL.md` | The operational guide: page anatomy, the nine gates, ID tooling, the authoring workflow. |
| `course-authoring-playbook.md` | The full reference: design tokens, character-escaping rules, navigation conventions, validator semantics. |
| `elixir-progress.md` | The living tracker — build records, headline counts, and the **resume point** for the next module. |
| `CONTINUE-PROMPT.md` | A ready-to-paste prompt for continuing the course in a fresh session. |

> The course's built `*.html` pages are **not** shipped in this archive because they are regenerable: run the build
> (below) to produce them in the working directory from `content/`.

## Prerequisites

- **Python 3** (standard library only — the builder and generators have no third-party deps).
- **Node.js** with **Playwright** for the validator:
  ```bash
  cd validator && npm install        # installs playwright per package.json
  npx playwright install chromium     # one-time browser download
  ```

## Quickstart

From the toolkit root (the directory holding `build_page.py`):

```bash
# 1) list every linkable route (sanity check the manifest)
python3 build_page.py routes | tail -3

# 2) build a page from its manifest key into the working directory
python3 build_page.py build --page f5-5            # -> cqrs.html
python3 build_page.py build --page f5-5-cqs        # -> cqrs-cqs.html

# 3) grade a built page against the nine gates (expect: grade A+)
python3 build_page.py check cqrs.html

# 4) regenerate the syllabus and references from the manifest
python3 _gen_course_md.py
python3 _gen_refs_md.py

# 5) validate behaviour headlessly (build the pages first)
BASE_URL="file://$(pwd)" ONLY="F5" node validator/suite.elixir.js
```

To build every page at once, iterate `build --page <key>` over the keys in `build_page.py`'s `PAGES` dict.

## The nine quality gates

`build_page.py check` grades a page A+ only when it passes all nine: structure/anatomy, the design-token head,
accessibility (skip-link, labelled controls, `aria` on interactive figures), the **voice gate** (no hype words in
*visible* text — including `<pre class="code">` comments), no prose exclamation marks, the **links gate** (every
internal `href` resolves to a `live`/`built` route), the **pager gate**, the branded-Snowflake decoder, and
no-horizontal-overflow. The validator then checks runtime behaviour (selectors, readouts, decoded stamp, mobile
overflow) across desktop and a 390px viewport.

## Branded Snowflake IDs

Every entity and every build stamp is identified by a **Snowflake** — a 64-bit, time-ordered integer (the canonical
identity) — whose transport form is a **branded id**: a 3-letter namespace prefix plus the Base62-encoded snowflake,
e.g. `TSK0KHTOWnGLuC`. Layout (epoch `1704067200000` ms): `timestamp = snowflake >>> 22`,
`node = (snowflake >>> 12) &&& 0x3FF`, `seq = snowflake &&& 0xFFF`. Mint and decode from the CLI:

```bash
python3 build_page.py id mint --ns TSK
python3 build_page.py id decode TSK0KHTOWnGLuC
```

The Portal worked example uses the namespaces `USR / SES / CRS / LSN / PGE / ENR / PRG`, plus `EVT` for domain events.

## Adding a module

The end-to-end loop — promote in the manifest, author fragments, build to A+, promote the landing card, add a
validator block, regenerate the docs, update the tracker — is documented step by step in **`SKILL.md`** and the
**"Resume point and next actions"** section of **`elixir-progress.md`**. For the worked example's specifications and
build prompts, start from **`build-guide/pragmatic.md`**. The toolkit norm is **markdown first, presentation
second**.
