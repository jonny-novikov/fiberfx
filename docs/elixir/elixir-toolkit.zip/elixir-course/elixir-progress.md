# Elixir course — page readiness

A living tracker for *Functional Programming in Elixir* on the jonnify dark-editorial system,
published at `https://jonnify.fly.dev/elixir`. It records what the toolkit can do, what is
published, what is authored, and what comes next. Update it after every page promotion.

> Snapshot taken 2026-05-31. Sources of truth: `build_page.py` (the manifest and gates) and the
> live contents page fetched today. Where the local manifest and the deployed site disagree, both
> states are shown so the gap stays visible.

## This session — what was initialized

The attached guide was unpacked, verified safe, and stood up as a working toolkit. Every part runs.

| Step | Result |
|---|---|
| Unpack the guide bundle | 12 files: `build_page.py`, the two doc generators, the validator harness (4 files), two canonical content fragments, one built reference page, the README, the playbook. |
| Toolkit laid out at `/home/claude/elixir-course/` | builder + generators at root, `content/`, `validator/`, playbook, SKILL. |
| Branded Snowflake IDs verified | `TSK0KHTOWnGLuC` decodes to `274557032793636864` / `2026-01-27 15:11:37 UTC` — exact match to the verified example. Fresh mint + round-trip pass. |
| Design system extracted | `extract-head` wrote `_head.html` (16.3 KB); all colour tokens present (`--ink`, `--cream`, `--gold`, `--blue`, `--sage`, `--elixir`, `--burgundy`, `--line`). |
| Course-design docs generated | `functional-programming-in-elixir.md` (272 lines, 4 Mermaid graphs) and `elixir-references.md` (385 lines, 145 module references). Both report voice gate CLEAN. |
| SKILL initialized | `SKILL.md` — a self-contained, actionable authoring skill distilled from the playbook. |
| Two shipped pages built + graded | both **A+** across all nine Apollo gates. |
| Build fidelity | the freshly built `enum-streams.html` is byte-identical to the shipped reference after normalising the per-build stamp. |
| JavaScript | `node --check` passes on the longest script of each built page. |
| Headless validator | **11 PASS, 0 FAIL, 0 images embedded** (9 DOM checks + 2 mobile-overflow checks, scoped to the built page). |

## Readiness legend

- **Manifest** — status in the local `build_page.py` (`live` / `built` / `planned`).
- **Deployed** — what the published contents page at jonnify.fly.dev currently links (`published` / `planned`).
- **Source here** — whether the page fragment ships in this bundle's `content/` (so it can be built right now).
- **A+ this session** — whether it was built and graded A+ in this session.

## Toolkit components

| Component | File(s) | State |
|---|---|---|
| Page builder + manifest + gates + ID tools + CLI | `build_page.py` | operational |
| Design-system head | `_head.html` (from `HEAD_CSS`) | regenerated |
| Course outline generator | `_gen_course_md.py` → `functional-programming-in-elixir.md` | operational |
| References generator | `_gen_refs_md.py` → `elixir-references.md` | operational |
| Headless DOM validator | `validator/validator.js` | operational (Playwright + chromium resolve here) |
| Course validator suite | `validator/suite.elixir.js` | operational (run with `ONLY=<tag>` to scope) |
| Visual-regression option | `validator/visual.js` | available; needs a one-time `npm install` in `validator/` for `pixelmatch`/`pngjs` |
| Authoring skill | `SKILL.md` | initialized |
| Authoring playbook | `course-authoring-playbook.md` | reference, copied into the toolkit |

## Page readiness by chapter

Scope is six numbered chapters of nine modules each (54), plus the optional two-part F0 history chapter.
**32 modules are built in the manifest; 24 are planned.** Of the 87 registered page fragments, the whole of F3
(9 modules) plus the F4 landing and F4.01, F4.02, F4.03, F4.04, and F4.06 are authorable source in this working tree and were
validated A+ here. The earlier chapters (F0–F2 and F3.01–F3.03) are authored in the full repository and most are
deployed; their source is not part of this working tree.

### F0 · History — `/elixir/course` — accent blue

| Module | Route | Manifest | Deployed | Source here | A+ this session |
|---|---|---|---|---|---|
| F0.1 The evolution of functional languages & runtimes | `/elixir/course/fp-evolution` | built | published | — | — |
| F0.2 The evolution of Erlang, the BEAM & OTP | `/elixir/course/beam-evolution` | built | published | — | — |

Chapter front-matter (not counted as modules): `course` landing/contents, and the `csharp` onramp
("Elixir for C# developers"). Both published.

### F1 · Algebra — `/elixir/algebra` — accent gold

All nine modules built and published.

| Module | Route | Manifest | Deployed |
|---|---|---|---|
| F1.01 What a function really is | `/elixir/algebra/functions` | built | published |
| F1.02 The substitution model | `/elixir/algebra/substitution` | built | published |
| F1.03 Composition, f∘g | `/elixir/algebra/composition` | built | published |
| F1.04 Immutability & binding | `/elixir/algebra/immutability` | built | published |
| F1.05 Sets, sequences & mappings | `/elixir/algebra/collections` | built | published |
| F1.06 Recursion & induction | `/elixir/algebra/recursion` | built | published |
| F1.07 Higher-order operators (Σ, Π) | `/elixir/algebra/higher-order` | built | published |
| F1.08 Equations & pattern matching | `/elixir/algebra/pattern-matching` | built | published |
| F1.09 Functions on the plane — a plotting lab | `/elixir/algebra/plotting-lab` | built | published |

### F2 · Functional Programming — `/elixir/functional` — accent elixir

All nine modules built and published; F2.04–F2.08 carry deep-dive subpage hubs (16 subpages total).

| Module | Route | Manifest | Deployed | Subpages |
|---|---|---|---|---|
| F2.01 Pure functions & side effects | `/elixir/functional/pure` | built | published | — |
| F2.02 Immutability & persistent data | `/elixir/functional/persistence` | built | published | — |
| F2.03 Higher-order functions | `/elixir/functional/higher-order` | built | published | — |
| F2.04 Recursion patterns & tail calls | `/elixir/functional/recursion` | built | published | 3 (shape, tail-calls, patterns) |
| F2.05 map / filter / reduce (folds) | `/elixir/functional/folds` | built | published | 4 (map, filter, reduce, advanced) |
| F2.06 Closures & partial application | `/elixir/functional/closures` | built | published | 3 (environment, capture, currying) |
| F2.07 Algebraic data types | `/elixir/functional/adt` | built | published | 3 (product, sum, matching) |
| F2.08 Composition & pipelines | `/elixir/functional/composition` | built | published | 3 (compose, pipe, pipeline) |
| F2.09 The data-pipeline lab | `/elixir/functional/pipeline-lab` | built | published | — |

### F3 · The Elixir Language — `/elixir/language` — accent elixir

This is the active chapter and the focus of the gap below.

| Module | Route | Manifest | Deployed | Source here | A+ this session |
|---|---|---|---|---|---|
| F3.01 Values, types & IEx | `/elixir/language/values` | built | published | — | — |
| F3.02 Pattern matching & the match operator | `/elixir/language/match` | built | published | — | — |
| **F3.03 Functions, modules & the pipe (hub)** | `/elixir/language/modules` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.03.1 Defining functions | `/elixir/language/modules/functions` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.03.2 Organising with modules | `/elixir/language/modules/organising` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.03.3 The pipe operator | `/elixir/language/modules/pipe` | built | planned | **yes** | **yes** |
| **F3.04 Enumerables & streams (hub)** | `/elixir/language/enum-streams` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.04 Enum, the eager workhorse | `/elixir/language/enum-streams/enum` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.04 Comprehensions | `/elixir/language/enum-streams/comprehensions` | built | planned | — | — |
| &nbsp;&nbsp;↳ F3.04 Lazy streams | `/elixir/language/enum-streams/streams` | built | planned | — | — |
| **F3.05 Structs, maps & keyword lists (hub)** | `/elixir/language/structs` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.05 Defining a struct | `/elixir/language/structs/define` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.05 Enforcing keys & defaults | `/elixir/language/structs/defaults` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.05 Matching on a struct's type | `/elixir/language/structs/matching` | built | planned | **yes** | **yes** |
| **F3.06 Protocols & behaviours (hub)** | `/elixir/language/protocols` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.06 Defining a protocol | `/elixir/language/protocols/define` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.06 Implementing for a struct | `/elixir/language/protocols/defimpl` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.06 Behaviours & callbacks | `/elixir/language/protocols/behaviours` | built | planned | **yes** | **yes** |
| **F3.07 Processes & the actor model (hub)** | `/elixir/language/processes` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.07 Spawning a process | `/elixir/language/processes/spawn` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.07 Sending & receiving messages | `/elixir/language/processes/messages` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.07 Holding state in a loop | `/elixir/language/processes/state` | built | planned | **yes** | **yes** |
| **F3.08 OTP: GenServer & supervisors (hub)** | `/elixir/language/otp` | built | **planned (deploy lags)** | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.08 The GenServer behaviour | `/elixir/language/otp/genserver` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.08 Synchronous call, asynchronous cast | `/elixir/language/otp/call-cast` | built | planned | **yes** | **yes** |
| &nbsp;&nbsp;↳ F3.08 Supervisors & restart strategies | `/elixir/language/otp/supervisors` | built | planned | **yes** | **yes** |
| **F3.09 The process playground (lab)** | `/elixir/language/playground` | built | **planned (deploy lags)** | **yes** | **yes** |

F3.02 and F3.03 also carry subpage hubs (3 each); F3.04 carries 3 (enum, comprehensions, streams);
F3.05 carries 3 (define, defaults, matching); F3.06 carries 3 (define, defimpl, behaviours); F3.07 carries 3
(spawn, messages, state); F3.08 carries 3 (genserver, call-cast, supervisors). F3.09 is a **single-page lab**
with no subpages \u2014 a comprehensive interactive playground rather than a hub-plus-dives module, which is the
intended shape for the chapter's capstone lab.
F3 front-matter: `history`, `timeline`, `under-the-hood` (built in the manifest).

F3.03 (functions, modules & the pipe) was already `built` in the manifest with `SUBPAGES["F3.03"]` and four
registered PAGES, but its four fragment files were absent from this working tree; they have now been authored
here and validated A+ (the hub plus `functions`, `organising`, and `pipe`). Following the F3 convention, the
dives carry two teaching sections each rather than the F4.02/F4.03-style advanced section. The running example
is a learning `Portal`: a learner's scores piped through `Portal.average/1` and `Portal.grade/1` to the atom
`:b`. The hub frames the function/module/pipe trio; the functions dive shows the same guarded `grade/1` as a
named, anonymous, and captured function; the organising dive builds the `Portal` module with an attribute,
`alias`, and `import` (plus `@moduledoc`/`@doc` and the one-module-per-file convention); the pipe dive contrasts
nested calls with the pipeline and states the value-first rewrite rule, `x |> f(a, b) == f(x, a, b)`. The hub
pager goes back to F3.02 (`/elixir/language/match`) and the last dive (pipe) forward to the chapter overview
(`/elixir/language`); the hub note and the pipe note both link forward to the built F3.04. The F3 chapter
landing fragment is not in this working tree, so no landing card relink was needed (F3.03 was already built in
the manifest).

### F4 · Algorithms & Data Structures — `/elixir/algorithms` — accent sage — **chapter live**

The chapter is open: the landing is built and `/elixir/algorithms` is linkable. F4.01, F4.02, F4.03, and F4.04 are
built (each a hub plus three dives; F4.02, F4.03, and F4.04 carry an advanced section per dive), and **F4.06
(CHAMP maps)** is built ahead of F4.05 on request &mdash; also a hub plus three dives, each with an advanced
section. **F4.05 (HAMT) is still planned**, deliberately skipped for now, so it is unlinkable and F4.06&rsquo;s
hub pager points back to the chapter overview rather than a missing `/hamt` route. F4.07&ndash;F4.09 are planned,
and each carries a
three-dive roadmap in the manifest so the navigation
shows the whole path. F4.05–F4.07 (HAMT → CHAMP → **branded CHAMP**) are the chapter spine, where the branded
Snowflake / trie convention used across the course gets its own modules; F4.09 is the "watch a branded CHAMP
map grow" lab.

F4.04 (maps, sets & hashing) is grounded in the course's own Phoenix LiveView data layer, on request: the worked
example is the site's **page registry** — a map from route string to a `%Page{}` struct keyed by a branded
Snowflake id (namespace `PGE`, e.g. `PGE0NbWMtkolM0`, minted with real timestamps and decodable by the same
footer decoder). The hub frames lookup / membership / hashing over that registry; the lookup dive shows
`Map.get`/`fetch`/`put` and ties to `socket.assigns` and `assign/3`; the sets dive runs `MapSet.member?` as the
course's own links gate, with `intersection`/`difference` over the built-versus-F4 route sets (and a two-set
SVG); the hashing dive walks key → `:erlang.phash2` → bucket → collision, and its advanced section sketches the
32-way HAMT (a second SVG) as a direct bridge into F4.05. Each dive carries one teaching section plus one advanced
section, matching F4.02/F4.03. The first dive slug is `lookup` (not `maps`) to avoid a `/maps/maps` route; the
hub pager goes back to F4.03 and the last dive (hashing) forward to `/elixir/algorithms`; the hub note and the
hashing note name **F4.05 — Hash Array Mapped Tries (HAMT)** as the next module, currently unlinked ("in
production"). The F4.03 hub note, an inline F4.03 reference, the F4.03 cost note, and the F4 landing card were all
relinked to `/elixir/algorithms/maps`.

F4.06 (CHAMP maps) was built next on request, jumping past F4.05. CHAMP &mdash; Compressed Hash-Array Mapped
Prefix-tree &mdash; is the compressed successor to the HAMT introduced in F4.04's hashing dive: each node splits
its 32 slots into two bitmaps (a `datamap` and a `nodemap`) and two gap-free packed arrays (entries and
sub-nodes), which buys cache-friendly iteration and a canonical shape per map. The real-world frame is the
course's own persistent page registry and, directly, the stack's **BrandedChamp trie** (a CHAMP keyed by branded
Snowflake ids), with F4.07 named as where the keys become branded. The hub frames layout / iteration / equality
over a CHAMP node (a `datamap`/`nodemap` SVG with a canonical-form badge); the layout dive shows the two bitmaps,
two packed arrays, and the `popcount` index trick (with `Bitwise` `entry?`/`child?`/`data_index`); the iteration
dive contrasts CHAMP's contiguous entry sweep against a HAMT's interleaved 32-slot layout (two toggled SVG
groups) and ties to `Enum.reduce`; the equality dive shows canonical-form structural equality and a one-entry
snapshot diff over two CHAMP trees, bridging to the BrandedChamp trie and LiveView assign-diffing. Each dive is
one teaching section plus one advanced section; all four pages are single-SVG. Subpage slugs are
`layout`/`iteration`/`equality`. **Navigation around the F4.05 gap:** because F4.05 (HAMT, slug `hamt`) is
planned and unlinkable, the F4.06 hub pager back goes to `/elixir/algorithms` (labelled "F4 · Algorithms & Data
Structures"), the last dive (equality) forward goes to `/elixir/algorithms`, and both the hub note and the
equality note name **F4.05 (predecessor)** and **F4.07 — Branded CHAMP maps (next)**, both unlinked ("in
production"). The F4.04 &rarr; F4.05 forward pointers were left intact (F4.05 is still the correct next module);
only the F4 landing's F4.06 card was relinked to `/elixir/algorithms/champ`. The decoder block references the real
minted id `PGE0NbWMtkolM0`.

| Page | Route | Local | Deployed | A+ | Validator |
| --- | --- | --- | --- | --- | --- |
| **F4 landing** | `/elixir/algorithms` | built | **planned (deploy lags)** | **yes** | **yes** |
| **F4.01 Lists, recursion & complexity (hub)** | `/elixir/algorithms/lists` | built | planned | **yes** | **yes** |
| ↳ F4.01.1 Cons cells & the shape of a list | `/elixir/algorithms/lists/cons` | built | planned | **yes** | **yes** |
| ↳ F4.01.2 Recursion over lists | `/elixir/algorithms/lists/recursion` | built | planned | **yes** | **yes** |
| ↳ F4.01.3 Complexity & big-O on the BEAM | `/elixir/algorithms/lists/big-o` | built | planned | **yes** | **yes** |
| **F4.02 Trees & traversals (hub)** | `/elixir/algorithms/trees` | built | planned | **yes** | **yes** |
| ↳ F4.02.1 Binary trees & recursive shape | `/elixir/algorithms/trees/shape` | built | planned | **yes** | **yes** |
| ↳ F4.02.2 Depth-first: pre, in, post-order | `/elixir/algorithms/trees/dfs` | built | planned | **yes** | **yes** |
| ↳ F4.02.3 Breadth-first & balance | `/elixir/algorithms/trees/bfs` | built | planned | **yes** | **yes** |
| **F4.03 Sorting & searching (hub)** | `/elixir/algorithms/sorting` | built | planned | **yes** | **yes** |
| ↳ F4.03.1 Merge & quicksort | `/elixir/algorithms/sorting/sorts` | built | planned | **yes** | **yes** |
| ↳ F4.03.2 Linear & binary search | `/elixir/algorithms/sorting/search` | built | planned | **yes** | **yes** |
| ↳ F4.03.3 Stability & sort cost | `/elixir/algorithms/sorting/cost` | built | planned | **yes** | **yes** |
| **F4.04 Maps, sets & hashing (hub)** | `/elixir/algorithms/maps` | built | planned | **yes** | **yes** |
| ↳ F4.04.1 Maps & key lookup | `/elixir/algorithms/maps/lookup` | built | planned | **yes** | **yes** |
| ↳ F4.04.2 MapSet & membership | `/elixir/algorithms/maps/sets` | built | planned | **yes** | **yes** |
| ↳ F4.04.3 Hashing & collisions | `/elixir/algorithms/maps/hashing` | built | planned | **yes** | **yes** |
| F4.05 Hash Array Mapped Tries (HAMT) (+ 3 dives) | `/elixir/algorithms/hamt` | planned | planned | — | — |
| **F4.06 CHAMP maps (hub)** | `/elixir/algorithms/champ` | built | planned | **yes** | **yes** |
| ↳ F4.06.1 Compressed node layout | `/elixir/algorithms/champ/layout` | built | planned | **yes** | **yes** |
| ↳ F4.06.2 Cache-friendly iteration | `/elixir/algorithms/champ/iteration` | built | planned | **yes** | **yes** |
| ↳ F4.06.3 Canonical equality | `/elixir/algorithms/champ/equality` | built | planned | **yes** | **yes** |
| F4.07–F4.08 (+ 3 dives each) | `…/branded-champ … /dynamic-programming` | planned | planned | — | — |
| F4.09 Watch a branded CHAMP map grow (lab) | `/elixir/algorithms/champ-lab` | planned | planned | — | — |

The F4 landing is a hand-authored fragment (`content/f4-00-landing.html`) with an SVG roadmap of the nine
modules and a hand-written `.mods` directory (the `{{CONTENTS}}` placeholder renders *all* chapters, so a
chapter-only directory is written by hand using the head's card classes). F4.01's, F4.02's, and F4.03's three
dives each are real SUBPAGES; the per-module `dives` lists drive the display roadmap on the contents page and the landing.

F4.02 carries a dedicated **advanced section per page**, as requested: the hub closes on balance and the road to
tries (BST O(log n), degenerate chains, AVL/red-black, and a HAMT's branch-32 ⇒ log₃₂ n shallowness); the shape
dive adds structural sharing on insert (a second static SVG of the rebuilt path vs shared subtrees); the dfs
dive generalises the three orders into one parameterised fold and notes the explicit-stack iterative form; the
bfs dive contrasts a balanced tree against a degenerate chain (a second static SVG) to make the O(log n)-vs-O(n)
split concrete. The running structure throughout is one seven-node BST (`12 · 8 · 30 · 5 · 10 · 20 · 42`), so
in-order is sorted by construction.

F4.03 continues the same advanced-section-per-page treatment, and reuses F4.02's data directly: the array it
sorts and searches is that BST's in-order output, `[5, 8, 10, 12, 20, 30, 42]`, and the search target is `20`
(binary path 12 → 30 → 20, three comparisons; linear, five). The hub frames sorting and searching as one
bargain — pay O(n log n) once, then every lookup is O(log n) — and previews the comparison floor; the sorts
dive shows merge (split/merge over `[8, 3, 5, 1]`) and quicksort (pivot/partition) as one divide-and-conquer
idea, with an advanced section on worst cases and `Enum.sort` being a stable merge sort; the search dive
contrasts linear O(n) with binary O(log n), and its advanced section makes the BEAM-specific point that binary
search needs O(1) random access, so a list forces O(n) and sorted data wants a tuple or a tree; the cost dive
ranks merge / quick / insertion on average, worst, space, and stability, then proves the Ω(n log n) lower bound
with a decision-tree SVG (n! leaves, height ≥ log₂(n!) ≈ n log n).

### F5 · Pragmatic Programming — `/elixir/pragmatic` — accent sage — chapter planned

All nine planned: Mix, ExUnit, typespecs, "let it crash", Tasks, **telemetry**, releases, performance, and
the supervision-tree lab. F5 is where the portal gains telemetry.

### F6 · Phoenix Framework — `/elixir/phoenix` — accent blue — chapter planned

All nine planned: request lifecycle, routing/plugs, Ecto, contexts, HEEx, **LiveView**, PubSub, deployment,
and the live-dashboard lab. F6 is where the portal gains Phoenix LiveView.

## The deploy-versus-local gap

The local manifest is ahead of the deployed contents page in one place worth tracking:

- **F3.03 (modules)**, **F3.04 (enum-streams)**, **F3.05 (structs)**, **F3.06 (protocols & behaviours)**,
  **F3.07 (processes & the actor model)**, **F3.08 (OTP: GenServer & supervisors)**, and **F3.09 (the
  process playground lab)** are `built` in `build_page.py` but the published contents page still shows them as
  `planned` (non-linking cards). With F3.09 done, **F3 is 9/9 built locally** \u2014 the whole chapter.
- **F4 is now open locally**: the chapter is `live`, the F4 landing (`/elixir/algorithms`), **F4.01**, and
  **F4.02** (each a hub + three dives) are built, and the deployed site has not seen any of it yet. The live
  build stamp predates all of these promotions.
- Practical reading: F3.03 through F3.09 and the F4 landing + F4.01 + F4.02 are authored and pass the gates, but
  are not yet linked from the live site. Closing the gap is a deploy step, not an authoring step — except that
  this bundle only carries the fragments authored here (F3.04–F3.09 and F4.00/F4.01/F4.02), so a local
  `build --all` of the rest needs the remaining fragments synced from the full repository first.

## Validation evidence (this session)

```text
id decode TSK0KHTOWnGLuC  ->  snowflake 274557032793636864 · 2026-01-27 15:11:37 UTC   [exact match]
build --page f4-3         ->  sorting.html               · Apollo A+ · 9/9 gates PASS
build --page f4-3-sorts   ->  sorting-sorts.html         · Apollo A+ · 9/9 gates PASS
build --page f4-3-search  ->  sorting-search.html        · Apollo A+ · 9/9 gates PASS
build --page f4-3-cost    ->  sorting-cost.html          · Apollo A+ · 9/9 gates PASS  (2 SVGs)
rebuild f4-2, f4-2-bfs, f4-landing  ->  A+ (F4.02 hub + bfs notes + landing F4.03 card relinked → /elixir/algorithms/sorting)
node --check (page JS)    ->  OK for all four F4.03 pages
routes                    ->  88 allowed (was 84); F4.04 /algorithms/maps correctly absent
suite.elixir.js ONLY=F4.03  ->  44 PASS desktop + 8 PASS mobile · 0 FAIL · images embedded: 0

build --page f3-3         ->  modules.html               · Apollo A+ · 9/9 gates PASS
build --page f3-3-fn      ->  modules-functions.html     · Apollo A+ · 9/9 gates PASS
build --page f3-3-org     ->  modules-organising.html    · Apollo A+ · 9/9 gates PASS
build --page f3-3-pipe    ->  modules-pipe.html          · Apollo A+ · 9/9 gates PASS
F3.03 was already wired in the manifest (built + SUBPAGES + 4 PAGES); only the 4 fragments were missing → authored
node --check (page JS)    ->  OK for all four F3.03 pages
suite.elixir.js ONLY=F3.03  ->  39 PASS desktop + 8 PASS mobile · 0 FAIL · images embedded: 0

build --page f4-4         ->  maps.html                  · Apollo A+ · 9/9 gates PASS
build --page f4-4-lookup  ->  maps-lookup.html           · Apollo A+ · 9/9 gates PASS
build --page f4-4-sets    ->  maps-sets.html             · Apollo A+ · 9/9 gates PASS
build --page f4-4-hashing ->  maps-hashing.html          · Apollo A+ · 9/9 gates PASS  (2 SVGs)
F4.04 was NOT pre-wired: promoted planned→built, added SUBPAGES (lookup, sets, hashing) + 4 PAGES; first dive slug lookup
rebuild f4-3, f4-3-cost, f4-landing  ->  A+ (F4.03 hub note + inline + cost note + landing F4.04 card relinked → /elixir/algorithms/maps)
mint PGE ids  ->  PGE0NbWMtkolM0 (maps), PGE0NbLeJJpTmr (sorting), PGE0NXh7MFjxT6 (modules) — all decode to real timestamps
node --check (page JS)    ->  OK for all four F4.04 pages
routes                    ->  92 allowed (was 88); F4.05 /algorithms/hamt correctly absent
suite.elixir.js ONLY=F4.04  ->  45 PASS desktop + 8 PASS mobile · 0 FAIL · images embedded: 0

build --page f4-6          ->  champ.html                 · Apollo A+ · 9/9 gates PASS
build --page f4-6-layout   ->  champ-layout.html          · Apollo A+ · 9/9 gates PASS
build --page f4-6-iteration->  champ-iteration.html       · Apollo A+ · 9/9 gates PASS
build --page f4-6-equality ->  champ-equality.html        · Apollo A+ · 9/9 gates PASS
F4.06 was NOT pre-wired: promoted planned→built, added SUBPAGES (layout, iteration, equality) + 4 PAGES; built ahead of F4.05
rebuild f4-landing         ->  A+ (landing F4.06 card relinked → /elixir/algorithms/champ; F4.05 card left planned)
F4.04 → F4.05 forward pointers left intact (F4.05 still the correct next module, in production)
node --check (page JS)     ->  OK for all four F4.06 pages
routes                     ->  96 allowed (was 92); F4.05 /algorithms/hamt and F4.07 /algorithms/branded-champ correctly absent
suite.elixir.js ONLY=F4.06  ->  46 PASS desktop + 8 PASS mobile · 0 FAIL · images embedded: 0
```

F4.03's pages are validated by deterministic select-and-read sequences over the sorted seven-element array: the
hub cycles sort → search → cost (role text, the first box's sage stroke, and the result line moving from the
sorted sequence to "found 20" to the "log n" cost); the sorts dive reads the merge step and the `[1, 3, 5, 8]`
result with the split divider at full opacity, then the quicksort pivot step with the pivot bar gold; the search
dive reads the O(n) / O(log n) badge and the "one by one" / "halves" step text with the first binary mid box
turning blue; the cost dive reads the algorithm name and stability across merge (stable), quick (not stable),
and insertion (stable) with the average-case badge.

Apollo gates that passed, per page: `containers`, `svg`, `no-future`, `voice`, `storage`, `motion`,
`degrade`, `links`, `pager`.

## Resume point and next actions

**The F4 chapter is open; F4.01&ndash;F4.04 and F4.06 are complete (F4.05 deliberately skipped).** The chapter is
`live`, the landing (`/elixir/algorithms`) is built, and **F4.01 (Lists, recursion & complexity)**, **F4.02
(Trees & traversals)**, **F4.03 (Sorting & searching)**, **F4.04 (Maps, sets & hashing)**, and **F4.06 (CHAMP
maps)** each ship as a hub plus three dives. F4.02, F4.03, F4.04, and F4.06 carry a dedicated advanced section on
every page, all A+ and green in the validator (F4.04: 45+8 = 53 PASS; F4.06: 46+8 = 54 PASS). F4.04 is grounded
in the course's own Phoenix LiveView data layer (the page registry map keyed by branded `PGE` Snowflake ids, the
route sets behind the links gate, `phash2` into a 32-way HAMT). F4.06 (CHAMP) continues that into the persistent
maps spine and the stack's **BrandedChamp trie**: two-bitmap compressed nodes, cache-friendly iteration, and a
canonical shape for cheap equality and snapshot diffs. **F4.05 (HAMT) is still planned and was skipped on
request**, so it is unlinkable; F4.06's hub pager back goes to `/elixir/algorithms`, and F4.06's hub/equality
notes name F4.05 (predecessor) and F4.07 (next) without links. The F4.04 &rarr; F4.05 pointers were left intact;
only the F4 landing's F4.06 card was relinked to `/elixir/algorithms/champ`. The chapter accent is sage; `.ex`/
`code.inl` stay the global Elixir purple.

**Resume at F4.05 — Hash Array Mapped Tries (HAMT)** (`slug` "hamt", route `/elixir/algorithms/hamt`), the
remaining gap in the spine, currently `planned` with a three-dive roadmap (bitmap / index / sharing). The bridge
in is F4.04's hashing dive (a 32-way branch on the hash) and the bridge out is F4.06 (its compressed successor).
After F4.05, **F4.07 — Branded CHAMP maps** (`slug` "branded-champ") closes the spine, keying the CHAMP by branded
Snowflake ids &mdash; the stack's BrandedChamp trie.

Immediate steps for F4.05, in order:

1. Author the F4.05 hub + three dive subpages into `content/` (e.g. `f4-05-hamt.html` + three dives: bitmap,
   index, sharing), following the page anatomy in `SKILL.md`, with an advanced section per page. The bridge back
   is F4.04 (hashing sends a key to a slot); the bridge forward is F4.06 (CHAMP compresses the node). Keep prefixes
   off `st` and unique per page.
2. Promote F4.05 to `built`; the `dives` roadmap is already in the manifest — add `SUBPAGES["F4.05"]` and register
   PAGES with unique output filenames. Confirm the route is `/elixir/algorithms/hamt`.
3. Relink the F4.04 &rarr; F4.05 forward pointers (F4.04 hub note + hashing note name **F4.05 — Hash Array Mapped
   Tries (HAMT)** unlinked): wrap them in `<a href="/elixir/algorithms/hamt">` and drop "(in production)". Then
   relink F4.06's predecessor references: the F4.06 hub note and equality note name **F4.05** unlinked — link
   those too, and consider repointing the F4.06 hub pager back from `/elixir/algorithms` to
   `/elixir/algorithms/hamt` now that the previous module exists. On the F4 landing, change the F4.05 card from
   `<div class="mod is-quiet">` to a linkable `<a class="mod" href="/elixir/algorithms/hamt">`, pill `planned` →
   `built`.
4. Verify routes, run the voice sweep (incl. JS strings AND static code comments — a dismissive adverb inside a
   `<pre class="code">` comment is visible text and fails the voice gate, because static code is NOT stripped the
   way `<script>` is; this caught the F4.04 hashing dive on first build), build, grade for A+, `node --check` the
   JS, and add a tagged validator block run with `ONLY="F4.05"`.
5. Regenerate `functional-programming-in-elixir.md` and `elixir-references.md`, update this tracker, then
   deliver. (F4.07 — Branded CHAMP maps — is the next module after F4.05.)

**Deferred wiring (not authoring):** lighting up F3.05–F3.09 on the F3 chapter landing needs
`content/f3-00-landing.html`, which is not in this bundle. The deploy gap above is the same kind of step — the
live site still trails the local manifest (now including the whole of F3 and the F4 landing + F4.01 + F4.02 +
F4.03 + F4.04 + F4.06). Both are sync/deploy steps to run against the full repository.

## Known follow-ups

- The outline generator's hand-written "At a glance" summary prose lags the manifest (it predates the
  F2.09, F3.01–F3.09, and F4 promotions); its per-chapter tables, derived from the manifest, are correct and now
  show F3 fully built, the F4 chapter open with F4.01, F4.02, F4.03, and F4.04 as built hubs (three nested dives
  each) and F4.06 as a built hub (three dives) ahead of a still-planned F4.05, and F4.05/F4.07/F4.08 with their
  three-dive roadmaps. Refresh the summary prose in `_gen_course_md.py` when convenient.
- Wiring references into the builder as a `references` manifest field with a `render_references()` footer
  (rather than a separate document) remains an open enhancement noted in the playbook.

## How to continue

Read `SKILL.md` first (it is the operational guide), then `course-authoring-playbook.md` for the full
reasoning and the copy-paste appendices. The CLI:

```bash
python3 build_page.py manifest        # the current chapter/module state
python3 build_page.py routes          # every linkable route
python3 build_page.py build --page KEY
python3 build_page.py check OUT.html  # the nine gates + grade
python3 build_page.py id mint
BASE_URL="file:///home/claude/elixir-course" ONLY="<tag>" node validator/suite.elixir.js
```
