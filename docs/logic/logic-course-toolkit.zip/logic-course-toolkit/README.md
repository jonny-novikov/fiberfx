# Курс II «Логика и принятие решений» — toolkit

Стартовый комплект и текущее состояние курса в системе тёмно-редакторского дизайна.
Тема: вероятность + логика + теория решений как защита «от обмана собственным мозгом».

## С чего начать (новая сессия)
1. `logic-status.md` — текущее состояние и дорожная карта.
2. `logic-course-design.md` — архитектура 6×6, поглавный разбор, палитра, паттерн навигации.
3. `course-build-playbook.md` — общие механики (CSS-токены, шрифты, движок квиза, KaTeX-правила, Quality Gates).
4. `logic-references.md` — 18 реальных академических источников по главам.

## Содержимое
- `logic-course-design.md`, `logic-references.md`, `logic-status.md` — спецификации
- `course-build-playbook.md` — общий гайд по сборке (разделяется всеми курсами)
- `logic/verify_math.py` — проверка формул курса (EV, дисперсия, Байес, теория игр, статистика, CRT/якорь). Запуск: `python3 logic/verify_math.py`
- `logic/build_chapter_quiz.py` — генератор «Квиз главы» (запуск: `OUT_BASE=. python3 logic/build_chapter_quiz.py`)
- `logic/build_chapter_landing.py` — генератор лендингов глав
- `logic/preflight.py` — pre-flight скан (KaTeX/смешанные скрипты/ссылки/структура)
- `logic/index.html` — главная курса; `logic/{глава}/index.html` — лендинги;
  `logic/{глава}/kviz.html` — квизы; `logic/iskazheniya/sistemy.html` (1.1) и `yakorenie.html` (1.2) — модули
- `toolkit/validator.js`, `toolkit/visual.js` — headless-валидация (0 изображений)

## Валидация (0 image budget)
```
BASE_URL="file:///abs/path/to/logic" NODE_PATH="/path/to/node_modules" node suite.X.js
```
Проверяет DOM/computedStyle через stdout, без скриншотов. См. `toolkit/suite.example.js`.

## Состояние
Готово: главная `/logic`, 6 лендингов глав, 6 «Квиз главы», модули 1.1 (две системы мышления) и 1.2 (якорение). Core-модулей: 2/36, Глава 1 — 2/6.
Дальше: модули по 2 за раз. Следующая пара — 1.3 «Доступность» + 1.4 «Ошибка выжившего».
