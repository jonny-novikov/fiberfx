# Курс II «Логика и принятие решений» — toolkit

Стартовый комплект, прогресс и дизайн курса в системе тёмно-редакторского дизайна.
Тема: вероятность + логика + теория решений как защита «от обмана собственным мозгом».

## Публикация
Курс опубликован: **https://jonnify.fly.dev/logic** — часть серии **jonnify** (девять
интерактивных курсов: школьная математика и геометрия, ЕГЭ, финансы `/edu`, здоровье,
право, логика, Elixir, «Образование будущего»). Карта серии — `llms.txt` (включён в архив),
полный список URL — `https://jonnify.fly.dev/sitemap.xml`.

Страницы в этом архиве — авторский исходник `/logic`; живой сайт остаётся каноном
опубликованного состояния.

## С чего начать (новая сессия)
1. `logic-status.md` — текущее состояние, прогресс, дорожная карта.
2. `logic-course-design.md` — архитектура 6×6, поглавный разбор с интерактивами, палитра, паттерн навигации.
3. `course-build-playbook.md` — ОБЩИЕ механики (CSS-токены, шрифты, движок квиза, KaTeX-правила, Quality Gates).
4. `logic-references.md` — 18 реальных академических источников; `llms.txt` — карта всей серии.

## Содержимое
- `logic-course-design.md`, `logic-references.md`, `logic-status.md` — спецификации (дизайн + прогресс)
- `course-build-playbook.md` — общий гайд по сборке (разделяется всеми курсами серии)
- `llms.txt` — карта знаний всей серии jonnify (контекст для агента)
- `logic/verify_math.py` — проверка формул (EV, дисперсия, Байес, теория игр, статистика, CRT/якорь). Запуск: `python3 logic/verify_math.py`
- `logic/build_chapter_quiz.py`, `logic/build_chapter_landing.py` — генераторы (запуск с `OUT_BASE=...`)
- `logic/preflight.py` — pre-flight скан (KaTeX/смешанные скрипты/ссылки/структура)
- `logic/index.html` — главная; `logic/{глава}/index.html` — лендинги; `logic/{глава}/kviz.html` — квизы;
  `logic/iskazheniya/sistemy.html` (1.1) и `yakorenie.html` (1.2) — модули
- `toolkit/validator.js`, `toolkit/visual.js` — headless-валидация (0 изображений)

## Валидация (0 image budget)
```
BASE_URL="file:///abs/path/to/logic" NODE_PATH="/path/to/node_modules" node suite.X.js
```
Проверяет DOM/computedStyle через stdout, без скриншотов. Пример — `toolkit/suite.example.js`.

## Состояние и дизайн
Готово: главная `/logic`, 6 лендингов глав, 6 «Квиз главы», модули 1.1 (две системы мышления)
и 1.2 (якорение). Core-модулей: 2/36, Глава 1 — 2/6.
Дизайн: тёмно-редакторская вёрстка, KaTeX strict, навигация по секциям + нижняя навигация,
тема на главу из палитры (детали — в `course-build-playbook.md` и `logic-course-design.md`).
Дальше: модули по 2 за раз. Следующая пара — 1.3 «Доступность» + 1.4 «Ошибка выжившего».
